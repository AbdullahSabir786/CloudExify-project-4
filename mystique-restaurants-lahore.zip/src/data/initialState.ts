import { User, Order, TableReservation, Review } from '../types';

export const DEMO_USERS: User[] = [
  {
    id: 'usr-customer-1',
    email: 'samiyaf381@gmail.com',
    name: 'Samiya Fatima',
    role: 'customer',
    phone: '+92 321 4567890',
    address: 'House 42, Block H, Gulberg III, Lahore',
    avatar: 'https://images.unsplash.com/photo-1534528741775-53994a69daeb?auto=format&fit=crop&w=200&q=80'
  },
  {
    id: 'usr-admin-1',
    email: 'admin@mystiquerestaurants.com',
    name: 'Farhan Zaidi (General Manager)',
    role: 'admin',
    phone: '+92 310 6036759',
    address: 'Mystique MM Alam Rd, Gulberg, Lahore',
    avatar: 'https://images.unsplash.com/photo-1507003211169-0a1dd7228f2d?auto=format&fit=crop&w=200&q=80'
  },
  {
    id: 'usr-staff-1',
    email: 'chef.tariq@mystiquerestaurants.com',
    name: 'Executive Chef Tariq',
    role: 'staff',
    phone: '+92 300 8492011',
    address: 'Mystique Kitchen, MM Alam Rd, Lahore',
    avatar: 'https://images.unsplash.com/photo-1577219491135-ce391730fb2c?auto=format&fit=crop&w=200&q=80'
  }
];

export const INITIAL_ORDERS: Order[] = [
  {
    id: 'ord-101',
    orderNumber: 'MYS-8821',
    customerId: 'usr-customer-1',
    customerName: 'Samiya Fatima',
    customerPhone: '+92 321 4567890',
    customerEmail: 'samiyaf381@gmail.com',
    orderType: 'dine_in',
    tableNumber: 'Table 7 (Indoor Lounge)',
    items: [
      {
        menuItemId: 'cont-1',
        name: 'Parmesan Chicken (Best Seller)',
        unitPrice: 2650,
        quantity: 1,
        totalItemPrice: 2650,
        specialInstructions: 'Extra marinara sauce on side please',
        image: 'https://images.unsplash.com/photo-1632778149955-e80f8ceca2e8?auto=format&fit=crop&w=400&q=80'
      },
      {
        menuItemId: 'sushi-1',
        name: 'Mystique Maki (Signature)',
        unitPrice: 4000,
        quantity: 1,
        selectedPortion: '8 Pieces (Full Platter)',
        totalItemPrice: 4000,
        image: 'https://images.unsplash.com/photo-1579871494447-9811cf80d66c?auto=format&fit=crop&w=400&q=80'
      },
      {
        menuItemId: 'bev-1',
        name: 'Mystique Mint Margherita',
        unitPrice: 850,
        quantity: 2,
        totalItemPrice: 1700,
        image: 'https://images.unsplash.com/photo-1513558161293-cdaf765ed2fd?auto=format&fit=crop&w=400&q=80'
      }
    ],
    subtotal: 8350,
    tax: 1336, // 16% PRA GST
    deliveryFee: 0,
    discount: 0,
    total: 9686,
    paymentMethod: 'card_at_counter',
    paymentStatus: 'paid',
    status: 'preparing',
    statusTimeline: [
      { status: 'pending', timestamp: '15 mins ago', note: 'Order placed by diner at Table 7' },
      { status: 'preparing', timestamp: '10 mins ago', note: 'Head Chef confirmed ticket in kitchen' }
    ],
    specialOrderNote: 'Anniversary celebration tonight!',
    createdAt: new Date(Date.now() - 15 * 60 * 1000).toISOString(),
    estimatedPrepMinutes: 25
  },
  {
    id: 'ord-102',
    orderNumber: 'MYS-8822',
    customerId: 'usr-customer-2',
    customerName: 'Hamza Malik',
    customerPhone: '+92 333 9871234',
    customerEmail: 'hamza.malik@gmail.com',
    orderType: 'delivery',
    deliveryAddress: 'House 18-B, Sector Z, Phase 3 DHA, Lahore',
    items: [
      {
        menuItemId: 'asia-10',
        name: 'Chili Dry Signature',
        unitPrice: 3000,
        quantity: 2,
        selectedProtein: 'Beef Tenderloin',
        totalItemPrice: 6000,
        image: 'https://images.unsplash.com/photo-1543339308-43e59d6b73a6?auto=format&fit=crop&w=400&q=80'
      },
      {
        menuItemId: 'side-3',
        name: 'Chicken Fried Rice',
        unitPrice: 1050,
        quantity: 2,
        totalItemPrice: 2100,
        image: 'https://images.unsplash.com/photo-1512058564366-18510be2db19?auto=format&fit=crop&w=400&q=80'
      },
      {
        menuItemId: 'des-1',
        name: 'The Famous Matilda Chocolate Cake',
        unitPrice: 1650,
        quantity: 1,
        totalItemPrice: 1650,
        image: 'https://images.unsplash.com/photo-1578985545062-69928b1d9587?auto=format&fit=crop&w=400&q=80'
      }
    ],
    subtotal: 9750,
    tax: 1560,
    deliveryFee: 350,
    discount: 0,
    total: 11660,
    paymentMethod: 'cash_on_delivery',
    paymentStatus: 'unpaid',
    status: 'pending',
    statusTimeline: [
      { status: 'pending', timestamp: '3 mins ago', note: 'Order received via online portal' }
    ],
    createdAt: new Date(Date.now() - 3 * 60 * 1000).toISOString(),
    estimatedPrepMinutes: 30
  },
  {
    id: 'ord-103',
    orderNumber: 'MYS-8820',
    customerId: 'usr-customer-3',
    customerName: 'Ayesha Rahman',
    customerPhone: '+92 300 5556789',
    customerEmail: 'ayesha.r@yahoo.com',
    orderType: 'dine_in',
    tableNumber: 'Table 14 (Private Dining Room)',
    items: [
      {
        menuItemId: 'cont-4',
        name: 'Grilled Norwegian Salmon',
        unitPrice: 4800,
        quantity: 2,
        totalItemPrice: 9600,
        image: 'https://images.unsplash.com/photo-1485921325833-c519f76c4927?auto=format&fit=crop&w=400&q=80'
      },
      {
        menuItemId: 'bev-2',
        name: 'Strawberry Garden Mojito',
        unitPrice: 950,
        quantity: 2,
        totalItemPrice: 1900,
        image: 'https://images.unsplash.com/photo-1551538827-9c037cb4f32a?auto=format&fit=crop&w=400&q=80'
      }
    ],
    subtotal: 11500,
    tax: 1840,
    deliveryFee: 0,
    discount: 0,
    total: 13340,
    paymentMethod: 'card_at_counter',
    paymentStatus: 'paid',
    status: 'ready',
    statusTimeline: [
      { status: 'pending', timestamp: '35 mins ago' },
      { status: 'preparing', timestamp: '25 mins ago' },
      { status: 'ready', timestamp: '5 mins ago', note: 'Plated and ready on counter for service' }
    ],
    createdAt: new Date(Date.now() - 35 * 60 * 1000).toISOString(),
    estimatedPrepMinutes: 25
  },
  {
    id: 'ord-100',
    orderNumber: 'MYS-8819',
    customerId: 'usr-customer-4',
    customerName: 'Dr. Usman Qureshi',
    customerPhone: '+92 322 1112233',
    customerEmail: 'dr.usman@hospital.pk',
    orderType: 'takeaway',
    items: [
      {
        menuItemId: 'asia-1',
        name: 'Gai Pad Prik (SOD - Mystique Special)',
        unitPrice: 2750,
        quantity: 1,
        totalItemPrice: 2750,
        image: 'https://images.unsplash.com/photo-1525755662778-989d0524087e?auto=format&fit=crop&w=400&q=80'
      },
      {
        menuItemId: 'des-2',
        name: 'Belgian Molten Lava Cake',
        unitPrice: 1450,
        quantity: 1,
        totalItemPrice: 1450,
        image: 'https://images.unsplash.com/photo-1606313564200-e75d5e30476c?auto=format&fit=crop&w=400&q=80'
      }
    ],
    subtotal: 4200,
    tax: 672,
    deliveryFee: 0,
    discount: 0,
    total: 4872,
    paymentMethod: 'jazzcash_easypaisa',
    paymentStatus: 'paid',
    status: 'completed',
    statusTimeline: [
      { status: 'pending', timestamp: '1 hour ago' },
      { status: 'preparing', timestamp: '50 mins ago' },
      { status: 'ready', timestamp: '30 mins ago' },
      { status: 'completed', timestamp: '15 mins ago', note: 'Customer picked up package at MM Alam front desk' }
    ],
    createdAt: new Date(Date.now() - 60 * 60 * 1000).toISOString(),
    estimatedPrepMinutes: 20
  }
];

export const INITIAL_RESERVATIONS: TableReservation[] = [
  {
    id: 'res-1',
    customerName: 'Samiya Fatima',
    customerPhone: '+92 321 4567890',
    customerEmail: 'samiyaf381@gmail.com',
    guestsCount: 4,
    date: '2026-08-26',
    time: '20:30',
    diningArea: 'Indoor Royal Lounge',
    specialRequests: 'Window side table if possible for birthday celebration',
    status: 'confirmed',
    tableAssigned: 'Table 12',
    createdAt: new Date(Date.now() - 2 * 3600 * 1000).toISOString()
  },
  {
    id: 'res-2',
    customerName: 'Shahbaz Sharif & Guests',
    customerPhone: '+92 300 4443322',
    customerEmail: 'shahbaz.corp@lahore.pk',
    guestsCount: 8,
    date: '2026-08-27',
    time: '21:00',
    diningArea: 'Private Dining Room',
    specialRequests: 'Corporate dinner, high-tea platter to start',
    status: 'pending',
    createdAt: new Date(Date.now() - 5 * 3600 * 1000).toISOString()
  },
  {
    id: 'res-3',
    customerName: 'Rabia Tariq',
    customerPhone: '+92 333 1298471',
    customerEmail: 'rabia.t@gmail.com',
    guestsCount: 2,
    date: '2026-08-26',
    time: '19:45',
    diningArea: 'MM Alam Terrace',
    specialRequests: 'Live music view preferred',
    status: 'confirmed',
    tableAssigned: 'Terrace-4',
    createdAt: new Date(Date.now() - 8 * 3600 * 1000).toISOString()
  }
];

export const INITIAL_REVIEWS: Review[] = [
  {
    id: 'rev-1',
    userName: 'Ahsan Abdul Rehman',
    rating: 5,
    date: '1 week ago',
    comment: 'Mystique MM Alam has elevated fine dining in Lahore! The Parmesan Chicken is unmatched in flavor and the Volcano Maki sushi was pure melt-in-the-mouth perfection. Staff was courteous and the atmosphere with live music was superb.',
    dishRecommended: 'Parmesan Chicken & Volcano Maki',
    verifiedVisit: true,
    avatarBg: 'bg-emerald-800'
  },
  {
    id: 'rev-2',
    userName: 'Zainab Qazi',
    rating: 5,
    date: '2 weeks ago',
    comment: 'The famous Matilda Chocolate Cake lived up to the massive hype! Rich, warm, decadent. We also tried the Gai Pad Prik and Chili Dry - true Asian spice balance. Definitely coming back for their High Tea.',
    dishRecommended: 'Matilda Chocolate Cake',
    verifiedVisit: true,
    avatarBg: 'bg-amber-800'
  },
  {
    id: 'rev-3',
    userName: 'Bilal Chaudhry',
    rating: 5,
    date: '3 weeks ago',
    comment: 'Booked the Private Dining Room for my sister’s engagement dinner. Flawless hospitality, exquisite steak and Grilled Norwegian Salmon. Lahore’s finest restaurant on MM Alam Rd.',
    dishRecommended: 'Grilled Norwegian Salmon',
    verifiedVisit: true,
    avatarBg: 'bg-purple-900'
  },
  {
    id: 'rev-4',
    userName: 'Mahnoor Siddiqui',
    rating: 4,
    date: '1 month ago',
    comment: 'Amazing ambiance and the Mint Margherita is so refreshing. The Chicken Cordon Bleu was stuffed with premium smoked turkey. 10/10 presentation!',
    dishRecommended: 'Mint Margherita & Cordon Bleu',
    verifiedVisit: true,
    avatarBg: 'bg-rose-900'
  }
];
