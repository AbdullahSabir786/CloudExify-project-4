import React, { useState } from 'react';
import { useRestaurant } from '../../context/RestaurantContext';
import { X, CalendarCheck, Users, Clock, MapPin, Sparkles, CheckCircle2 } from 'lucide-react';
import { motion, AnimatePresence } from 'motion/react';

export const ReservationModal: React.FC = () => {
  const { isReservationModalOpen, setIsReservationModalOpen, createReservation, currentUser } = useRestaurant();

  const [customerName, setCustomerName] = useState(currentUser?.name || '');
  const [customerPhone, setCustomerPhone] = useState(currentUser?.phone || '+92 321 4567890');
  const [customerEmail, setCustomerEmail] = useState(currentUser?.email || 'diner@lahore.pk');
  const [guestsCount, setGuestsCount] = useState(2);
  const [date, setDate] = useState('2026-08-26');
  const [time, setTime] = useState('20:00');
  const [diningArea, setDiningArea] = useState<'Indoor Royal Lounge' | 'Private Dining Room' | 'MM Alam Terrace' | 'Live Music Lounge'>('Indoor Royal Lounge');
  const [specialRequests, setSpecialRequests] = useState('');
  const [submitted, setSubmitted] = useState(false);

  if (!isReservationModalOpen) return null;

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (!customerName || !customerPhone) return;

    createReservation({
      customerName,
      customerPhone,
      customerEmail,
      guestsCount,
      date,
      time,
      diningArea,
      specialRequests: specialRequests.trim() || undefined
    });

    setSubmitted(true);
    setTimeout(() => {
      setSubmitted(false);
      setIsReservationModalOpen(false);
    }, 2000);
  };

  const diningAreas: { id: 'Indoor Royal Lounge' | 'Private Dining Room' | 'MM Alam Terrace' | 'Live Music Lounge'; title: string; desc: string; icon: string }[] = [
    { id: 'Indoor Royal Lounge', title: 'Indoor Royal Lounge', desc: 'Opulent chandelier dining with plush velvet seating', icon: '🏛️' },
    { id: 'Private Dining Room', title: 'Private VIP Dining Room', desc: 'Exclusive enclosed room for corporate/family events (4-14 guests)', icon: '👑' },
    { id: 'MM Alam Terrace', title: 'MM Alam Terrace', desc: 'Open-air al fresco terrace overlooking Gulberg boulevard', icon: '🌿' },
    { id: 'Live Music Lounge', title: 'Live Music Lounge', desc: 'Close to evening acoustic instrument performances', icon: '🎷' },
  ];

  return (
    <AnimatePresence>
      <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/80 backdrop-blur-md overflow-y-auto">
        <motion.div
          initial={{ opacity: 0, scale: 0.95, y: 15 }}
          animate={{ opacity: 1, scale: 1, y: 0 }}
          exit={{ opacity: 0, scale: 0.95, y: 15 }}
          className="w-full max-w-xl bg-[#0a140f]/90 backdrop-blur-2xl border border-[#d4af37]/40 rounded-3xl shadow-[0_20px_60px_rgba(0,0,0,0.8)] overflow-hidden my-6"
        >
          {/* Header */}
          <div className="p-6 bg-[#0e1c14]/80 backdrop-blur-xl border-b border-[#d4af37]/25 flex items-center justify-between">
            <div className="flex items-center gap-3">
              <div className="w-11 h-11 rounded-2xl bg-[#1a2d21]/90 border border-[#d4af37]/40 flex items-center justify-center shadow-md">
                <CalendarCheck className="w-6 h-6 text-[#d4af37]" />
              </div>
              <div>
                <h3 className="font-cinzel text-lg font-bold text-[#fcfaf5]">Table Reservation</h3>
                <p className="text-xs text-neutral-300">
                  Mystique Restaurants • 41-A MM Alam Rd Gulberg, Lahore
                </p>
              </div>
            </div>

            <button
              onClick={() => setIsReservationModalOpen(false)}
              className="p-1.5 rounded-lg text-neutral-400 hover:text-white hover:bg-white/10 transition-colors"
            >
              <X className="w-5 h-5" />
            </button>
          </div>

          {submitted ? (
            <div className="p-12 text-center space-y-4">
              <div className="w-16 h-16 mx-auto rounded-full bg-emerald-900/60 border border-emerald-500/50 flex items-center justify-center text-emerald-300 shadow-lg">
                <CheckCircle2 className="w-10 h-10" />
              </div>
              <h4 className="font-cinzel text-xl font-bold text-white">Table Request Confirmed!</h4>
              <p className="text-xs text-neutral-300 max-w-sm mx-auto">
                Thank you, {customerName}. Your reservation request for {guestsCount} guests at Mystique ({diningArea}) has been transmitted to front desk management.
              </p>
              <div className="font-mono text-xs text-[#d4af37]">
                Confirmation SMS sent to {customerPhone}
              </div>
            </div>
          ) : (
            <form onSubmit={handleSubmit} className="p-6 space-y-4 max-h-[75vh] overflow-y-auto">
              
              {/* Dining Area Selection */}
              <div>
                <label className="block text-[11px] uppercase tracking-wider text-neutral-400 font-semibold mb-2">
                  Select Dining Ambience
                </label>
                <div className="grid grid-cols-1 sm:grid-cols-2 gap-2.5">
                  {diningAreas.map((area) => (
                    <button
                      key={area.id}
                      type="button"
                      onClick={() => setDiningArea(area.id)}
                      className={`p-3 rounded-2xl text-left border transition-all ${
                        diningArea === area.id
                          ? 'bg-[#182c20]/90 border-[#d4af37] text-white shadow-[0_2px_15px_rgba(212,175,55,0.18)]'
                          : 'bg-[#101913]/60 border-white/10 text-neutral-400 hover:border-neutral-700'
                      }`}
                    >
                      <div className="flex items-center gap-2 font-bold text-xs text-[#fcfaf5]">
                        <span>{area.icon}</span>
                        <span>{area.title}</span>
                      </div>
                      <div className="text-[10px] text-neutral-400 mt-1 line-clamp-1">
                        {area.desc}
                      </div>
                    </button>
                  ))}
                </div>
              </div>

              {/* Guest Count & Date & Time */}
              <div className="grid grid-cols-1 sm:grid-cols-3 gap-3">
                <div>
                  <label className="block text-[11px] uppercase tracking-wider text-neutral-400 font-semibold mb-1">
                    Guests Count
                  </label>
                  <div className="relative">
                    <Users className="w-4 h-4 text-neutral-400 absolute left-3 top-3" />
                    <select
                      value={guestsCount}
                      onChange={(e) => setGuestsCount(Number(e.target.value))}
                      className="w-full pl-9 pr-3 py-2.5 glass-input rounded-xl text-xs text-white focus:outline-none"
                    >
                      {[1, 2, 3, 4, 5, 6, 7, 8, 10, 12, 16, 20].map(n => (
                        <option key={n} value={n} className="bg-[#0c1410]">
                          {n} {n === 1 ? 'Guest' : 'Guests'}
                        </option>
                      ))}
                    </select>
                  </div>
                </div>

                <div>
                  <label className="block text-[11px] uppercase tracking-wider text-neutral-400 font-semibold mb-1">
                    Date
                  </label>
                  <input
                    type="date"
                    required
                    value={date}
                    onChange={(e) => setDate(e.target.value)}
                    className="w-full px-3 py-2.5 glass-input rounded-xl text-xs text-white focus:outline-none"
                  />
                </div>

                <div>
                  <label className="block text-[11px] uppercase tracking-wider text-neutral-400 font-semibold mb-1">
                    Time Slot
                  </label>
                  <div className="relative">
                    <Clock className="w-4 h-4 text-neutral-400 absolute left-3 top-3" />
                    <select
                      value={time}
                      onChange={(e) => setTime(e.target.value)}
                      className="w-full pl-9 pr-3 py-2.5 glass-input rounded-xl text-xs text-white focus:outline-none"
                    >
                      <option value="12:30" className="bg-[#0c1410]">12:30 PM (Lunch)</option>
                      <option value="13:30" className="bg-[#0c1410]">01:30 PM (Lunch)</option>
                      <option value="16:30" className="bg-[#0c1410]">04:30 PM (Hi-Tea)</option>
                      <option value="19:30" className="bg-[#0c1410]">07:30 PM (Early Dinner)</option>
                      <option value="20:30" className="bg-[#0c1410]">08:30 PM (Prime Dinner)</option>
                      <option value="21:30" className="bg-[#0c1410]">09:30 PM (Dinner & Music)</option>
                      <option value="22:30" className="bg-[#0c1410]">10:30 PM (Late Night)</option>
                    </select>
                  </div>
                </div>
              </div>

              {/* Guest Details */}
              <div className="grid grid-cols-1 sm:grid-cols-2 gap-3 pt-2">
                <div>
                  <label className="block text-[11px] uppercase tracking-wider text-neutral-400 font-semibold mb-1">
                    Your Full Name
                  </label>
                  <input
                    type="text"
                    required
                    value={customerName}
                    onChange={(e) => setCustomerName(e.target.value)}
                    placeholder="e.g. Samiya Fatima"
                    className="w-full px-3.5 py-2.5 glass-input rounded-xl text-xs text-white focus:outline-none"
                  />
                </div>

                <div>
                  <label className="block text-[11px] uppercase tracking-wider text-neutral-400 font-semibold mb-1">
                    Contact Phone (WhatsApp)
                  </label>
                  <input
                    type="tel"
                    required
                    value={customerPhone}
                    onChange={(e) => setCustomerPhone(e.target.value)}
                    placeholder="+92 321 4567890"
                    className="w-full px-3.5 py-2.5 glass-input rounded-xl text-xs text-white focus:outline-none"
                  />
                </div>
              </div>

              {/* Special Notes */}
              <div>
                <label className="block text-[11px] uppercase tracking-wider text-neutral-400 font-semibold mb-1">
                  Special Occasion or Seating Preference
                </label>
                <input
                  type="text"
                  value={specialRequests}
                  onChange={(e) => setSpecialRequests(e.target.value)}
                  placeholder="e.g. Birthday setup, high chair for toddler, window view"
                  className="w-full px-3.5 py-2.5 glass-input rounded-xl text-xs text-white focus:outline-none"
                />
              </div>

              {/* Submit CTA */}
              <button
                type="submit"
                className="w-full py-3.5 mt-4 rounded-xl bg-gradient-to-r from-[#d4af37] via-[#e2c458] to-[#aa8210] text-[#090f0c] text-xs font-bold uppercase tracking-wider shadow-[0_4px_25px_rgba(212,175,55,0.25)] hover:brightness-110 active:scale-98 transition-all flex items-center justify-center gap-2"
              >
                <Sparkles className="w-4 h-4" />
                <span>Request Reservation at MM Alam</span>
              </button>

              <div className="text-[10px] text-center text-neutral-400">
                No reservation fee. Table held for 15 minutes past scheduled time.
              </div>
            </form>
          )}
        </motion.div>
      </div>
    </AnimatePresence>
  );
};
