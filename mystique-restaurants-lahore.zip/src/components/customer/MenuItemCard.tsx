import React from 'react';
import { MenuItem } from '../../types';
import { Sparkles, Flame, Plus, Clock, Ban } from 'lucide-react';
import { motion } from 'motion/react';

interface MenuItemCardProps {
  item: MenuItem;
  onSelect: (item: MenuItem) => void;
}

export const MenuItemCard: React.FC<MenuItemCardProps> = ({ item, onSelect }) => {
  return (
    <motion.div
      initial={{ opacity: 0, y: 15 }}
      whileInView={{ opacity: 1, y: 0 }}
      viewport={{ once: true }}
      className={`group relative rounded-2xl overflow-hidden glass-card transition-all duration-300 flex flex-col justify-between ${
        item.isAvailable
          ? 'hover:border-[#d4af37]/60 hover:shadow-[0_8px_30px_rgba(212,175,55,0.15)] hover:-translate-y-1'
          : 'opacity-60 grayscale-[40%]'
      }`}
    >
      {/* Top Image Container */}
      <div className="relative h-48 w-full overflow-hidden bg-[#080e0a]">
        <img
          src={item.image}
          alt={item.name}
          className="w-full h-full object-cover transition-transform duration-500 group-hover:scale-105"
          loading="lazy"
        />
        <div className="absolute inset-0 bg-gradient-to-t from-[#0b130f] via-transparent to-black/30" />

        {/* Top badges */}
        <div className="absolute top-3 left-3 right-3 flex items-center justify-between gap-1">
          <div className="flex flex-wrap gap-1">
            {item.isChefSpecial && (
              <span className="px-2 py-0.5 rounded-md bg-[#d4af37] text-black text-[10px] font-bold uppercase tracking-wider shadow-sm flex items-center gap-0.5">
                <Sparkles className="w-2.5 h-2.5" /> Chef Special
              </span>
            )}
            {item.isPopular && !item.isChefSpecial && (
              <span className="px-2 py-0.5 rounded-md bg-amber-500/90 text-black text-[10px] font-bold uppercase tracking-wider">
                Popular
              </span>
            )}
          </div>

          {item.isSpicy && (
            <span className="px-2 py-0.5 rounded-md bg-black/75 backdrop-blur-md border border-rose-500/40 text-rose-300 text-[10px] font-semibold flex items-center gap-0.5">
              <Flame className="w-2.5 h-2.5 text-rose-400" />
              {'🌶️'.repeat(item.spicyLevel || 1)}
            </span>
          )}
        </div>

        {/* Out of Stock Overlay */}
        {!item.isAvailable && (
          <div className="absolute inset-0 bg-black/80 backdrop-blur-sm flex items-center justify-center">
            <span className="px-3 py-1.5 rounded-xl bg-rose-950/90 border border-rose-500/40 text-rose-200 text-xs font-bold uppercase tracking-wider flex items-center gap-1.5 shadow-lg">
              <Ban className="w-3.5 h-3.5 text-rose-400" /> Sold Out Tonight
            </span>
          </div>
        )}

        {/* Portion variant hint */}
        {item.portionVariants && item.portionVariants.length > 0 && (
          <div className="absolute bottom-2 right-2 px-2 py-0.5 rounded-md bg-black/75 backdrop-blur-md border border-white/10 text-[10px] text-neutral-300 font-mono">
            4 / 8 Pieces
          </div>
        )}
      </div>

      {/* Item Details */}
      <div className="p-4 flex-1 flex flex-col justify-between">
        <div>
          <div className="flex items-start justify-between gap-2">
            <h4 className="font-cinzel text-sm sm:text-base font-bold text-[#fcfaf5] group-hover:text-[#f3e5ab] transition-colors line-clamp-1">
              {item.name}
            </h4>
          </div>

          <p className="text-xs text-neutral-400 mt-1.5 line-clamp-2 leading-relaxed font-light">
            {item.description}
          </p>

          {item.servedWith && (
            <div className="text-[11px] text-[#d4af37] font-medium mt-1">
              {item.servedWith}
            </div>
          )}
        </div>

        {/* Bottom Price & Add to Cart button */}
        <div className="mt-4 pt-3 border-t border-white/10 flex items-center justify-between">
          <div>
            <div className="text-[10px] uppercase tracking-wider text-neutral-500 font-semibold">Price</div>
            <div className="font-mono text-sm sm:text-base font-bold text-[#f3e5ab]">
              Rs {item.price.toLocaleString()}
            </div>
          </div>

          <button
            onClick={() => onSelect(item)}
            disabled={!item.isAvailable}
            className={`px-3 py-1.5 rounded-xl text-xs font-bold transition-all flex items-center gap-1.5 ${
              item.isAvailable
                ? 'bg-[#182a20]/90 backdrop-blur-md hover:bg-[#d4af37] text-[#f3e5ab] hover:text-black border border-[#d4af37]/35 shadow-[0_2px_10px_rgba(0,0,0,0.3)] active:scale-95'
                : 'bg-neutral-900/60 text-neutral-600 border border-white/5 cursor-not-allowed'
            }`}
          >
            <Plus className="w-3.5 h-3.5" />
            <span>{item.portionVariants || item.proteinVariants ? 'Select Options' : 'Add'}</span>
          </button>
        </div>
      </div>
    </motion.div>
  );
};
