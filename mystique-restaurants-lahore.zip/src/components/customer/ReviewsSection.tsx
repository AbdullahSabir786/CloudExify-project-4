import React, { useState } from 'react';
import { useRestaurant } from '../../context/RestaurantContext';
import { Star, MessageSquarePlus, CheckCircle2, ThumbsUp, X, Sparkles } from 'lucide-react';
import { motion, AnimatePresence } from 'motion/react';

export const ReviewsSection: React.FC = () => {
  const { reviews, addReview, currentUser } = useRestaurant();
  const [showAddReview, setShowAddReview] = useState(false);
  const [rating, setRating] = useState(5);
  const [comment, setComment] = useState('');
  const [dishRecommended, setDishRecommended] = useState('Parmesan Chicken & Volcano Maki');
  const [reviewerName, setReviewerName] = useState(currentUser?.name || '');

  const handleSubmitReview = (e: React.FormEvent) => {
    e.preventDefault();
    if (!comment || !reviewerName) return;

    addReview({
      userName: reviewerName,
      rating,
      comment,
      dishRecommended: dishRecommended.trim() || undefined,
      verifiedVisit: true
    });

    setComment('');
    setShowAddReview(false);
  };

  return (
    <section className="py-16 px-4 sm:px-6 lg:px-8 max-w-7xl mx-auto border-t border-[#d4af37]/20">
      
      {/* Section Header */}
      <div className="flex flex-col md:flex-row md:items-end justify-between mb-10 gap-6">
        <div>
          <div className="inline-flex items-center gap-1.5 px-3.5 py-1.5 rounded-full glass-pill text-xs font-semibold text-[#f3e5ab] mb-3 shadow-sm">
            <Star className="w-3.5 h-3.5 fill-amber-400 text-amber-400" />
            <span>Google Reviews Verified • 4.6 Stars (2,008+ Ratings)</span>
          </div>
          <h2 className="font-cinzel text-2xl sm:text-3xl font-bold text-[#fcfaf5]">
            Guest Voices & <span className="gold-gradient-text">Experiences</span>
          </h2>
          <p className="text-xs sm:text-sm text-neutral-400 mt-1 max-w-xl">
            Read authentic reviews from diners who experienced Mystique's Asian wok delicacies, sushi platters, and luxury ambiance on MM Alam Road.
          </p>
        </div>

        <button
          onClick={() => setShowAddReview(true)}
          className="px-5 py-3 rounded-2xl glass-panel hover:bg-[#1a3325]/80 text-[#f3e5ab] text-xs font-bold uppercase tracking-wider shadow-md transition-all flex items-center gap-2 self-start md:self-auto"
        >
          <MessageSquarePlus className="w-4 h-4 text-[#d4af37]" />
          <span>Write a Review</span>
        </button>
      </div>

      {/* Reviews Grid */}
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6">
        {reviews.map((rev) => (
          <div
            key={rev.id}
            className="p-5 rounded-3xl glass-card flex flex-col justify-between hover:border-[#d4af37]/50 transition-all shadow-[0_8px_30px_rgba(0,0,0,0.5)]"
          >
            <div>
              {/* Star Rating & Verified */}
              <div className="flex items-center justify-between mb-3">
                <div className="flex text-amber-400">
                  {Array.from({ length: 5 }).map((_, i) => (
                    <Star
                      key={i}
                      className={`w-3.5 h-3.5 ${
                        i < rev.rating ? 'fill-amber-400 text-amber-400' : 'text-neutral-600'
                      }`}
                    />
                  ))}
                </div>
                <span className="text-[10px] text-neutral-400">{rev.date}</span>
              </div>

              {/* Comment */}
              <p className="text-xs text-neutral-300 leading-relaxed font-light italic">
                "{rev.comment}"
              </p>

              {/* Recommended Dish */}
              {rev.dishRecommended && (
                <div className="mt-3 text-[11px] text-[#f3e5ab] bg-[#121f17]/80 backdrop-blur-md px-2.5 py-1 rounded-xl border border-[#d4af37]/25 flex items-center gap-1.5">
                  <Sparkles className="w-3 h-3 text-[#d4af37] shrink-0" />
                  <span className="truncate">Favorite: {rev.dishRecommended}</span>
                </div>
              )}
            </div>

            {/* Author details */}
            <div className="mt-4 pt-3 border-t border-white/10 flex items-center justify-between">
              <div className="flex items-center gap-2.5">
                <div className={`w-8 h-8 rounded-full ${rev.avatarBg || 'bg-emerald-900'} text-[#f5f0e6] flex items-center justify-center font-bold text-xs border border-[#d4af37]/35 shadow-sm`}>
                  {rev.userName.charAt(0)}
                </div>
                <div>
                  <div className="text-xs font-semibold text-white">{rev.userName}</div>
                  <div className="text-[10px] text-neutral-400 flex items-center gap-1">
                    <CheckCircle2 className="w-3 h-3 text-emerald-400" />
                    Verified MM Alam Diner
                  </div>
                </div>
              </div>
            </div>
          </div>
        ))}
      </div>

      {/* Leave a review modal */}
      {showAddReview && (
        <AnimatePresence>
          <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/80 backdrop-blur-md">
            <motion.div
              initial={{ opacity: 0, scale: 0.95 }}
              animate={{ opacity: 1, scale: 1 }}
              exit={{ opacity: 0, scale: 0.95 }}
              className="w-full max-w-md bg-[#08120d]/90 backdrop-blur-2xl border border-[#d4af37]/45 rounded-3xl shadow-[0_20px_60px_rgba(0,0,0,0.8)] p-6 relative"
            >
              <button
                onClick={() => setShowAddReview(false)}
                className="absolute top-4 right-4 p-2 text-neutral-400 hover:text-white"
              >
                <X className="w-5 h-5" />
              </button>

              <h3 className="font-cinzel text-lg font-bold text-[#fcfaf5] mb-1">
                Share Your Experience
              </h3>
              <p className="text-xs text-neutral-400 mb-4">
                Rate your dining experience at Mystique Restaurants Lahore.
              </p>

              <form onSubmit={handleSubmitReview} className="space-y-4">
                <div>
                  <label className="block text-[11px] uppercase tracking-wider text-neutral-400 font-semibold mb-1">
                    Your Name
                  </label>
                  <input
                    type="text"
                    required
                    value={reviewerName}
                    onChange={(e) => setReviewerName(e.target.value)}
                    placeholder="e.g. Zainab Malik"
                    className="w-full px-3.5 py-2.5 glass-input rounded-xl text-xs text-white focus:outline-none"
                  />
                </div>

                <div>
                  <label className="block text-[11px] uppercase tracking-wider text-neutral-400 font-semibold mb-1">
                    Rating
                  </label>
                  <div className="flex items-center gap-2">
                    {[1, 2, 3, 4, 5].map((star) => (
                      <button
                        key={star}
                        type="button"
                        onClick={() => setRating(star)}
                        className="p-1 text-2xl transition-transform hover:scale-110"
                      >
                        <Star
                          className={`w-6 h-6 ${
                            star <= rating ? 'fill-amber-400 text-amber-400' : 'text-neutral-600'
                          }`}
                        />
                      </button>
                    ))}
                    <span className="text-xs text-amber-300 font-bold ml-2">{rating} / 5 Stars</span>
                  </div>
                </div>

                <div>
                  <label className="block text-[11px] uppercase tracking-wider text-neutral-400 font-semibold mb-1">
                    Your Review
                  </label>
                  <textarea
                    rows={3}
                    required
                    value={comment}
                    onChange={(e) => setComment(e.target.value)}
                    placeholder="Tell us about the dishes, service, and ambiance..."
                    className="w-full px-3.5 py-2 glass-input rounded-xl text-xs text-white focus:outline-none"
                  />
                </div>

                <div>
                  <label className="block text-[11px] uppercase tracking-wider text-neutral-400 font-semibold mb-1">
                    Recommended Dish (Optional)
                  </label>
                  <input
                    type="text"
                    value={dishRecommended}
                    onChange={(e) => setDishRecommended(e.target.value)}
                    placeholder="e.g. Parmesan Chicken, Matilda Cake, Gai Pad Prik"
                    className="w-full px-3.5 py-2 glass-input rounded-xl text-xs text-white focus:outline-none"
                  />
                </div>

                <button
                  type="submit"
                  className="w-full py-3 rounded-xl bg-gradient-to-r from-[#d4af37] via-[#e2c458] to-[#aa8210] text-black text-xs font-bold uppercase tracking-wider shadow-[0_4px_20px_rgba(212,175,55,0.3)] hover:brightness-110 transition-all"
                >
                  Submit Public Review
                </button>
              </form>
            </motion.div>
          </div>
        </AnimatePresence>
      )}

    </section>
  );
};
