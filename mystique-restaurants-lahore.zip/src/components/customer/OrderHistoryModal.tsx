import React from 'react';
import { useRestaurant } from '../../context/RestaurantContext';
import { Order } from '../../types';
import { X, Clock, CheckCircle2, AlertCircle, ChefHat, RotateCcw, Utensils, Sparkles } from 'lucide-react';
import { motion, AnimatePresence } from 'motion/react';

interface OrderHistoryModalProps {
  isOpen: boolean;
  onClose: () => void;
  onTrackOrder: (order: Order) => void;
}

export const OrderHistoryModal: React.FC<OrderHistoryModalProps> = ({ isOpen, onClose, onTrackOrder }) => {
  const { orders, currentUser, addToCart, setIsCartOpen } = useRestaurant();

  if (!isOpen) return null;

  // Filter orders for the user
  const userOrders = orders.filter(o => 
    currentUser ? (o.customerId === currentUser.id || o.customerEmail === currentUser.email) : true
  );

  const handleReorder = (order: Order) => {
    order.items.forEach(item => {
      addToCart(item);
    });
    onClose();
    setIsCartOpen(true);
  };

  return (
    <AnimatePresence>
      <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/80 backdrop-blur-md overflow-y-auto">
        <motion.div
          initial={{ opacity: 0, scale: 0.95, y: 15 }}
          animate={{ opacity: 1, scale: 1, y: 0 }}
          exit={{ opacity: 0, scale: 0.95, y: 15 }}
          className="w-full max-w-2xl bg-[#08120d]/90 backdrop-blur-2xl border border-[#d4af37]/40 rounded-3xl shadow-[0_20px_60px_rgba(0,0,0,0.8)] overflow-hidden my-6"
        >
          {/* Header */}
          <div className="p-5 bg-[#0e1c14]/80 backdrop-blur-xl border-b border-[#d4af37]/25 flex items-center justify-between">
            <div className="flex items-center gap-3">
              <div className="w-10 h-10 rounded-2xl bg-[#17291f]/90 border border-[#d4af37]/40 flex items-center justify-center shadow-md">
                <Clock className="w-5 h-5 text-[#d4af37]" />
              </div>
              <div>
                <h3 className="font-cinzel text-base font-bold text-white">Your Dining Order History</h3>
                <p className="text-xs text-neutral-400">
                  Logged in as: {currentUser?.name || 'Guest Diner'}
                </p>
              </div>
            </div>

            <button
              onClick={onClose}
              className="p-1.5 rounded-lg text-neutral-400 hover:text-white hover:bg-white/10 transition-colors"
            >
              <X className="w-5 h-5" />
            </button>
          </div>

          {/* Orders List */}
          <div className="p-6 space-y-4 max-h-[70vh] overflow-y-auto">
            {userOrders.length === 0 ? (
              <div className="py-12 text-center space-y-3">
                <div className="text-4xl">📜</div>
                <h4 className="font-cinzel text-base font-bold text-white">No previous orders found</h4>
                <p className="text-xs text-neutral-400 max-w-xs mx-auto">
                  When you place orders for dine-in, takeaway, or delivery, they will appear here with live receipts.
                </p>
              </div>
            ) : (
              userOrders.map((order) => (
                <div
                  key={order.id}
                  className="p-4 rounded-2xl glass-panel hover:border-[#d4af37]/50 transition-all space-y-3 shadow-md"
                >
                  <div className="flex flex-wrap items-center justify-between gap-2 border-b border-white/10 pb-2.5">
                    <div>
                      <div className="flex items-center gap-2">
                        <span className="font-mono text-xs font-bold text-[#f3e5ab] bg-[#18271e]/90 px-2.5 py-0.5 rounded-full border border-[#d4af37]/35">
                          {order.orderNumber}
                        </span>
                        <span className="text-xs text-neutral-400 capitalize">
                          • {order.orderType.replace('_', ' ')}
                        </span>
                      </div>
                      <div className="text-[10px] text-neutral-500 mt-0.5">
                        {new Date(order.createdAt).toLocaleString()}
                      </div>
                    </div>

                    {/* Status Badge */}
                    <div className="flex items-center gap-2">
                      <span className={`px-2.5 py-1 rounded-full text-[10px] font-bold uppercase tracking-wider backdrop-blur-md ${
                        order.status === 'completed'
                          ? 'bg-emerald-950/70 text-emerald-300 border border-emerald-500/40'
                          : order.status === 'cancelled'
                          ? 'bg-rose-950/70 text-rose-300 border border-rose-500/40'
                          : order.status === 'ready'
                          ? 'bg-sky-950/70 text-sky-300 border border-sky-500/40'
                          : 'bg-amber-950/70 text-amber-300 border border-amber-500/40'
                      }`}>
                        {order.status.replace('_', ' ')}
                      </span>
                    </div>
                  </div>

                  {/* Items brief */}
                  <div className="space-y-1 text-xs text-neutral-300">
                    {order.items.map((item, i) => (
                      <div key={i} className="flex justify-between">
                        <span>{item.quantity}x {item.name} {item.selectedPortion && `(${item.selectedPortion})`}</span>
                        <span className="font-mono text-neutral-400">Rs {item.totalItemPrice.toLocaleString()}</span>
                      </div>
                    ))}
                  </div>

                  {/* Footer & Reorder action */}
                  <div className="pt-2 border-t border-white/10 flex items-center justify-between text-xs">
                    <div>
                      <span className="text-neutral-400">Total: </span>
                      <span className="font-mono font-bold text-[#d4af37]">Rs {order.total.toLocaleString()}</span>
                    </div>

                    <div className="flex items-center gap-2">
                      <button
                        onClick={() => { onTrackOrder(order); onClose(); }}
                        className="px-3 py-1.5 rounded-xl bg-[#14231a]/80 hover:bg-[#1a3023] border border-[#d4af37]/35 text-[#f3e5ab] text-xs font-semibold flex items-center gap-1 transition-colors"
                      >
                        <Clock className="w-3.5 h-3.5 text-[#d4af37]" />
                        <span>Track</span>
                      </button>

                      <button
                        onClick={() => handleReorder(order)}
                        className="px-3.5 py-1.5 rounded-xl bg-gradient-to-r from-[#d4af37] to-[#b89528] text-black text-xs font-bold flex items-center gap-1 hover:brightness-110 active:scale-95 transition-all shadow-sm"
                      >
                        <RotateCcw className="w-3.5 h-3.5" />
                        <span>Reorder</span>
                      </button>
                    </div>
                  </div>
                </div>
              ))
            )}
          </div>
        </motion.div>
      </div>
    </AnimatePresence>
  );
};
