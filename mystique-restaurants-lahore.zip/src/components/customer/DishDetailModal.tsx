import React, { useState } from 'react';
import { MenuItem, OrderItem } from '../../types';
import { useRestaurant } from '../../context/RestaurantContext';
import { X, Plus, Minus, Flame, Sparkles, Clock, AlertCircle, ShoppingBag } from 'lucide-react';
import { motion, AnimatePresence } from 'motion/react';

interface DishDetailModalProps {
  item: MenuItem | null;
  onClose: () => void;
}

export const DishDetailModal: React.FC<DishDetailModalProps> = ({ item, onClose }) => {
  const { addToCart } = useRestaurant();

  if (!item) return null;

  // Selected portion variant (default to first or null)
  const [selectedPortion, setSelectedPortion] = useState<string>(
    item.portionVariants && item.portionVariants.length > 0 ? item.portionVariants[0].label : ''
  );

  // Selected protein variant (default to first or null)
  const [selectedProtein, setSelectedProtein] = useState<string>(
    item.proteinVariants && item.proteinVariants.length > 0 ? item.proteinVariants[0].label : ''
  );

  // Optional Add-on side selections
  const [selectedSides, setSelectedSides] = useState<string[]>([]);
  const [quantity, setQuantity] = useState<number>(1);
  const [specialInstructions, setSpecialInstructions] = useState<string>('');

  // Calculate Unit Price based on selected variants
  let unitPrice = item.price;

  if (item.portionVariants && selectedPortion) {
    const matched = item.portionVariants.find(p => p.label === selectedPortion);
    if (matched) unitPrice = matched.price;
  } else if (item.proteinVariants && selectedProtein) {
    const matched = item.proteinVariants.find(p => p.label === selectedProtein);
    if (matched) unitPrice = matched.price;
  }

  // Side add-on prices (e.g. +Egg Fried Rice Rs 1000)
  const availableSides = [
    { label: 'Egg Fried Rice (+Rs 1,000)', price: 1000, name: 'Egg Fried Rice' },
    { label: 'Garlic Butter Rice (+Rs 1,050)', price: 1050, name: 'Garlic Rice' },
    { label: 'Creamy Mashed Potatoes (+Rs 900)', price: 900, name: 'Mashed Potatoes' },
    { label: 'Large Fries Basket (+Rs 950)', price: 950, name: 'Large Fries' }
  ];

  const sidesPriceTotal = selectedSides.reduce((acc, sideName) => {
    const found = availableSides.find(s => s.name === sideName);
    return acc + (found ? found.price : 0);
  }, 0);

  const finalUnitPrice = unitPrice + sidesPriceTotal;
  const totalItemPrice = finalUnitPrice * quantity;

  const toggleSide = (sideName: string) => {
    if (selectedSides.includes(sideName)) {
      setSelectedSides(selectedSides.filter(s => s !== sideName));
    } else {
      setSelectedSides([...selectedSides, sideName]);
    }
  };

  const handleAddToCart = () => {
    const orderItem: OrderItem = {
      menuItemId: item.id,
      name: item.name,
      unitPrice: finalUnitPrice,
      quantity,
      selectedPortion: selectedPortion || undefined,
      selectedProtein: selectedProtein || undefined,
      selectedSides: selectedSides.length > 0 ? selectedSides : undefined,
      specialInstructions: specialInstructions.trim() || undefined,
      totalItemPrice,
      image: item.image
    };

    addToCart(orderItem);
    onClose();
  };

  return (
    <AnimatePresence>
      <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/75 backdrop-blur-md overflow-y-auto">
        <motion.div
          initial={{ opacity: 0, scale: 0.95, y: 20 }}
          animate={{ opacity: 1, scale: 1, y: 0 }}
          exit={{ opacity: 0, scale: 0.95, y: 20 }}
          className="w-full max-w-2xl bg-[#0b140f]/90 backdrop-blur-2xl border border-[#d4af37]/45 rounded-3xl shadow-[0_20px_60px_rgba(0,0,0,0.8)] overflow-hidden my-8"
        >
          {/* Header Image */}
          <div className="relative h-64 sm:h-72 w-full bg-[#080d0a]">
            <img
              src={item.image}
              alt={item.name}
              className="w-full h-full object-cover"
            />
            <div className="absolute inset-0 bg-gradient-to-t from-[#0b140f] via-transparent to-black/40" />

            {/* Close Button */}
            <button
              onClick={onClose}
              className="absolute top-4 right-4 p-2 rounded-full bg-black/70 backdrop-blur-md text-white hover:bg-black transition-colors"
            >
              <X className="w-5 h-5" />
            </button>

            {/* Badges on image */}
            <div className="absolute bottom-4 left-4 right-4 flex flex-wrap items-center justify-between gap-2">
              <div className="flex items-center gap-2">
                {item.isChefSpecial && (
                  <span className="px-2.5 py-1 rounded-full bg-[#d4af37] text-black text-[11px] font-bold uppercase tracking-wider flex items-center gap-1 shadow-md">
                    <Sparkles className="w-3 h-3" /> Chef's Special
                  </span>
                )}
                {item.isSpicy && (
                  <span className="px-2.5 py-1 rounded-full bg-rose-900/80 backdrop-blur-md text-rose-200 border border-rose-600/40 text-[11px] font-semibold flex items-center gap-1">
                    <Flame className="w-3 h-3 text-rose-400" />
                    {'🌶️'.repeat(item.spicyLevel || 1)} Spicy
                  </span>
                )}
              </div>
              <div className="flex items-center gap-1 text-xs text-neutral-300 bg-black/60 backdrop-blur-md px-3 py-1 rounded-full border border-white/10">
                <Clock className="w-3.5 h-3.5 text-[#d4af37]" />
                <span>~{item.prepTimeMinutes} mins prep</span>
              </div>
            </div>
          </div>

          {/* Body content */}
          <div className="p-6 space-y-6 max-h-[60vh] overflow-y-auto">
            {/* Title & Description */}
            <div>
              <div className="flex items-start justify-between gap-4">
                <h3 className="font-cinzel text-xl sm:text-2xl font-bold text-[#fbf8f2]">
                  {item.name}
                </h3>
                <span className="font-mono text-xl font-bold text-[#d4af37] shrink-0">
                  Rs {unitPrice.toLocaleString()}
                </span>
              </div>
              <p className="text-xs sm:text-sm text-neutral-300 mt-2 leading-relaxed font-light">
                {item.description}
              </p>
              {item.servedWith && (
                <div className="mt-2 text-xs text-[#f3e5ab] font-medium flex items-center gap-1">
                  <span>🍚</span> {item.servedWith}
                </div>
              )}
            </div>

            {/* Portion Variants (e.g. 8 Pieces vs 4 Pieces for Sushi) */}
            {item.portionVariants && item.portionVariants.length > 0 && (
              <div>
                <label className="block text-xs uppercase tracking-wider text-neutral-400 font-semibold mb-2">
                  Select Portion Size
                </label>
                <div className="grid grid-cols-2 gap-3">
                  {item.portionVariants.map((p) => (
                    <button
                      key={p.label}
                      type="button"
                      onClick={() => setSelectedPortion(p.label)}
                      className={`p-3 rounded-xl text-xs font-semibold flex items-center justify-between border transition-all ${
                        selectedPortion === p.label
                          ? 'bg-[#1a2d21]/90 border-[#d4af37] text-[#f3e5ab] shadow-[0_2px_12px_rgba(212,175,55,0.2)]'
                          : 'bg-[#101914]/60 border-white/10 text-neutral-400 hover:border-neutral-700'
                      }`}
                    >
                      <span>{p.label}</span>
                      <span className="font-mono font-bold text-[#d4af37]">Rs {p.price.toLocaleString()}</span>
                    </button>
                  ))}
                </div>
              </div>
            )}

            {/* Protein Variants (e.g. Chicken vs Prime Beef Fillet) */}
            {item.proteinVariants && item.proteinVariants.length > 0 && (
              <div>
                <label className="block text-xs uppercase tracking-wider text-neutral-400 font-semibold mb-2">
                  Select Protein Choice
                </label>
                <div className="grid grid-cols-2 gap-3">
                  {item.proteinVariants.map((pv) => (
                    <button
                      key={pv.label}
                      type="button"
                      onClick={() => setSelectedProtein(pv.label)}
                      className={`p-3 rounded-xl text-xs font-semibold flex items-center justify-between border transition-all ${
                        selectedProtein === pv.label
                          ? 'bg-[#1a2d21]/90 border-[#d4af37] text-[#f3e5ab] shadow-[0_2px_12px_rgba(212,175,55,0.2)]'
                          : 'bg-[#101914]/60 border-white/10 text-neutral-400 hover:border-neutral-700'
                      }`}
                    >
                      <span>{pv.label}</span>
                      <span className="font-mono font-bold text-[#d4af37]">Rs {pv.price.toLocaleString()}</span>
                    </button>
                  ))}
                </div>
              </div>
            )}

            {/* Add Extra Side Option */}
            <div>
              <label className="block text-xs uppercase tracking-wider text-neutral-400 font-semibold mb-2">
                Complementary Sides (Optional)
              </label>
              <div className="grid grid-cols-1 sm:grid-cols-2 gap-2">
                {availableSides.map((side) => {
                  const isChecked = selectedSides.includes(side.name);
                  return (
                    <button
                      key={side.name}
                      type="button"
                      onClick={() => toggleSide(side.name)}
                      className={`p-2.5 rounded-xl text-xs flex items-center justify-between border text-left transition-all ${
                        isChecked
                          ? 'bg-[#16271e]/90 border-[#d4af37]/70 text-[#f3e5ab] shadow-sm'
                          : 'bg-[#0f1712]/60 border-white/10 text-neutral-400 hover:border-neutral-700'
                      }`}
                    >
                      <span>{side.label}</span>
                      <span className={`w-4 h-4 rounded flex items-center justify-center text-[10px] ${
                        isChecked ? 'bg-[#d4af37] text-black font-bold' : 'border border-neutral-700'
                      }`}>
                        {isChecked ? '✓' : ''}
                      </span>
                    </button>
                  );
                })}
              </div>
            </div>

            {/* Special Instructions */}
            <div>
              <label className="block text-xs uppercase tracking-wider text-neutral-400 font-semibold mb-1">
                Special Preparation Notes for Chef
              </label>
              <input
                type="text"
                value={specialInstructions}
                onChange={(e) => setSpecialInstructions(e.target.value)}
                placeholder="e.g. Mild spice, sauce on side, extra ginger, anniversary note"
                className="w-full px-3.5 py-2.5 glass-input rounded-xl text-xs text-white placeholder:text-neutral-500 focus:outline-none"
              />
            </div>

            {/* Allergens note */}
            {item.allergens && item.allergens.length > 0 && (
              <div className="flex items-center gap-2 p-2.5 rounded-xl glass-panel text-[11px] text-neutral-400">
                <AlertCircle className="w-3.5 h-3.5 text-amber-400 shrink-0" />
                <span>Allergens: {item.allergens.join(', ')}</span>
              </div>
            )}
          </div>

          {/* Footer Action */}
          <div className="p-4 sm:p-6 bg-[#080f0a]/90 backdrop-blur-xl border-t border-[#d4af37]/20 flex flex-col sm:flex-row items-center justify-between gap-4">
            {/* Quantity Selector */}
            <div className="flex items-center gap-3 bg-[#111c15]/80 p-1.5 rounded-xl border border-white/10">
              <button
                type="button"
                onClick={() => setQuantity(Math.max(1, quantity - 1))}
                className="p-1.5 rounded-lg bg-neutral-800 text-neutral-300 hover:text-white hover:bg-neutral-700 transition-colors"
              >
                <Minus className="w-4 h-4" />
              </button>
              <span className="font-mono font-bold text-sm text-white px-2 min-w-[20px] text-center">
                {quantity}
              </span>
              <button
                type="button"
                onClick={() => setQuantity(quantity + 1)}
                className="p-1.5 rounded-lg bg-[#d4af37] text-black hover:brightness-110 transition-colors"
              >
                <Plus className="w-4 h-4" />
              </button>
            </div>

            {/* Add to Cart CTA */}
            <button
              onClick={handleAddToCart}
              className="w-full sm:w-auto flex-1 py-3 px-6 rounded-xl bg-gradient-to-r from-[#d4af37] to-[#aa8210] text-[#090f0c] text-xs font-bold uppercase tracking-wider shadow-[0_4px_20px_rgba(212,175,55,0.3)] hover:brightness-110 active:scale-98 transition-all flex items-center justify-center gap-2"
            >
              <ShoppingBag className="w-4 h-4" />
              <span>Add to Order • Rs {totalItemPrice.toLocaleString()}</span>
            </button>
          </div>
        </motion.div>
      </div>
    </AnimatePresence>
  );
};
