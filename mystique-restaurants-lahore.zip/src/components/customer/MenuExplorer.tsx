import React, { useState, useMemo } from 'react';
import { MenuItem, CategoryType } from '../../types';
import { CATEGORIES } from '../../data/initialMenu';
import { useRestaurant } from '../../context/RestaurantContext';
import { MenuItemCard } from './MenuItemCard';
import { DishDetailModal } from './DishDetailModal';
import { Search, Flame, Sparkles, SlidersHorizontal, Check } from 'lucide-react';

export const MenuExplorer: React.FC = () => {
  const { menuItems } = useRestaurant();
  
  const [selectedCategory, setSelectedCategory] = useState<CategoryType | 'all'>('all');
  const [searchQuery, setSearchQuery] = useState('');
  const [onlySpicy, setOnlySpicy] = useState(false);
  const [onlyChefSpecial, setOnlyChefSpecial] = useState(false);
  const [onlyAvailable, setOnlyAvailable] = useState(false);
  const [sortBy, setSortBy] = useState<'default' | 'price_asc' | 'price_desc'>('default');

  const [selectedDish, setSelectedDish] = useState<MenuItem | null>(null);

  // Filtered & sorted menu list
  const filteredItems = useMemo(() => {
    return menuItems.filter(item => {
      // Category filter
      if (selectedCategory !== 'all' && item.category !== selectedCategory) {
        return false;
      }
      // Search query
      if (searchQuery.trim()) {
        const q = searchQuery.toLowerCase();
        const matchName = item.name.toLowerCase().includes(q);
        const matchDesc = item.description.toLowerCase().includes(q);
        const matchCat = item.category.toLowerCase().includes(q);
        if (!matchName && !matchDesc && !matchCat) return false;
      }
      // Spicy filter
      if (onlySpicy && !item.isSpicy) return false;
      // Chef special
      if (onlyChefSpecial && !item.isChefSpecial) return false;
      // Available
      if (onlyAvailable && !item.isAvailable) return false;

      return true;
    }).sort((a, b) => {
      if (sortBy === 'price_asc') return a.price - b.price;
      if (sortBy === 'price_desc') return b.price - a.price;
      return 0;
    });
  }, [menuItems, selectedCategory, searchQuery, onlySpicy, onlyChefSpecial, onlyAvailable, sortBy]);

  return (
    <section id="restaurant-menu-section" className="py-16 px-4 sm:px-6 lg:px-8 max-w-7xl mx-auto">
      {/* Section Title */}
      <div className="text-center max-w-3xl mx-auto mb-10">
        <div className="inline-flex items-center gap-1.5 px-3.5 py-1 rounded-full glass-pill text-xs font-semibold text-[#f3e5ab] mb-3">
          <Sparkles className="w-3.5 h-3.5 text-[#d4af37]" />
          <span>Curated A La Carte Experience</span>
        </div>
        <h2 className="font-cinzel text-3xl sm:text-4xl font-bold tracking-tight text-[#fdfbf7]">
          The Mystique <span className="gold-gradient-text">Menu Collection</span>
        </h2>
        <p className="text-xs sm:text-sm text-neutral-400 mt-2 font-light">
          Prepared to order with master wok techniques, premium seafood, hand-crafted pastas, and prime cuts.
        </p>
      </div>

      {/* Category Pills Navigation */}
      <div className="flex items-center gap-2 overflow-x-auto pb-4 mb-6 scrollbar-none no-scrollbar">
        <button
          onClick={() => setSelectedCategory('all')}
          className={`shrink-0 px-4 py-2 rounded-xl text-xs font-semibold tracking-wide transition-all border ${
            selectedCategory === 'all'
              ? 'bg-gradient-to-r from-[#d4af37] to-[#aa8210] text-[#090f0c] border-[#d4af37] shadow-[0_4px_15px_rgba(212,175,55,0.3)] font-bold'
              : 'bg-[#101914]/70 backdrop-blur-md text-neutral-300 border-white/10 hover:border-[#d4af37]/40 hover:text-white'
          }`}
        >
          ✨ All Specialties ({menuItems.length})
        </button>

        {CATEGORIES.map((cat) => {
          const count = menuItems.filter(i => i.category === cat.id).length;
          const isSelected = selectedCategory === cat.id;
          return (
            <button
              key={cat.id}
              onClick={() => setSelectedCategory(cat.id)}
              className={`shrink-0 px-4 py-2 rounded-xl text-xs font-semibold tracking-wide transition-all border flex items-center gap-1.5 ${
                isSelected
                  ? 'bg-gradient-to-r from-[#d4af37] to-[#aa8210] text-[#090f0c] border-[#d4af37] shadow-[0_4px_15px_rgba(212,175,55,0.3)] font-bold'
                  : 'bg-[#101914]/70 backdrop-blur-md text-neutral-300 border-white/10 hover:border-[#d4af37]/40 hover:text-white'
              }`}
            >
              <span>{cat.icon}</span>
              <span>{cat.name}</span>
              <span className={`text-[10px] px-1.5 py-0.2 rounded-full ${
                isSelected ? 'bg-black/20 text-black font-bold' : 'bg-neutral-800 text-neutral-400'
              }`}>
                {count}
              </span>
            </button>
          );
        })}
      </div>

      {/* Search & Filter Controls Bar */}
      <div className="p-4 rounded-2xl glass-panel mb-8 flex flex-col md:flex-row items-center justify-between gap-4">
        {/* Search input */}
        <div className="relative w-full md:max-w-md">
          <Search className="w-4 h-4 text-neutral-400 absolute left-3.5 top-3" />
          <input
            type="text"
            value={searchQuery}
            onChange={(e) => setSearchQuery(e.target.value)}
            placeholder="Search dishes (e.g. Parmesan Chicken, Mystique Maki, Chili Dry)..."
            className="w-full pl-10 pr-4 py-2.5 glass-input rounded-xl text-xs text-white placeholder:text-neutral-500 focus:outline-none"
          />
          {searchQuery && (
            <button
              onClick={() => setSearchQuery('')}
              className="absolute right-3 top-2.5 text-xs text-neutral-400 hover:text-white"
            >
              Clear
            </button>
          )}
        </div>

        {/* Filter Chips & Sort */}
        <div className="flex flex-wrap items-center gap-2 w-full md:w-auto justify-start md:justify-end">
          <button
            onClick={() => setOnlyChefSpecial(!onlyChefSpecial)}
            className={`px-3 py-2 rounded-xl text-xs font-medium border flex items-center gap-1.5 transition-all backdrop-blur-md ${
              onlyChefSpecial
                ? 'bg-[#1a2d21]/90 border-[#d4af37] text-[#f3e5ab] shadow-[0_0_12px_rgba(212,175,55,0.2)]'
                : 'bg-[#101913]/60 border-white/10 text-neutral-400 hover:text-neutral-200'
            }`}
          >
            <Sparkles className="w-3.5 h-3.5 text-[#d4af37]" />
            <span>Chef's Choice</span>
            {onlyChefSpecial && <Check className="w-3 h-3 text-[#d4af37]" />}
          </button>

          <button
            onClick={() => setOnlySpicy(!onlySpicy)}
            className={`px-3 py-2 rounded-xl text-xs font-medium border flex items-center gap-1.5 transition-all backdrop-blur-md ${
              onlySpicy
                ? 'bg-[#281313]/90 border-rose-600 text-rose-200 shadow-[0_0_12px_rgba(225,29,72,0.2)]'
                : 'bg-[#101913]/60 border-white/10 text-neutral-400 hover:text-neutral-200'
            }`}
          >
            <Flame className="w-3.5 h-3.5 text-rose-400" />
            <span>Spicy Only</span>
            {onlySpicy && <Check className="w-3 h-3 text-rose-400" />}
          </button>

          {/* Sort Dropdown */}
          <div className="flex items-center gap-1.5 bg-[#121c16]/75 backdrop-blur-md border border-white/10 rounded-xl px-2.5 py-1 text-xs text-neutral-300">
            <SlidersHorizontal className="w-3.5 h-3.5 text-[#d4af37]" />
            <select
              value={sortBy}
              onChange={(e) => setSortBy(e.target.value as any)}
              className="bg-transparent text-xs text-neutral-200 focus:outline-none cursor-pointer pr-1 py-1"
            >
              <option value="default" className="bg-[#0c1410] text-white">Default Ranking</option>
              <option value="price_asc" className="bg-[#0c1410] text-white">Price: Low to High</option>
              <option value="price_desc" className="bg-[#0c1410] text-white">Price: High to Low</option>
            </select>
          </div>
        </div>
      </div>

      {/* Dishes Grid */}
      {filteredItems.length === 0 ? (
        <div className="text-center py-16 bg-[#0c1410] rounded-2xl border border-neutral-800">
          <div className="text-4xl mb-3">🔍</div>
          <h3 className="font-cinzel text-lg font-bold text-neutral-200">No dishes match your search</h3>
          <p className="text-xs text-neutral-400 mt-1">Try clearing filters or search for another keyword</p>
          <button
            onClick={() => {
              setSearchQuery('');
              setSelectedCategory('all');
              setOnlySpicy(false);
              setOnlyChefSpecial(false);
            }}
            className="mt-4 px-4 py-2 rounded-xl bg-[#17291f] text-[#f3e5ab] text-xs font-semibold border border-[#d4af37]/30 hover:bg-[#20392b]"
          >
            Reset Filters
          </button>
        </div>
      ) : (
        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 xl:grid-cols-4 gap-6">
          {filteredItems.map((item) => (
            <MenuItemCard
              key={item.id}
              item={item}
              onSelect={(selected) => setSelectedDish(selected)}
            />
          ))}
        </div>
      )}

      {/* Dish Customizer Modal */}
      {selectedDish && (
        <DishDetailModal
          item={selectedDish}
          onClose={() => setSelectedDish(null)}
        />
      )}
    </section>
  );
};
