import React, { useEffect, useState } from 'react';
import { useRestaurant } from '../../context/RestaurantContext';
import { Order, OrderStatus } from '../../types';
import { 
  X, 
  Clock, 
  ChefHat, 
  CheckCircle2, 
  Truck, 
  Phone, 
  MapPin, 
  Utensils, 
  Sparkles, 
  AlertCircle,
  RotateCcw,
  Receipt
} from 'lucide-react';
import { motion, AnimatePresence } from 'motion/react';

interface LiveOrderTrackerProps {
  isOpen: boolean;
  onClose: () => void;
}

export const LiveOrderTracker: React.FC<LiveOrderTrackerProps> = ({ isOpen, onClose }) => {
  const { activeOrder, orders, setActiveOrder, cancelOrder, currentUser } = useRestaurant();
  const [cancelReason, setCancelReason] = useState('');
  const [showCancelDialog, setShowCancelDialog] = useState(false);

  // Available orders for the user
  const userOrders = orders.filter(o => 
    currentUser ? (o.customerId === currentUser.id || o.customerEmail === currentUser.email) : true
  );

  const order = activeOrder || userOrders[0];

  if (!isOpen) return null;

  const getStepIndex = (status: OrderStatus): number => {
    switch (status) {
      case 'pending': return 1;
      case 'preparing': return 2;
      case 'ready': return 3;
      case 'out_for_delivery': return 3;
      case 'completed': return 4;
      case 'cancelled': return 0;
      default: return 1;
    }
  };

  const currentStep = order ? getStepIndex(order.status) : 1;

  const steps = [
    { num: 1, title: 'Received', desc: 'Ticket logged at MM Alam' },
    { num: 2, title: 'Preparing', desc: 'Wok & grill station cooking' },
    { num: 3, title: order?.orderType === 'delivery' ? 'On The Way' : 'Ready Plated', desc: order?.orderType === 'delivery' ? 'Courier rider en route' : 'Ready for table service' },
    { num: 4, title: 'Enjoy Feast', desc: 'Completed & Served' },
  ];

  return (
    <AnimatePresence>
      <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/80 backdrop-blur-md overflow-y-auto">
        <motion.div
          initial={{ opacity: 0, scale: 0.95, y: 15 }}
          animate={{ opacity: 1, scale: 1, y: 0 }}
          exit={{ opacity: 0, scale: 0.95, y: 15 }}
          className="w-full max-w-2xl bg-[#08120d]/90 backdrop-blur-2xl border border-[#d4af37]/40 rounded-3xl shadow-[0_20px_60px_rgba(0,0,0,0.8)] overflow-hidden my-8"
        >
          {/* Header */}
          <div className="p-5 bg-[#0e1c14]/80 backdrop-blur-xl border-b border-[#d4af37]/25 flex items-center justify-between">
            <div className="flex items-center gap-3">
              <div className="w-10 h-10 rounded-xl bg-[#182a20]/90 border border-[#d4af37]/45 flex items-center justify-center shadow-md">
                <ChefHat className="w-5 h-5 text-[#d4af37]" />
              </div>
              <div>
                <div className="flex items-center gap-2">
                  <h3 className="font-cinzel text-base font-bold text-white">Live Kitchen Tracker</h3>
                  {order && (
                    <span className="font-mono text-xs px-2.5 py-0.5 rounded-full bg-[#d4af37]/20 backdrop-blur-md text-[#f3e5ab] border border-[#d4af37]/35 font-bold">
                      {order.orderNumber}
                    </span>
                  )}
                </div>
                <p className="text-[11px] text-neutral-400">
                  Real-time status broadcast from Mystique MM Alam Rd Kitchen
                </p>
              </div>
            </div>

            <button
              onClick={onClose}
              className="p-1.5 rounded-lg text-neutral-400 hover:text-white hover:bg-white/10 transition-colors"
            >
              <X className="w-5 h-5" />
            </button>
          </div>

          {!order ? (
            <div className="p-12 text-center space-y-3">
              <div className="text-4xl">⏱️</div>
              <h4 className="font-cinzel text-base font-bold text-white">No active orders placed yet</h4>
              <p className="text-xs text-neutral-400 max-w-sm mx-auto">
                Place an order from our Asian specialties, sushi bar, or steaks to watch live cooking updates.
              </p>
              <button
                onClick={onClose}
                className="mt-2 px-5 py-2.5 rounded-xl bg-[#17291f]/80 text-[#f3e5ab] text-xs font-semibold border border-[#d4af37]/35 hover:bg-[#203a2b]"
              >
                Browse Menu
              </button>
            </div>
          ) : (
            <div className="p-6 space-y-6 max-h-[75vh] overflow-y-auto">
              
              {/* Order selector if multiple orders exist */}
              {userOrders.length > 1 && (
                <div className="flex items-center gap-2 p-2 rounded-xl glass-panel text-xs">
                  <span className="text-neutral-400 shrink-0 text-[11px]">Select Order:</span>
                  <div className="flex gap-1.5 overflow-x-auto pb-0.5">
                    {userOrders.map(o => (
                      <button
                        key={o.id}
                        onClick={() => setActiveOrder(o)}
                        className={`px-2.5 py-1 rounded-lg text-xs font-mono font-semibold transition-colors shrink-0 ${
                          o.id === order.id
                            ? 'bg-[#d4af37] text-black shadow-md'
                            : 'bg-[#121c16]/70 text-neutral-300 hover:bg-neutral-800'
                        }`}
                      >
                        {o.orderNumber} ({o.status.toUpperCase()})
                      </button>
                    ))}
                  </div>
                </div>
              )}

              {/* Status Header Banner */}
              <div className={`p-4 rounded-2xl border ${
                order.status === 'cancelled'
                  ? 'bg-rose-950/30 backdrop-blur-md border-rose-600/40 text-rose-200'
                  : order.status === 'completed'
                  ? 'bg-emerald-950/30 backdrop-blur-md border-emerald-500/40 text-emerald-200'
                  : 'bg-gradient-to-r from-[#14261d]/85 to-[#0e1a13]/85 backdrop-blur-md border-[#d4af37]/35 shadow-[0_4px_20px_rgba(212,175,55,0.1)]'
              }`}>
                <div className="flex items-center justify-between">
                  <div className="flex items-center gap-3">
                    <div className="w-10 h-10 rounded-full bg-[#1b3326]/90 border border-[#d4af37]/40 flex items-center justify-center shadow-inner">
                      {order.status === 'pending' && <Clock className="w-5 h-5 text-[#d4af37] animate-pulse" />}
                      {order.status === 'preparing' && <ChefHat className="w-5 h-5 text-amber-400 animate-bounce" />}
                      {order.status === 'ready' && <Utensils className="w-5 h-5 text-emerald-400" />}
                      {order.status === 'out_for_delivery' && <Truck className="w-5 h-5 text-sky-400" />}
                      {order.status === 'completed' && <CheckCircle2 className="w-5 h-5 text-emerald-400" />}
                      {order.status === 'cancelled' && <AlertCircle className="w-5 h-5 text-rose-400" />}
                    </div>
                    <div>
                      <div className="text-[11px] uppercase tracking-wider text-[#d4af37] font-bold">
                        Current Order Status
                      </div>
                      <h4 className="text-base font-bold text-white capitalize">
                        {order.status.replace('_', ' ')}
                      </h4>
                    </div>
                  </div>

                  <div className="text-right">
                    <div className="text-[10px] text-neutral-400 uppercase">Estimated Prep</div>
                    <div className="font-mono text-sm font-bold text-[#f3e5ab]">
                      {order.status === 'completed' ? 'Delivered' : order.status === 'cancelled' ? 'Cancelled' : `~${order.estimatedPrepMinutes} Mins`}
                    </div>
                  </div>
                </div>

                {/* Latest Timeline Note */}
                {order.statusTimeline.length > 0 && (
                  <div className="mt-3 pt-3 border-t border-white/10 text-xs text-neutral-300 flex items-start gap-2">
                    <span className="text-[#d4af37]">💬</span>
                    <span>{order.statusTimeline[order.statusTimeline.length - 1].note || 'Processing in restaurant'}</span>
                  </div>
                )}
              </div>

              {/* Visual Step Progress Bar (if not cancelled) */}
              {order.status !== 'cancelled' && (
                <div className="py-2">
                  <div className="grid grid-cols-4 gap-2 relative">
                    {/* Connecting line behind */}
                    <div className="absolute top-4 left-6 right-6 h-1 bg-neutral-800 -z-0" />
                    <div 
                      className="absolute top-4 left-6 h-1 bg-[#d4af37] transition-all duration-700 -z-0 shadow-[0_0_10px_rgba(212,175,55,0.5)]"
                      style={{ width: `${((currentStep - 1) / 3) * 100}%` }}
                    />

                    {steps.map((step) => {
                      const isDone = currentStep >= step.num;
                      const isCurrent = currentStep === step.num;
                      return (
                        <div key={step.num} className="relative z-10 flex flex-col items-center text-center">
                          <div
                            className={`w-8 h-8 rounded-full flex items-center justify-center text-xs font-bold transition-all ${
                              isCurrent
                                ? 'bg-[#d4af37] text-black ring-4 ring-[#d4af37]/30 shadow-[0_0_15px_rgba(212,175,55,0.4)]'
                                : isDone
                                ? 'bg-[#193223] text-emerald-300 border border-emerald-500 shadow-sm'
                                : 'bg-[#101813]/80 text-neutral-500 border border-white/10'
                            }`}
                          >
                            {isDone && !isCurrent ? '✓' : step.num}
                          </div>
                          <div className={`text-[11px] font-semibold mt-2 ${isCurrent ? 'text-[#f3e5ab]' : isDone ? 'text-white' : 'text-neutral-500'}`}>
                            {step.title}
                          </div>
                          <div className="text-[9px] text-neutral-400 hidden sm:block mt-0.5">
                            {step.desc}
                          </div>
                        </div>
                      );
                    })}
                  </div>
                </div>
              )}

              {/* Order Info & Receipt Items */}
              <div className="p-4 rounded-2xl glass-panel space-y-4">
                <div className="flex items-center justify-between border-b border-white/10 pb-2.5">
                  <div className="flex items-center gap-2 text-xs text-neutral-300">
                    <Receipt className="w-4 h-4 text-[#d4af37]" />
                    <span className="font-semibold">Ticket Details:</span>
                    <span className="font-mono text-neutral-400 capitalize">{order.orderType.replace('_', ' ')}</span>
                  </div>
                  <div className="text-xs text-neutral-400">
                    {order.tableNumber ? order.tableNumber : order.deliveryAddress}
                  </div>
                </div>

                <div className="space-y-2 max-h-48 overflow-y-auto pr-1">
                  {order.items.map((item, idx) => (
                    <div key={idx} className="flex items-center justify-between text-xs py-1">
                      <div>
                        <span className="font-medium text-white">{item.quantity}x {item.name}</span>
                        {item.selectedPortion && (
                          <span className="text-[10px] text-neutral-400 ml-1.5">({item.selectedPortion})</span>
                        )}
                        {item.selectedProtein && (
                          <span className="text-[10px] text-[#d4af37] ml-1">[{item.selectedProtein}]</span>
                        )}
                      </div>
                      <span className="font-mono text-neutral-300">Rs {item.totalItemPrice.toLocaleString()}</span>
                    </div>
                  ))}
                </div>

                <div className="pt-3 border-t border-white/10 flex justify-between items-center text-xs">
                  <span className="text-neutral-400">Total Charged (Incl. 16% Tax):</span>
                  <span className="font-mono text-sm font-bold text-[#d4af37]">Rs {order.total.toLocaleString()}</span>
                </div>
              </div>

              {/* Help & Support / Call Desk */}
              <div className="flex flex-col sm:flex-row items-center gap-3">
                <a
                  href="tel:03106036759"
                  className="w-full sm:flex-1 py-2.5 rounded-xl bg-[#14231a]/90 hover:bg-[#1a3024] border border-[#d4af37]/35 text-xs font-semibold text-[#f3e5ab] flex items-center justify-center gap-2 transition-colors shadow-sm"
                >
                  <Phone className="w-4 h-4 text-[#d4af37]" />
                  <span>Call MM Alam Desk (0310 6036759)</span>
                </a>

                {order.status === 'pending' && !showCancelDialog && (
                  <button
                    onClick={() => setShowCancelDialog(true)}
                    className="w-full sm:w-auto px-4 py-2.5 rounded-xl bg-rose-950/40 hover:bg-rose-900/50 border border-rose-600/30 text-rose-300 text-xs font-semibold transition-colors"
                  >
                    Cancel Order
                  </button>
                )}
              </div>

              {/* Cancellation Reason Modal inline */}
              {showCancelDialog && (
                <div className="p-4 rounded-xl bg-[#200e0e]/90 backdrop-blur-xl border border-rose-600/50 space-y-3">
                  <div className="text-xs font-bold text-rose-200">Are you sure you want to cancel this order?</div>
                  <input
                    type="text"
                    value={cancelReason}
                    onChange={(e) => setCancelReason(e.target.value)}
                    placeholder="Reason for cancellation (e.g. ordered by mistake, table plan changed)"
                    className="w-full px-3 py-2 glass-input border-rose-800 rounded-lg text-xs text-white placeholder:text-neutral-500 focus:outline-none"
                  />
                  <div className="flex gap-2 justify-end">
                    <button
                      onClick={() => setShowCancelDialog(false)}
                      className="px-3 py-1.5 rounded-lg bg-neutral-800 text-xs text-neutral-300"
                    >
                      Keep Order
                    </button>
                    <button
                      onClick={() => {
                        cancelOrder(order.id, cancelReason || 'Customer requested cancellation');
                        setShowCancelDialog(false);
                      }}
                      className="px-3 py-1.5 rounded-lg bg-rose-600 hover:bg-rose-700 text-xs text-white font-bold shadow-md"
                    >
                      Confirm Cancel
                    </button>
                  </div>
                </div>
              )}

            </div>
          )}
        </motion.div>
      </div>
    </AnimatePresence>
  );
};
