import React from 'react';
import { useRestaurant } from '../../context/RestaurantContext';
import { Sparkles, CalendarCheck, Utensils, Star, MapPin, Music, Award, ShieldCheck } from 'lucide-react';
import { motion } from 'motion/react';

interface HeroBannerProps {
  onScrollToMenu: () => void;
}

export const HeroBanner: React.FC<HeroBannerProps> = ({ onScrollToMenu }) => {
  const { setIsReservationModalOpen } = useRestaurant();

  return (
    <div className="relative overflow-hidden bg-gradient-to-b from-[#060b08]/80 via-[#0a140f]/70 to-[#050907]/90 border-b border-[#d4af37]/20 py-16 sm:py-24">
      {/* Background ambient lighting effects */}
      <div className="absolute top-1/4 left-1/2 -translate-x-1/2 -translate-y-1/2 w-[650px] h-[380px] bg-[#d4af37]/10 rounded-full blur-[100px] pointer-events-none" />
      <div className="absolute -top-10 -left-10 w-80 h-80 bg-emerald-700/15 rounded-full blur-[90px] pointer-events-none" />
      <div className="absolute bottom-0 right-10 w-96 h-96 bg-[#d4af37]/8 rounded-full blur-[100px] pointer-events-none" />

      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 relative z-10">
        <div className="grid grid-cols-1 lg:grid-cols-12 gap-12 items-center">
          
          {/* Left Hero Content */}
          <motion.div
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.6 }}
            className="lg:col-span-7 space-y-6 text-center lg:text-left"
          >
            {/* Top Eyebrow Tag */}
            <div className="inline-flex items-center gap-2 px-4 py-1.5 rounded-full glass-pill text-xs font-semibold text-[#f5e7b8] shadow-[0_2px_10px_rgba(0,0,0,0.3)]">
              <Sparkles className="w-3.5 h-3.5 text-[#d4af37]" />
              <span>Lahore's Best Multi-Cuisine Fine Dining Destination</span>
            </div>

            {/* Main Headline */}
            <h1 className="font-cinzel text-3xl sm:text-5xl lg:text-6xl font-bold tracking-tight text-[#fcfaf5] leading-[1.15]">
              An Unforgettable <br className="hidden sm:inline" />
              <span className="gold-gradient-text">Culinary Symphony</span>
            </h1>

            {/* Description */}
            <p className="text-sm sm:text-base text-neutral-300 leading-relaxed max-w-2xl mx-auto lg:mx-0 font-light">
              Experience the pinnacle of culinary artistry on MM Alam Road, Gulberg. Savor world-class 
              <strong className="text-[#f5e7b8] font-medium"> Voyage to Asia</strong> wok creations, authentic 
              <strong className="text-[#f5e7b8] font-medium"> Japanese Sushi Bar</strong>, hand-tossed 
              <strong className="text-[#f5e7b8] font-medium"> Italian Pastas</strong>, and signature 
              <strong className="text-[#f5e7b8] font-medium"> Continental Steaks</strong>.
            </p>

            {/* Highlights Chips */}
            <div className="flex flex-wrap items-center justify-center lg:justify-start gap-2.5 pt-1 text-xs">
              <span className="inline-flex items-center gap-1.5 px-3.5 py-1.5 rounded-xl glass-pill text-neutral-200">
                <Star className="w-3.5 h-3.5 fill-amber-400 text-amber-400" />
                <strong>4.6 ★</strong> (2,008+ Reviews)
              </span>
              <span className="inline-flex items-center gap-1.5 px-3.5 py-1.5 rounded-xl glass-pill text-neutral-200">
                <MapPin className="w-3.5 h-3.5 text-[#d4af37]" />
                41-A MM Alam Rd, Gulberg
              </span>
              <span className="inline-flex items-center gap-1.5 px-3.5 py-1.5 rounded-xl glass-pill text-neutral-200">
                <Music className="w-3.5 h-3.5 text-emerald-400" />
                Live Music & Private Dining
              </span>
            </div>

            {/* CTA Buttons */}
            <div className="flex flex-col sm:flex-row items-center justify-center lg:justify-start gap-4 pt-3">
              <button
                onClick={onScrollToMenu}
                className="w-full sm:w-auto px-7 py-3.5 rounded-xl bg-gradient-to-r from-[#d4af37] via-[#e2c458] to-[#aa8210] text-[#090f0c] text-xs font-bold uppercase tracking-wider shadow-[0_6px_25px_rgba(212,175,55,0.3)] hover:brightness-110 active:scale-95 transition-all flex items-center justify-center gap-2"
              >
                <Utensils className="w-4 h-4" />
                <span>Explore Full Menu & Order</span>
              </button>

              <button
                onClick={() => setIsReservationModalOpen(true)}
                className="w-full sm:w-auto px-7 py-3.5 rounded-xl bg-[#14251b]/80 hover:bg-[#1c3527] backdrop-blur-md border border-[#d4af37]/45 text-[#f3e5ab] text-xs font-bold uppercase tracking-wider shadow-[0_4px_20px_rgba(0,0,0,0.4)] transition-all flex items-center justify-center gap-2"
              >
                <CalendarCheck className="w-4 h-4 text-[#d4af37]" />
                <span>Book Table Reservation</span>
              </button>
            </div>

            {/* Pricing range note */}
            <div className="text-xs text-neutral-400 flex items-center justify-center lg:justify-start gap-3 pt-2 font-mono">
              <span>Avg: Rs 2,000 – 8,000 / person</span>
              <span>•</span>
              <span className="text-emerald-400 font-sans">Live Kitchen Sync Active</span>
            </div>
          </motion.div>

          {/* Right Featured Visual Display */}
          <motion.div
            initial={{ opacity: 0, scale: 0.95 }}
            animate={{ opacity: 1, scale: 1 }}
            transition={{ duration: 0.7, delay: 0.1 }}
            className="lg:col-span-5 relative"
          >
            <div className="relative rounded-2xl overflow-hidden border border-[#d4af37]/45 shadow-[0_12px_45px_rgba(0,0,0,0.7),0_0_25px_rgba(212,175,55,0.15)] bg-[#0b140f]/90 backdrop-blur-md">
              <img
                src="https://images.unsplash.com/photo-1544025162-d76694265947?auto=format&fit=crop&w=900&q=80"
                alt="Mystique Restaurants Lahore Fine Dining"
                className="w-full h-80 sm:h-96 object-cover hover:scale-105 transition-transform duration-700 brightness-95"
              />
              <div className="absolute inset-0 bg-gradient-to-t from-[#050907] via-transparent to-black/30" />

              {/* Floating Badge 1 - Parmesan Chicken & Sushi */}
              <div className="absolute bottom-4 left-4 right-4 p-4 rounded-2xl bg-[#09110c]/80 backdrop-blur-xl border border-white/10 shadow-[0_8px_30px_rgba(0,0,0,0.6)] flex items-center justify-between">
                <div>
                  <div className="text-[10px] uppercase tracking-wider text-[#d4af37] font-bold">Chef's Signature Selection</div>
                  <div className="text-xs font-semibold text-white">Mystique Maki & Parmesan Chicken</div>
                </div>
                <div className="text-right">
                  <div className="text-xs font-bold text-[#f3e5ab] font-mono">Fresh Daily</div>
                  <div className="text-[10px] text-emerald-400">Order Online Available</div>
                </div>
              </div>

              {/* Top Corner Badge */}
              <div className="absolute top-3 right-3 px-3 py-1 rounded-full bg-black/75 backdrop-blur-xl border border-[#d4af37]/40 text-[11px] text-amber-300 font-semibold flex items-center gap-1.5 shadow-lg">
                <Award className="w-3.5 h-3.5 text-[#d4af37]" /> MM Alam Gulberg
              </div>
            </div>
          </motion.div>

        </div>
      </div>
    </div>
  );
};
