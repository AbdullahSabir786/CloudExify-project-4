import React, { useState } from 'react';
import { useRestaurant } from '../../context/RestaurantContext';
import { 
  X, 
  Trash2, 
  Plus, 
  Minus, 
  ShoppingBag, 
  Utensils, 
  Truck, 
  Store, 
  Sparkles, 
  CreditCard, 
  Banknote, 
  Smartphone,
  ChevronRight,
  ShieldCheck
} from 'lucide-react';
import { motion, AnimatePresence } from 'motion/react';
import confetti from 'canvas-confetti';

interface CartDrawerProps {
  onOrderPlacedSuccess: (orderId: string) => void;
}

export const CartDrawer: React.FC<CartDrawerProps> = ({ onOrderPlacedSuccess }) => {
  const {
    isCartOpen,
    setIsCartOpen,
    cart,
    removeFromCart,
    updateCartQuantity,
    clearCart,
    cartSubtotal,
    cartTax,
    cartTotal,
    placeOrder,
    currentUser,
    setIsAuthModalOpen
  } = useRestaurant();

  const [orderType, setOrderType] = useState<'dine_in' | 'delivery' | 'takeaway'>('dine_in');
  const [tableNumber, setTableNumber] = useState('Table 7 (Indoor Lounge)');
  const [deliveryAddress, setDeliveryAddress] = useState(currentUser?.address || 'Gulberg III, Lahore');
  const [paymentMethod, setPaymentMethod] = useState<'cash_on_delivery' | 'card_at_counter' | 'jazzcash_easypaisa'>('card_at_counter');
  const [specialOrderNote, setSpecialOrderNote] = useState('');
  const [isSubmitting, setIsSubmitting] = useState(false);

  if (!isCartOpen) return null;

  const deliveryFee = orderType === 'delivery' ? 350 : 0;
  const grandTotal = cartTotal + deliveryFee;

  const handleCheckout = () => {
    if (cart.length === 0) return;

    setIsSubmitting(true);

    // Trigger celebration confetti
    try {
      confetti({
        particleCount: 80,
        spread: 70,
        origin: { y: 0.6 },
        colors: ['#d4af37', '#f3e5ab', '#10b981', '#ffffff']
      });
    } catch {
      // ignore
    }

    setTimeout(() => {
      const createdOrder = placeOrder({
        orderType,
        tableNumber: orderType === 'dine_in' ? tableNumber : undefined,
        deliveryAddress: orderType === 'delivery' ? deliveryAddress : undefined,
        paymentMethod,
        specialOrderNote: specialOrderNote.trim() || undefined
      });

      setIsSubmitting(false);
      onOrderPlacedSuccess(createdOrder.id);
    }, 400);
  };

  return (
    <AnimatePresence>
      <div className="fixed inset-0 z-50 flex justify-end bg-black/75 backdrop-blur-md">
        <motion.div
          initial={{ x: '100%' }}
          animate={{ x: 0 }}
          exit={{ x: '100%' }}
          transition={{ type: 'spring', damping: 25, stiffness: 200 }}
          className="w-full max-w-lg bg-[#070e0a]/90 backdrop-blur-2xl border-l border-[#d4af37]/35 h-full flex flex-col justify-between shadow-[0_0_50px_rgba(0,0,0,0.8)] overflow-hidden"
        >
          {/* Top Header */}
          <div className="p-5 bg-[#0c1812]/85 backdrop-blur-xl border-b border-[#d4af37]/20 flex items-center justify-between">
            <div className="flex items-center gap-2.5">
              <div className="w-9 h-9 rounded-xl bg-[#17291f]/90 border border-[#d4af37]/45 flex items-center justify-center shadow-sm">
                <ShoppingBag className="w-5 h-5 text-[#d4af37]" />
              </div>
              <div>
                <h3 className="font-cinzel text-base font-bold text-[#fcfaf5]">Your Dining Order</h3>
                <p className="text-[11px] text-neutral-400">
                  {cart.reduce((s, i) => s + i.quantity, 0)} items in ticket
                </p>
              </div>
            </div>

            <div className="flex items-center gap-2">
              {cart.length > 0 && (
                <button
                  onClick={clearCart}
                  className="p-1.5 text-neutral-400 hover:text-rose-400 rounded-lg hover:bg-white/5 transition-colors text-xs flex items-center gap-1"
                  title="Clear entire cart"
                >
                  <Trash2 className="w-3.5 h-3.5" />
                  <span className="text-[10px]">Clear</span>
                </button>
              )}
              <button
                onClick={() => setIsCartOpen(false)}
                className="p-1.5 rounded-lg text-neutral-400 hover:text-white hover:bg-white/10 transition-colors"
              >
                <X className="w-5 h-5" />
              </button>
            </div>
          </div>

          {/* Cart Content Area */}
          <div className="flex-1 overflow-y-auto p-5 space-y-6">
            {cart.length === 0 ? (
              <div className="py-16 text-center space-y-3">
                <div className="w-16 h-16 mx-auto rounded-full bg-[#121f18]/80 border border-white/10 flex items-center justify-center text-3xl shadow-inner">
                  🍽️
                </div>
                <h4 className="font-cinzel text-base font-bold text-neutral-200">Your order is empty</h4>
                <p className="text-xs text-neutral-400 max-w-xs mx-auto">
                  Browse our Asian wok dishes, artisan Sushi bar, and steaks to begin your order.
                </p>
                <button
                  onClick={() => setIsCartOpen(false)}
                  className="mt-2 px-5 py-2.5 rounded-xl bg-[#17291f]/80 text-[#f3e5ab] text-xs font-semibold border border-[#d4af37]/35 hover:bg-[#203a2b] shadow-sm"
                >
                  Explore Menu
                </button>
              </div>
            ) : (
              <>
                {/* Dining Mode Selector */}
                <div>
                  <label className="block text-[11px] uppercase tracking-wider text-neutral-400 font-semibold mb-2">
                    Service Experience
                  </label>
                  <div className="grid grid-cols-3 gap-2">
                    <button
                      type="button"
                      onClick={() => setOrderType('dine_in')}
                      className={`p-2.5 rounded-xl text-xs font-semibold flex flex-col items-center gap-1 border transition-all ${
                        orderType === 'dine_in'
                          ? 'bg-[#1a2d21]/90 border-[#d4af37] text-[#f3e5ab] shadow-[0_2px_12px_rgba(212,175,55,0.2)]'
                          : 'bg-[#101913]/60 border-white/10 text-neutral-400 hover:text-neutral-200'
                      }`}
                    >
                      <Utensils className="w-4 h-4 text-[#d4af37]" />
                      <span>Dine-In Table</span>
                    </button>

                    <button
                      type="button"
                      onClick={() => setOrderType('delivery')}
                      className={`p-2.5 rounded-xl text-xs font-semibold flex flex-col items-center gap-1 border transition-all ${
                        orderType === 'delivery'
                          ? 'bg-[#1a2d21]/90 border-[#d4af37] text-[#f3e5ab] shadow-[0_2px_12px_rgba(212,175,55,0.2)]'
                          : 'bg-[#101913]/60 border-white/10 text-neutral-400 hover:text-neutral-200'
                      }`}
                    >
                      <Truck className="w-4 h-4 text-[#d4af37]" />
                      <span>Delivery (+Rs 350)</span>
                    </button>

                    <button
                      type="button"
                      onClick={() => setOrderType('takeaway')}
                      className={`p-2.5 rounded-xl text-xs font-semibold flex flex-col items-center gap-1 border transition-all ${
                        orderType === 'takeaway'
                          ? 'bg-[#1a2d21]/90 border-[#d4af37] text-[#f3e5ab] shadow-[0_2px_12px_rgba(212,175,55,0.2)]'
                          : 'bg-[#101913]/60 border-white/10 text-neutral-400 hover:text-neutral-200'
                      }`}
                    >
                      <Store className="w-4 h-4 text-[#d4af37]" />
                      <span>Takeaway Pickup</span>
                    </button>
                  </div>
                </div>

                {/* Service Details (Table Number or Address) */}
                {orderType === 'dine_in' ? (
                  <div>
                    <label className="block text-[11px] uppercase tracking-wider text-neutral-400 font-semibold mb-1">
                      Table Location at MM Alam
                    </label>
                    <select
                      value={tableNumber}
                      onChange={(e) => setTableNumber(e.target.value)}
                      className="w-full px-3 py-2.5 glass-input rounded-xl text-xs text-neutral-200 focus:outline-none"
                    >
                      <option value="Table 7 (Indoor Lounge)" className="bg-[#0b140f]">Table 7 (Indoor Royal Lounge)</option>
                      <option value="Table 12 (Window Side)" className="bg-[#0b140f]">Table 12 (Window Side)</option>
                      <option value="Table 14 (Private Dining Room)" className="bg-[#0b140f]">Table 14 (Private Dining Room)</option>
                      <option value="Table 4 (MM Alam Terrace)" className="bg-[#0b140f]">Table 4 (MM Alam Terrace)</option>
                      <option value="Table 9 (Live Music Lounge)" className="bg-[#0b140f]">Table 9 (Live Music Lounge)</option>
                      <option value="Table 1 (Front Porch)" className="bg-[#0b140f]">Table 1 (Front Porch)</option>
                    </select>
                  </div>
                ) : orderType === 'delivery' ? (
                  <div>
                    <label className="block text-[11px] uppercase tracking-wider text-neutral-400 font-semibold mb-1">
                      Delivery Address in Lahore
                    </label>
                    <input
                      type="text"
                      value={deliveryAddress}
                      onChange={(e) => setDeliveryAddress(e.target.value)}
                      placeholder="e.g. House 14, Block L, Gulberg II, Lahore"
                      className="w-full px-3 py-2.5 glass-input rounded-xl text-xs text-neutral-200 focus:outline-none"
                    />
                  </div>
                ) : (
                  <div className="p-3 rounded-xl glass-panel text-xs text-neutral-300">
                    📍 Pickup at <strong>41-A MM Alam Rd, Gulberg, Lahore</strong> front service desk in ~20 minutes.
                  </div>
                )}

                {/* Items List */}
                <div className="space-y-3">
                  <div className="text-[11px] uppercase tracking-wider text-neutral-400 font-semibold">
                    Order Items ({cart.length})
                  </div>

                  {cart.map((item, idx) => (
                    <div
                      key={idx}
                      className="p-3 rounded-xl glass-card flex items-start gap-3 justify-between"
                    >
                      <div className="flex items-start gap-2.5 flex-1 min-w-0">
                        {item.image && (
                          <img
                            src={item.image}
                            alt={item.name}
                            className="w-12 h-12 rounded-lg object-cover border border-white/10 shrink-0"
                          />
                        )}
                        <div className="flex-1 min-w-0">
                          <h5 className="text-xs font-bold text-[#fcfaf5] truncate">{item.name}</h5>
                          <div className="flex flex-wrap gap-1 mt-0.5">
                            {item.selectedPortion && (
                              <span className="text-[10px] px-1.5 py-0.2 rounded bg-neutral-800 text-neutral-300">
                                {item.selectedPortion}
                              </span>
                            )}
                            {item.selectedProtein && (
                              <span className="text-[10px] px-1.5 py-0.2 rounded bg-[#18271e] text-[#f3e5ab]">
                                {item.selectedProtein}
                              </span>
                            )}
                            {item.selectedSides && item.selectedSides.map((s, si) => (
                              <span key={si} className="text-[10px] px-1.5 py-0.2 rounded bg-neutral-800 text-neutral-400">
                                +{s}
                              </span>
                            ))}
                          </div>
                          {item.specialInstructions && (
                            <div className="text-[10px] text-amber-300/80 italic mt-0.5">
                              "{item.specialInstructions}"
                            </div>
                          )}
                          <div className="font-mono text-xs text-[#d4af37] font-semibold mt-1">
                            Rs {item.totalItemPrice.toLocaleString()}
                          </div>
                        </div>
                      </div>

                      {/* Qty changer */}
                      <div className="flex items-center gap-1.5 bg-[#142018]/80 backdrop-blur-md px-1.5 py-1 rounded-lg border border-white/10 shrink-0">
                        <button
                          onClick={() => updateCartQuantity(idx, item.quantity - 1)}
                          className="p-1 text-neutral-400 hover:text-white"
                        >
                          <Minus className="w-3 h-3" />
                        </button>
                        <span className="font-mono text-xs font-bold text-white px-1">
                          {item.quantity}
                        </span>
                        <button
                          onClick={() => updateCartQuantity(idx, item.quantity + 1)}
                          className="p-1 text-[#d4af37] hover:brightness-125"
                        >
                          <Plus className="w-3 h-3" />
                        </button>
                      </div>
                    </div>
                  ))}
                </div>

                {/* Special Kitchen Notes */}
                <div>
                  <label className="block text-[11px] uppercase tracking-wider text-neutral-400 font-semibold mb-1">
                    Special Occasion or Instructions
                  </label>
                  <input
                    type="text"
                    value={specialOrderNote}
                    onChange={(e) => setSpecialOrderNote(e.target.value)}
                    placeholder="e.g. Birthday dinner, cutlery needed, ring bell"
                    className="w-full px-3 py-2 glass-input rounded-xl text-xs text-neutral-200 focus:outline-none"
                  />
                </div>

                {/* Payment Method */}
                <div>
                  <label className="block text-[11px] uppercase tracking-wider text-neutral-400 font-semibold mb-2">
                    Payment Method
                  </label>
                  <div className="grid grid-cols-3 gap-2">
                    <button
                      type="button"
                      onClick={() => setPaymentMethod('card_at_counter')}
                      className={`p-2 rounded-xl text-xs font-medium flex flex-col items-center gap-1 border transition-all ${
                        paymentMethod === 'card_at_counter'
                          ? 'bg-[#182a20]/90 border-[#d4af37] text-[#f3e5ab] shadow-sm'
                          : 'bg-[#0f1712]/60 border-white/10 text-neutral-400'
                      }`}
                    >
                      <CreditCard className="w-3.5 h-3.5" />
                      <span>Card POS</span>
                    </button>

                    <button
                      type="button"
                      onClick={() => setPaymentMethod('cash_on_delivery')}
                      className={`p-2 rounded-xl text-xs font-medium flex flex-col items-center gap-1 border transition-all ${
                        paymentMethod === 'cash_on_delivery'
                          ? 'bg-[#182a20]/90 border-[#d4af37] text-[#f3e5ab] shadow-sm'
                          : 'bg-[#0f1712]/60 border-white/10 text-neutral-400'
                      }`}
                    >
                      <Banknote className="w-3.5 h-3.5" />
                      <span>Cash</span>
                    </button>

                    <button
                      type="button"
                      onClick={() => setPaymentMethod('jazzcash_easypaisa')}
                      className={`p-2 rounded-xl text-xs font-medium flex flex-col items-center gap-1 border transition-all ${
                        paymentMethod === 'jazzcash_easypaisa'
                          ? 'bg-[#182a20]/90 border-[#d4af37] text-[#f3e5ab] shadow-sm'
                          : 'bg-[#0f1712]/60 border-white/10 text-neutral-400'
                      }`}
                    >
                      <Smartphone className="w-3.5 h-3.5" />
                      <span>JazzCash</span>
                    </button>
                  </div>
                </div>
              </>
            )}
          </div>

          {/* Bottom Billing Summary & Place Order CTA */}
          {cart.length > 0 && (
            <div className="p-5 bg-[#0a140f]/90 backdrop-blur-xl border-t border-[#d4af37]/25 space-y-3">
              <div className="space-y-1.5 text-xs text-neutral-300">
                <div className="flex justify-between">
                  <span>Subtotal</span>
                  <span className="font-mono">Rs {cartSubtotal.toLocaleString()}</span>
                </div>
                <div className="flex justify-between text-neutral-400">
                  <span>Punjab Sales Tax (16% GST)</span>
                  <span className="font-mono">Rs {cartTax.toLocaleString()}</span>
                </div>
                {orderType === 'delivery' && (
                  <div className="flex justify-between text-neutral-400">
                    <span>Gulberg Delivery Courier</span>
                    <span className="font-mono">Rs {deliveryFee}</span>
                  </div>
                )}
                <div className="pt-2 border-t border-white/10 flex justify-between text-sm font-bold text-white">
                  <span className="font-cinzel tracking-wide">Grand Total</span>
                  <span className="font-mono text-base text-[#d4af37]">Rs {grandTotal.toLocaleString()}</span>
                </div>
              </div>

              {/* Checkout Button */}
              <button
                disabled={isSubmitting}
                onClick={handleCheckout}
                className="w-full py-3.5 rounded-xl bg-gradient-to-r from-[#d4af37] via-[#e2c458] to-[#aa8210] text-[#090f0c] text-xs font-bold uppercase tracking-wider shadow-[0_6px_25px_rgba(212,175,55,0.3)] hover:brightness-110 active:scale-98 transition-all flex items-center justify-center gap-2"
              >
                {isSubmitting ? (
                  <span>Transmitting Ticket to Kitchen...</span>
                ) : (
                  <>
                    <Sparkles className="w-4 h-4" />
                    <span>Confirm Order • Rs {grandTotal.toLocaleString()}</span>
                    <ChevronRight className="w-4 h-4" />
                  </>
                )}
              </button>

              <div className="text-[10px] text-center text-neutral-500 flex items-center justify-center gap-1">
                <ShieldCheck className="w-3 h-3 text-emerald-400" />
                <span>Real-time kitchen broadcast & automated status sync enabled</span>
              </div>
            </div>
          )}
        </motion.div>
      </div>
    </AnimatePresence>
  );
};
