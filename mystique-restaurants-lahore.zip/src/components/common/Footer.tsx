import React from 'react';
import { MapPin, Phone, Clock, Star, Instagram, Globe, Sparkles, ShieldCheck } from 'lucide-react';

export const Footer: React.FC = () => {
  return (
    <footer className="bg-[#040806]/95 backdrop-blur-xl border-t border-[#d4af37]/25 pt-16 pb-12 text-neutral-400">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-10 mb-12">
          
          {/* Brand Col */}
          <div className="space-y-4">
            <div className="flex items-center gap-3">
              <div className="w-10 h-10 rounded-2xl bg-[#14231a]/90 border border-[#d4af37]/45 flex items-center justify-center shadow-md">
                <span className="font-cinzel text-lg font-bold text-[#d4af37]">M</span>
              </div>
              <span className="font-cinzel text-xl font-bold tracking-widest text-[#f8f5ee]">MYSTIQUE</span>
            </div>
            <p className="text-xs leading-relaxed text-neutral-400">
              Lahore’s premier multi-cuisine fine dining sanctuary on MM Alam Road Gulberg. Where master Thai, Japanese Sushi Bar, Italian, and gourmet Continental cuisines unite in a bespoke ambiance.
            </p>
            <div className="flex items-center gap-2 text-amber-300 font-medium text-xs glass-panel p-2.5 rounded-2xl border-[#d4af37]/25 w-fit shadow-sm">
              <Star className="w-4 h-4 fill-amber-400 text-amber-400" />
              <span>4.6 ★ Rated on Google (2,008+ Verified Reviews)</span>
            </div>
          </div>

          {/* Location & Contact */}
          <div className="space-y-4">
            <h4 className="font-cinzel text-sm font-semibold text-[#f4eee4] tracking-wider uppercase border-b border-[#d4af37]/20 pb-2">
              Lahore Location
            </h4>
            <ul className="space-y-3 text-xs">
              <li className="flex items-start gap-2.5">
                <MapPin className="w-4 h-4 text-[#d4af37] shrink-0 mt-0.5" />
                <span>41-A MM Alam Rd Block, 2 L, Block L Gulberg 2, Lahore, 54660, Pakistan</span>
              </li>
              <li className="flex items-center gap-2.5">
                <Phone className="w-4 h-4 text-[#d4af37] shrink-0" />
                <a href="tel:03106036759" className="font-mono text-neutral-200 hover:text-[#d4af37] transition-colors">
                  0310 6036759 / +92 310 6036759
                </a>
              </li>
              <li className="flex items-center gap-2.5">
                <Globe className="w-4 h-4 text-[#d4af37] shrink-0" />
                <span className="text-neutral-300">mystiquerestaurants.com</span>
              </li>
            </ul>
          </div>

          {/* Operating Hours & Dining */}
          <div className="space-y-4">
            <h4 className="font-cinzel text-sm font-semibold text-[#f4eee4] tracking-wider uppercase border-b border-[#d4af37]/20 pb-2">
              Operating Hours
            </h4>
            <div className="space-y-2.5 text-xs">
              <div className="flex items-start gap-2">
                <Clock className="w-4 h-4 text-[#d4af37] shrink-0 mt-0.5" />
                <div>
                  <div className="font-medium text-neutral-200">Lunch & Dinner Service</div>
                  <div className="text-neutral-400">Monday – Sunday: 12:00 PM – 11:30 PM</div>
                </div>
              </div>
              <div className="flex items-start gap-2">
                <Sparkles className="w-4 h-4 text-[#d4af37] shrink-0 mt-0.5" />
                <div>
                  <div className="font-medium text-neutral-200">Royal Hi-Tea & Live Music</div>
                  <div className="text-neutral-400">Daily 4:00 PM – 7:00 PM (Live Acoustic)</div>
                </div>
              </div>
              <div className="flex items-center gap-2 pt-1 text-emerald-400">
                <ShieldCheck className="w-4 h-4 text-emerald-400" />
                <span>100% Halal Certified Ingredients</span>
              </div>
            </div>
          </div>

          {/* Social & Reservation */}
          <div className="space-y-4">
            <h4 className="font-cinzel text-sm font-semibold text-[#f4eee4] tracking-wider uppercase border-b border-[#d4af37]/20 pb-2">
              Connect & Book
            </h4>
            <p className="text-xs text-neutral-400">
              Follow our culinary journey on Instagram for special guest chef events and seasonal menus.
            </p>
            <div className="flex items-center gap-3">
              <a
                href="https://instagram.com/mystiqueofficialpk"
                target="_blank"
                rel="noreferrer"
                className="flex items-center gap-2 px-3.5 py-2 rounded-2xl glass-panel hover:bg-[#1d3527]/80 text-xs text-[#f3e5ab] transition-all shadow-sm"
              >
                <Instagram className="w-4 h-4 text-[#d4af37]" />
                <span>@mystiqueofficialpk (25K+)</span>
              </a>
            </div>
            <div className="text-[11px] text-neutral-500 pt-2">
              Valet parking available on MM Alam Road front porch.
            </div>
          </div>

        </div>

        <div className="pt-8 border-t border-white/10 flex flex-col sm:flex-row items-center justify-between text-xs text-neutral-500 gap-4">
          <p>© {new Date().getFullYear()} Mystique Restaurants Lahore. All rights reserved.</p>
          <div className="flex items-center gap-6">
            <span>Fine Dining Ordering System</span>
            <span>•</span>
            <span>MM Alam Rd Gulberg II</span>
            <span>•</span>
            <span>Real-time Full Stack Architecture</span>
          </div>
        </div>
      </div>
    </footer>
  );
};
