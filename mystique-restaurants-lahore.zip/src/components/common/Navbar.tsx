import React, { useState } from 'react';
import { useRestaurant } from '../../context/RestaurantContext';
import { 
  ShoppingBag, 
  Utensils, 
  LayoutDashboard, 
  Clock, 
  CalendarCheck, 
  User as UserIcon, 
  LogOut, 
  ShieldCheck, 
  Volume2, 
  VolumeX, 
  Menu as MenuIcon, 
  X, 
  Sparkles,
  Phone,
  ChevronDown
} from 'lucide-react';

interface NavbarProps {
  onOpenOrderHistory: () => void;
  onOpenLiveTracker: () => void;
}

export const Navbar: React.FC<NavbarProps> = ({ onOpenOrderHistory, onOpenLiveTracker }) => {
  const {
    currentUser,
    activeTab,
    setActiveTab,
    cart,
    setIsCartOpen,
    setIsAuthModalOpen,
    setIsReservationModalOpen,
    logout,
    switchRole,
    activeOrder,
    soundEnabled,
    setSoundEnabled
  } = useRestaurant();

  const [mobileMenuOpen, setMobileMenuOpen] = useState(false);
  const [roleDropdownOpen, setRoleDropdownOpen] = useState(false);

  const cartItemsCount = cart.reduce((sum, i) => sum + i.quantity, 0);
  const hasActiveOrder = activeOrder && activeOrder.status !== 'completed' && activeOrder.status !== 'cancelled';

  return (
    <header className="sticky top-0 z-40 bg-[#060b08]/80 backdrop-blur-xl border-b border-[#d4af37]/20 shadow-[0_4px_30px_rgba(0,0,0,0.5)] transition-all">
      {/* Top micro announcement bar */}
      <div className="bg-gradient-to-r from-[#0a1510]/90 via-[#122319]/90 to-[#0a1510]/90 backdrop-blur-md text-xs py-1.5 px-4 border-b border-[#d4af37]/15">
        <div className="max-w-7xl mx-auto flex items-center justify-between text-neutral-300">
          <div className="flex items-center gap-3">
            <span className="inline-flex items-center gap-1 text-[#d4af37] font-medium">
              <Sparkles className="w-3.5 h-3.5" /> MM Alam Road, Gulberg, Lahore
            </span>
            <span className="hidden md:inline text-neutral-500">•</span>
            <span className="hidden md:inline text-neutral-400">Open Daily: 12:00 PM – 11:30 PM</span>
            <span className="hidden lg:inline text-neutral-500">•</span>
            <span className="hidden lg:inline text-amber-300/90 font-medium">⭐ 4.6 (2,008+ Google Reviews)</span>
          </div>

          <div className="flex items-center gap-4">
            <a href="tel:03106036759" className="flex items-center gap-1 text-neutral-300 hover:text-[#d4af37] transition-colors">
              <Phone className="w-3 h-3 text-[#d4af37]" />
              <span className="font-mono text-xs">0310 6036759</span>
            </a>

            {/* Quick Role Switcher */}
            <div className="relative">
              <button
                onClick={() => setRoleDropdownOpen(!roleDropdownOpen)}
                className="flex items-center gap-1.5 px-3 py-1 rounded-full bg-[#14231a]/80 hover:bg-[#1e3427] border border-[#d4af37]/35 text-[11px] text-[#f3e5ab] font-medium shadow-[inset_0_1px_0_rgba(255,255,255,0.1)] transition-all"
                title="Switch between Customer & Staff roles"
              >
                <ShieldCheck className="w-3.5 h-3.5 text-[#d4af37]" />
                <span>Role: {currentUser ? currentUser.role.toUpperCase() : 'GUEST'}</span>
                <ChevronDown className="w-3 h-3 text-neutral-400" />
              </button>

              {roleDropdownOpen && (
                <div 
                  className="absolute right-0 mt-1.5 w-56 rounded-2xl bg-[#0c1611]/95 backdrop-blur-xl border border-[#d4af37]/35 shadow-[0_12px_40px_rgba(0,0,0,0.7)] p-1.5 z-50 text-xs"
                  onClick={() => setRoleDropdownOpen(false)}
                >
                  <div className="px-2.5 py-1 text-[10px] uppercase tracking-wider text-neutral-400 font-semibold border-b border-white/10">
                    Switch Active Session
                  </div>
                  <button
                    onClick={() => switchRole('customer')}
                    className={`w-full text-left px-2.5 py-2 rounded-xl flex items-center justify-between transition-colors ${
                      currentUser?.role === 'customer' ? 'bg-[#182a20] text-[#f3e5ab] border border-[#d4af37]/25' : 'hover:bg-white/5 text-neutral-300'
                    }`}
                  >
                    <div>
                      <div className="font-medium">Customer View</div>
                      <div className="text-[10px] text-neutral-400">Samiya Fatima (Diner)</div>
                    </div>
                    {currentUser?.role === 'customer' && <span className="text-[#d4af37] text-xs">✓</span>}
                  </button>

                  <button
                    onClick={() => switchRole('admin')}
                    className={`w-full text-left px-2.5 py-2 rounded-xl flex items-center justify-between transition-colors ${
                      currentUser?.role === 'admin' ? 'bg-[#182a20] text-[#f3e5ab] border border-[#d4af37]/25' : 'hover:bg-white/5 text-neutral-300'
                    }`}
                  >
                    <div>
                      <div className="font-medium text-amber-200">Admin / Manager</div>
                      <div className="text-[10px] text-neutral-400">Full Dashboard & Menu</div>
                    </div>
                    {currentUser?.role === 'admin' && <span className="text-[#d4af37] text-xs">✓</span>}
                  </button>

                  <button
                    onClick={() => switchRole('staff')}
                    className={`w-full text-left px-2.5 py-2 rounded-xl flex items-center justify-between transition-colors ${
                      currentUser?.role === 'staff' ? 'bg-[#182a20] text-[#f3e5ab] border border-[#d4af37]/25' : 'hover:bg-white/5 text-neutral-300'
                    }`}
                  >
                    <div>
                      <div className="font-medium text-emerald-200">Head Chef / Kitchen</div>
                      <div className="text-[10px] text-neutral-400">Live Ticket Display</div>
                    </div>
                    {currentUser?.role === 'staff' && <span className="text-[#d4af37] text-xs">✓</span>}
                  </button>
                </div>
              )}
            </div>

            {/* Sound notification toggle */}
            <button
              onClick={() => setSoundEnabled(!soundEnabled)}
              className="text-neutral-400 hover:text-[#d4af37] p-1 rounded-lg hover:bg-white/5 transition-colors"
              title={soundEnabled ? "Audio chimes active" : "Audio muted"}
            >
              {soundEnabled ? <Volume2 className="w-3.5 h-3.5 text-[#d4af37]" /> : <VolumeX className="w-3.5 h-3.5" />}
            </button>
          </div>
        </div>
      </div>

      {/* Main Navbar */}
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="flex items-center justify-between h-20">
          
          {/* Logo & Brand Identity */}
          <div className="flex items-center gap-3 cursor-pointer" onClick={() => setActiveTab('customer')}>
            <div className="w-12 h-12 rounded-2xl bg-gradient-to-br from-[#1c3325]/90 via-[#102017]/90 to-[#08110c]/90 backdrop-blur-md border border-[#d4af37]/50 flex items-center justify-center shadow-[0_0_20px_rgba(212,175,55,0.2)]">
              <span className="font-cinzel text-xl font-bold gold-gradient-text tracking-widest">M</span>
            </div>
            <div>
              <div className="font-cinzel text-xl sm:text-2xl font-bold tracking-[0.18em] text-[#fcfaf5] flex items-center gap-2">
                MYSTIQUE
                <span className="text-[10px] tracking-normal font-sans font-semibold px-2 py-0.5 rounded-full bg-[#d4af37]/15 text-[#f3e5ab] border border-[#d4af37]/35 shadow-sm">
                  LAHORE
                </span>
              </div>
              <p className="text-[11px] tracking-widest uppercase text-neutral-400 font-light">
                Asian Fusion • Sushi Bar • Continental
              </p>
            </div>
          </div>

          {/* Center Navigation Tabs (Customer View vs Admin Panel switch) */}
          <nav className="hidden md:flex items-center p-1.5 rounded-full bg-[#0b140f]/75 backdrop-blur-xl border border-[#d4af37]/30 shadow-[inset_0_1px_1px_rgba(255,255,255,0.08)]">
            <button
              onClick={() => setActiveTab('customer')}
              className={`flex items-center gap-2 px-5 py-2 rounded-full text-xs font-semibold tracking-wide transition-all ${
                activeTab === 'customer'
                  ? 'bg-gradient-to-r from-[#d4af37] to-[#b38e22] text-[#080e0b] shadow-[0_2px_15px_rgba(212,175,55,0.3)] font-bold'
                  : 'text-neutral-300 hover:text-white hover:bg-white/5'
              }`}
            >
              <Utensils className="w-3.5 h-3.5" />
              Customer Dining
            </button>

            <button
              onClick={() => setActiveTab('admin')}
              className={`flex items-center gap-2 px-5 py-2 rounded-full text-xs font-semibold tracking-wide transition-all ${
                activeTab === 'admin'
                  ? 'bg-gradient-to-r from-[#d4af37] to-[#b38e22] text-[#080e0b] shadow-[0_2px_15px_rgba(212,175,55,0.3)] font-bold'
                  : 'text-neutral-300 hover:text-white hover:bg-white/5'
              }`}
            >
              <LayoutDashboard className="w-3.5 h-3.5" />
              Admin & Kitchen Portal
              {(currentUser?.role === 'admin' || currentUser?.role === 'staff') && (
                <span className="w-2 h-2 rounded-full bg-emerald-400 animate-ping" />
              )}
            </button>
          </nav>

          {/* Right Action buttons */}
          <div className="hidden lg:flex items-center gap-3">
            {/* Live Order Tracker Button */}
            <button
              onClick={onOpenLiveTracker}
              className={`relative flex items-center gap-2 px-3.5 py-2 rounded-xl text-xs font-medium backdrop-blur-md border transition-all ${
                hasActiveOrder
                  ? 'bg-[#192f22]/85 border-emerald-500/50 text-emerald-200 hover:bg-[#203c2b] shadow-[0_0_20px_rgba(16,185,129,0.2)]'
                  : 'bg-[#0f1a14]/70 border-white/10 text-neutral-300 hover:border-[#d4af37]/40 hover:text-white hover:bg-[#14231a]/80'
              }`}
            >
              <Clock className={`w-4 h-4 ${hasActiveOrder ? 'text-emerald-400 animate-spin' : 'text-neutral-400'}`} />
              <span>Track Order</span>
              {hasActiveOrder && (
                <span className="px-1.5 py-0.5 rounded-full bg-emerald-500 text-black text-[10px] font-bold">
                  {activeOrder.status.replace('_', ' ').toUpperCase()}
                </span>
              )}
            </button>

            {/* Table Reservation Button */}
            <button
              onClick={() => setIsReservationModalOpen(true)}
              className="flex items-center gap-2 px-4 py-2 rounded-xl text-xs font-semibold bg-[#15271d]/80 hover:bg-[#1c3327] backdrop-blur-md border border-[#d4af37]/40 text-[#f3e5ab] shadow-[0_4px_16px_rgba(0,0,0,0.3)] transition-all"
            >
              <CalendarCheck className="w-4 h-4 text-[#d4af37]" />
              <span>Reserve Table</span>
            </button>

            {/* Shopping Cart Button */}
            <button
              onClick={() => setIsCartOpen(true)}
              className="relative flex items-center gap-2.5 px-4 py-2 rounded-xl text-xs font-bold bg-gradient-to-r from-[#d4af37] to-[#aa8210] text-[#090f0c] shadow-[0_4px_20px_rgba(212,175,55,0.25)] hover:brightness-110 active:scale-95 transition-all"
            >
              <ShoppingBag className="w-4 h-4" />
              <span>Cart</span>
              {cartItemsCount > 0 && (
                <span className="w-5 h-5 rounded-full bg-[#080d0a] text-[#f3e5ab] text-[11px] flex items-center justify-center font-bold border border-[#d4af37]/40">
                  {cartItemsCount}
                </span>
              )}
            </button>

            {/* User Profile / Auth button */}
            {currentUser ? (
              <div className="flex items-center gap-2 pl-2 border-l border-white/10">
                <button
                  onClick={onOpenOrderHistory}
                  className="flex items-center gap-2 p-1.5 pr-3 rounded-xl bg-[#0f1a14]/80 backdrop-blur-md hover:bg-[#16271e] border border-white/10 hover:border-[#d4af37]/40 text-left transition-colors"
                  title="View order history"
                >
                  <img
                    src={currentUser.avatar || 'https://images.unsplash.com/photo-1534528741775-53994a69daeb?auto=format&fit=crop&w=100&q=80'}
                    alt={currentUser.name}
                    className="w-7 h-7 rounded-lg object-cover border border-[#d4af37]/40"
                  />
                  <div className="text-[11px] leading-tight">
                    <div className="font-semibold text-neutral-200 truncate max-w-[90px]">{currentUser.name.split(' ')[0]}</div>
                    <div className="text-[9px] text-[#d4af37] capitalize font-medium">{currentUser.role}</div>
                  </div>
                </button>
                <button
                  onClick={logout}
                  className="p-2 rounded-xl text-neutral-400 hover:text-rose-400 hover:bg-rose-950/30 transition-colors"
                  title="Sign out"
                >
                  <LogOut className="w-4 h-4" />
                </button>
              </div>
            ) : (
              <button
                onClick={() => setIsAuthModalOpen(true)}
                className="flex items-center gap-1.5 px-3.5 py-2 rounded-xl text-xs font-medium text-neutral-300 hover:text-white hover:bg-white/5 border border-white/10 backdrop-blur-md transition-colors"
              >
                <UserIcon className="w-4 h-4" />
                <span>Sign In</span>
              </button>
            )}
          </div>

          {/* Mobile hamburger button */}
          <div className="flex lg:hidden items-center gap-2">
            <button
              onClick={() => setIsCartOpen(true)}
              className="relative p-2 rounded-xl bg-gradient-to-r from-[#d4af37] to-[#aa8210] text-black"
            >
              <ShoppingBag className="w-5 h-5" />
              {cartItemsCount > 0 && (
                <span className="absolute -top-1.5 -right-1.5 w-5 h-5 rounded-full bg-[#080d0a] text-[#f3e5ab] text-[10px] flex items-center justify-center font-bold border border-[#d4af37]">
                  {cartItemsCount}
                </span>
              )}
            </button>
            <button
              onClick={() => setMobileMenuOpen(!mobileMenuOpen)}
              className="p-2 rounded-xl bg-[#0f1a14]/80 backdrop-blur-md border border-white/10 text-neutral-300"
            >
              {mobileMenuOpen ? <X className="w-6 h-6" /> : <MenuIcon className="w-6 h-6" />}
            </button>
          </div>

        </div>
      </div>

      {/* Mobile Drawer Menu */}
      {mobileMenuOpen && (
        <div className="lg:hidden bg-[#0a120e]/95 backdrop-blur-xl border-b border-[#d4af37]/25 px-4 py-4 space-y-3 shadow-2xl">
          <div className="grid grid-cols-2 gap-2">
            <button
              onClick={() => { setActiveTab('customer'); setMobileMenuOpen(false); }}
              className={`p-2.5 rounded-xl text-xs font-semibold flex items-center justify-center gap-2 ${
                activeTab === 'customer' ? 'bg-[#d4af37] text-black font-bold' : 'bg-[#132018]/80 text-neutral-300 border border-white/5'
              }`}
            >
              <Utensils className="w-4 h-4" /> Customer Dining
            </button>
            <button
              onClick={() => { setActiveTab('admin'); setMobileMenuOpen(false); }}
              className={`p-2.5 rounded-xl text-xs font-semibold flex items-center justify-center gap-2 ${
                activeTab === 'admin' ? 'bg-[#d4af37] text-black font-bold' : 'bg-[#132018]/80 text-neutral-300 border border-white/5'
              }`}
            >
              <LayoutDashboard className="w-4 h-4" /> Admin Portal
            </button>
          </div>

          <div className="pt-2 border-t border-white/10 space-y-2">
            <button
              onClick={() => { setIsReservationModalOpen(true); setMobileMenuOpen(false); }}
              className="w-full py-2.5 px-3 rounded-xl bg-[#17291f]/90 text-[#f3e5ab] text-xs font-semibold flex items-center gap-2 border border-[#d4af37]/35"
            >
              <CalendarCheck className="w-4 h-4 text-[#d4af37]" /> Reserve a Table at MM Alam
            </button>
            <button
              onClick={() => { onOpenLiveTracker(); setMobileMenuOpen(false); }}
              className="w-full py-2.5 px-3 rounded-xl bg-[#111a14]/80 text-neutral-200 text-xs font-semibold flex items-center justify-between border border-white/10"
            >
              <span className="flex items-center gap-2"><Clock className="w-4 h-4 text-[#d4af37]" /> Live Order Tracker</span>
              {hasActiveOrder && (
                <span className="text-[10px] px-2 py-0.5 rounded-full bg-emerald-500 text-black font-bold">
                  {activeOrder.status.toUpperCase()}
                </span>
              )}
            </button>
            <button
              onClick={() => { onOpenOrderHistory(); setMobileMenuOpen(false); }}
              className="w-full py-2.5 px-3 rounded-xl bg-[#111a14]/80 text-neutral-200 text-xs font-semibold flex items-center gap-2 border border-white/10"
            >
              <UserIcon className="w-4 h-4 text-neutral-400" /> Past Order History
            </button>
          </div>
        </div>
      )}
    </header>
  );
};
