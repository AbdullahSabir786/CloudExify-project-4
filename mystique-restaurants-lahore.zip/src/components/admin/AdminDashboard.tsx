import React, { useState } from 'react';
import { useRestaurant } from '../../context/RestaurantContext';
import { LiveOrdersKanban } from './LiveOrdersKanban';
import { MenuManager } from './MenuManager';
import { ReservationManager } from './ReservationManager';
import { AnalyticsView } from './AnalyticsView';
import { 
  ChefHat, 
  UtensilsCrossed, 
  CalendarCheck, 
  TrendingUp, 
  Radio, 
  Sparkles, 
  Volume2, 
  VolumeX, 
  ShieldCheck, 
  PlusCircle, 
  Star, 
  Store,
  Layers
} from 'lucide-react';
import { motion } from 'motion/react';

export const AdminDashboard: React.FC = () => {
  const { 
    currentUser, 
    orders, 
    reservations, 
    soundEnabled, 
    setSoundEnabled, 
    placeOrder, 
    menuItems 
  } = useRestaurant();

  const [activeAdminSubTab, setActiveAdminSubTab] = useState<'orders' | 'menu' | 'reservations' | 'analytics' | 'reviews'>('orders');

  const pendingOrdersCount = orders.filter(o => o.status === 'pending').length;
  const pendingResCount = reservations.filter(r => r.status === 'pending').length;

  // Helper to simulate an instant incoming order from a customer
  const handleSimulateIncomingOrder = () => {
    const randomDish = menuItems[Math.floor(Math.random() * menuItems.length)];
    const randomTable = Math.floor(Math.random() * 14) + 1;

    placeOrder({
      orderType: 'dine_in',
      tableNumber: `Table ${randomTable} (Royal Lounge)`,
      paymentMethod: 'card_at_counter',
      specialOrderNote: 'Guest requested extra spicy sauce and fast plating'
    });
  };

  return (
    <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8 space-y-8">
      
      {/* Top Admin Banner */}
      <div className="p-6 sm:p-8 rounded-3xl bg-gradient-to-r from-[#0a140e]/90 via-[#102017]/90 to-[#0a120e]/90 backdrop-blur-2xl border border-[#d4af37]/35 shadow-[0_15px_50px_rgba(0,0,0,0.6)] relative overflow-hidden">
        {/* Glow effect */}
        <div className="absolute top-0 right-0 w-80 h-80 bg-[#d4af37]/15 rounded-full blur-3xl pointer-events-none" />

        <div className="flex flex-col lg:flex-row lg:items-center justify-between gap-6 relative z-10">
          <div>
            <div className="flex flex-wrap items-center gap-2 mb-2">
              <span className="px-3.5 py-1 rounded-full glass-pill text-[#f3e5ab] text-xs font-bold uppercase tracking-wider flex items-center gap-1.5 shadow-sm">
                <ShieldCheck className="w-3.5 h-3.5 text-[#d4af37]" />
                <span>Admin & Kitchen Management Portal</span>
              </span>

              <span className="px-3.5 py-1 rounded-full bg-emerald-950/80 backdrop-blur-md border border-emerald-500/40 text-emerald-300 text-xs font-semibold flex items-center gap-1.5 shadow-sm">
                <Radio className="w-3.5 h-3.5 animate-pulse text-emerald-400" />
                <span>Live Supabase & Broadcast Channel Active</span>
              </span>
            </div>

            <h1 className="font-cinzel text-2xl sm:text-3xl font-bold text-white">
              Mystique MM Alam Road <span className="gold-gradient-text">Operations Suite</span>
            </h1>
            <p className="text-xs sm:text-sm text-neutral-300 mt-1 max-w-2xl font-light">
              Manage incoming wok & sushi station tickets, edit menu items & stock availability, confirm table reservations, and monitor revenue metrics.
            </p>
          </div>

          {/* Quick Action Toolbar */}
          <div className="flex flex-wrap items-center gap-3">
            {/* Audio chime toggle */}
            <button
              onClick={() => setSoundEnabled(!soundEnabled)}
              className={`px-3.5 py-2.5 rounded-2xl text-xs font-semibold border flex items-center gap-1.5 transition-all shadow-sm ${
                soundEnabled
                  ? 'bg-[#182a20]/90 backdrop-blur-md border-[#d4af37]/50 text-[#f3e5ab]'
                  : 'glass-panel text-neutral-500'
              }`}
              title="Toggle Kitchen Order Chime Notification"
            >
              {soundEnabled ? <Volume2 className="w-4 h-4 text-[#d4af37]" /> : <VolumeX className="w-4 h-4" />}
              <span>{soundEnabled ? 'Kitchen Chime ON' : 'Chime Muted'}</span>
            </button>

            {/* Test Simulation Button */}
            <button
              onClick={handleSimulateIncomingOrder}
              className="px-4 py-2.5 rounded-2xl bg-gradient-to-r from-[#d4af37] via-[#e2c458] to-[#aa8210] text-[#090f0c] text-xs font-bold uppercase tracking-wider shadow-[0_4px_20px_rgba(212,175,55,0.3)] hover:brightness-110 active:scale-95 transition-all flex items-center gap-1.5"
            >
              <PlusCircle className="w-4 h-4" />
              <span>Simulate Customer Order</span>
            </button>
          </div>
        </div>
      </div>

      {/* Navigation Sub-Tabs */}
      <div className="flex items-center gap-2 overflow-x-auto pb-2 border-b border-white/10 scrollbar-none">
        <button
          onClick={() => setActiveAdminSubTab('orders')}
          className={`px-4 py-2.5 rounded-2xl text-xs font-bold uppercase tracking-wider flex items-center gap-2 transition-all border shrink-0 ${
            activeAdminSubTab === 'orders'
              ? 'bg-[#d4af37] text-black border-[#d4af37] shadow-lg shadow-[#d4af37]/20'
              : 'glass-panel text-neutral-400 hover:text-white'
          }`}
        >
          <ChefHat className="w-4 h-4" />
          <span>Live Kitchen Kanban</span>
          {pendingOrdersCount > 0 && (
            <span className={`text-[10px] px-2 py-0.5 rounded-full font-mono ${
              activeAdminSubTab === 'orders' ? 'bg-black text-[#d4af37] font-bold' : 'bg-amber-500 text-black font-bold'
            }`}>
              {pendingOrdersCount}
            </span>
          )}
        </button>

        <button
          onClick={() => setActiveAdminSubTab('menu')}
          className={`px-4 py-2.5 rounded-2xl text-xs font-bold uppercase tracking-wider flex items-center gap-2 transition-all border shrink-0 ${
            activeAdminSubTab === 'menu'
              ? 'bg-[#d4af37] text-black border-[#d4af37] shadow-lg shadow-[#d4af37]/20'
              : 'glass-panel text-neutral-400 hover:text-white'
          }`}
        >
          <UtensilsCrossed className="w-4 h-4" />
          <span>Menu & Stock Inventory</span>
        </button>

        <button
          onClick={() => setActiveAdminSubTab('reservations')}
          className={`px-4 py-2.5 rounded-2xl text-xs font-bold uppercase tracking-wider flex items-center gap-2 transition-all border shrink-0 ${
            activeAdminSubTab === 'reservations'
              ? 'bg-[#d4af37] text-black border-[#d4af37] shadow-lg shadow-[#d4af37]/20'
              : 'glass-panel text-neutral-400 hover:text-white'
          }`}
        >
          <CalendarCheck className="w-4 h-4" />
          <span>Table Reservations</span>
          {pendingResCount > 0 && (
            <span className={`text-[10px] px-2 py-0.5 rounded-full font-mono ${
              activeAdminSubTab === 'reservations' ? 'bg-black text-[#d4af37] font-bold' : 'bg-emerald-500 text-black font-bold'
            }`}>
              {pendingResCount}
            </span>
          )}
        </button>

        <button
          onClick={() => setActiveAdminSubTab('analytics')}
          className={`px-4 py-2.5 rounded-2xl text-xs font-bold uppercase tracking-wider flex items-center gap-2 transition-all border shrink-0 ${
            activeAdminSubTab === 'analytics'
              ? 'bg-[#d4af37] text-black border-[#d4af37] shadow-lg shadow-[#d4af37]/20'
              : 'glass-panel text-neutral-400 hover:text-white'
          }`}
        >
          <TrendingUp className="w-4 h-4" />
          <span>Sales & Analytics</span>
        </button>
      </div>

      {/* Sub-Tab Views */}
      <motion.div
        key={activeAdminSubTab}
        initial={{ opacity: 0, y: 10 }}
        animate={{ opacity: 1, y: 0 }}
        transition={{ duration: 0.3 }}
      >
        {activeAdminSubTab === 'orders' && <LiveOrdersKanban />}
        {activeAdminSubTab === 'menu' && <MenuManager />}
        {activeAdminSubTab === 'reservations' && <ReservationManager />}
        {activeAdminSubTab === 'analytics' && <AnalyticsView />}
      </motion.div>

    </div>
  );
};
