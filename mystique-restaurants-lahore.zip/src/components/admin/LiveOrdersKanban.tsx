import React, { useState } from 'react';
import { useRestaurant } from '../../context/RestaurantContext';
import { Order, OrderStatus, OrderType } from '../../types';
import { 
  Clock, 
  ChefHat, 
  CheckCircle2, 
  Truck, 
  AlertCircle, 
  Flame, 
  Check, 
  X, 
  Search, 
  Filter, 
  Printer, 
  Volume2,
  Receipt,
  User,
  Phone,
  Sparkles
} from 'lucide-react';
import { motion, AnimatePresence } from 'motion/react';

export const LiveOrdersKanban: React.FC = () => {
  const { orders, updateOrderStatus, cancelOrder, soundEnabled } = useRestaurant();
  
  const [searchQuery, setSearchQuery] = useState('');
  const [filterType, setFilterType] = useState<OrderType | 'all'>('all');
  const [selectedOrderDetails, setSelectedOrderDetails] = useState<Order | null>(null);
  const [cancelModalOrder, setCancelModalOrder] = useState<Order | null>(null);
  const [cancelReasonText, setCancelReasonText] = useState('');

  // Filter orders
  const filteredOrders = orders.filter(order => {
    if (filterType !== 'all' && order.orderType !== filterType) return false;
    if (searchQuery.trim()) {
      const q = searchQuery.toLowerCase();
      const matchNum = order.orderNumber.toLowerCase().includes(q);
      const matchName = order.customerName.toLowerCase().includes(q);
      const matchPhone = order.customerPhone.includes(q);
      if (!matchNum && !matchName && !matchPhone) return false;
    }
    return true;
  });

  const pendingOrders = filteredOrders.filter(o => o.status === 'pending');
  const preparingOrders = filteredOrders.filter(o => o.status === 'preparing');
  const readyOrders = filteredOrders.filter(o => o.status === 'ready' || o.status === 'out_for_delivery');
  const completedOrders = filteredOrders.filter(o => o.status === 'completed');

  const columns: { status: OrderStatus; title: string; subtitle: string; icon: string; items: Order[]; color: string; border: string }[] = [
    {
      status: 'pending',
      title: 'Incoming Tickets',
      subtitle: 'Awaiting kitchen confirmation',
      icon: '⏳',
      items: pendingOrders,
      color: 'bg-amber-950/20 text-amber-300',
      border: 'border-amber-500/30'
    },
    {
      status: 'preparing',
      title: 'Active in Kitchen',
      subtitle: 'Wok & grill stations cooking',
      icon: '🔥',
      items: preparingOrders,
      color: 'bg-orange-950/20 text-orange-300',
      border: 'border-orange-500/30'
    },
    {
      status: 'ready',
      title: 'Ready / Plated',
      subtitle: 'Waiting server / rider pickup',
      icon: '🍽️',
      items: readyOrders,
      color: 'bg-sky-950/20 text-sky-300',
      border: 'border-sky-500/30'
    },
    {
      status: 'completed',
      title: 'Completed & Served',
      subtitle: 'Fulfilled orders',
      icon: '✅',
      items: completedOrders,
      color: 'bg-emerald-950/20 text-emerald-300',
      border: 'border-emerald-500/30'
    }
  ];

  return (
    <div className="space-y-6">
      {/* Top Search & Filter Bar */}
      <div className="flex flex-col sm:flex-row items-center justify-between gap-4 p-4 rounded-3xl glass-panel shadow-md">
        <div className="relative w-full sm:max-w-xs">
          <Search className="w-4 h-4 text-neutral-400 absolute left-3 top-3" />
          <input
            type="text"
            value={searchQuery}
            onChange={(e) => setSearchQuery(e.target.value)}
            placeholder="Search order #, customer, phone..."
            className="w-full pl-9 pr-3 py-2 glass-input rounded-xl text-xs text-white placeholder:text-neutral-500 focus:outline-none"
          />
        </div>

        <div className="flex items-center gap-2 w-full sm:w-auto overflow-x-auto pb-1 sm:pb-0">
          <span className="text-[11px] text-neutral-400 shrink-0 font-medium">Type:</span>
          {(['all', 'dine_in', 'delivery', 'takeaway'] as const).map((type) => (
            <button
              key={type}
              onClick={() => setFilterType(type)}
              className={`px-3 py-1.5 rounded-xl text-xs font-semibold uppercase tracking-wider transition-all shrink-0 ${
                filterType === type
                  ? 'bg-[#d4af37] text-black font-bold shadow-md shadow-[#d4af37]/20'
                  : 'glass-panel text-neutral-400 hover:text-white'
              }`}
            >
              {type === 'all' ? 'All Tickets' : type.replace('_', ' ')}
            </button>
          ))}
        </div>
      </div>

      {/* Kanban Board Grid */}
      <div className="grid grid-cols-1 md:grid-cols-2 xl:grid-cols-4 gap-5 items-start">
        {columns.map((col) => (
          <div
            key={col.status}
            className={`rounded-3xl glass-card border ${col.border} p-4 min-h-[500px] flex flex-col shadow-[0_8px_30px_rgba(0,0,0,0.5)]`}
          >
            {/* Column Header */}
            <div className="flex items-center justify-between pb-3 mb-3 border-b border-white/10">
              <div className="flex items-center gap-2">
                <span className="text-base">{col.icon}</span>
                <div>
                  <h4 className="text-xs font-bold uppercase tracking-wider text-[#fcfaf5]">
                    {col.title}
                  </h4>
                  <div className="text-[10px] text-neutral-400">{col.subtitle}</div>
                </div>
              </div>
              <span className={`px-2.5 py-0.5 rounded-full text-xs font-mono font-bold ${col.color} border border-current/20 backdrop-blur-md`}>
                {col.items.length}
              </span>
            </div>

            {/* Orders Cards Container */}
            <div className="space-y-3 flex-1 overflow-y-auto max-h-[650px] pr-1">
              {col.items.length === 0 ? (
                <div className="text-center py-12 text-neutral-600 text-xs italic">
                  No orders in this stage
                </div>
              ) : (
                col.items.map((order) => (
                  <motion.div
                    key={order.id}
                    layout
                    initial={{ opacity: 0, scale: 0.95 }}
                    animate={{ opacity: 1, scale: 1 }}
                    className="p-3.5 rounded-2xl glass-panel hover:border-[#d4af37]/50 transition-all shadow-md space-y-2.5"
                  >
                    {/* Top Row: Ticket Number & Type */}
                    <div className="flex items-center justify-between">
                      <div className="flex items-center gap-1.5">
                        <span className="font-mono text-xs font-bold text-[#d4af37] bg-[#18271e]/90 px-2 py-0.5 rounded-lg border border-[#d4af37]/35 shadow-sm">
                          {order.orderNumber}
                        </span>
                        <span className="text-[10px] uppercase font-semibold text-neutral-300 px-2 py-0.5 rounded-lg bg-neutral-800/80 border border-neutral-700/50">
                          {order.orderType.replace('_', ' ')}
                        </span>
                      </div>
                      <span className="text-[10px] text-neutral-400 font-mono">
                        {order.statusTimeline[order.statusTimeline.length - 1]?.timestamp || 'Recent'}
                      </span>
                    </div>

                    {/* Customer & Location */}
                    <div className="text-xs">
                      <div className="font-semibold text-white truncate flex items-center justify-between">
                        <span>{order.customerName}</span>
                        <span className="font-mono text-xs text-[#f3e5ab] font-bold">Rs {order.total.toLocaleString()}</span>
                      </div>
                      <div className="text-[11px] text-neutral-400 mt-0.5 flex items-center gap-1 truncate">
                        {order.tableNumber ? (
                          <span className="text-[#d4af37] font-medium">📍 {order.tableNumber}</span>
                        ) : order.deliveryAddress ? (
                          <span className="text-sky-300 truncate">🚚 {order.deliveryAddress}</span>
                        ) : (
                          <span className="text-amber-300">🛍️ Takeaway Front Desk</span>
                        )}
                      </div>
                    </div>

                    {/* Items Summary */}
                    <div className="p-2.5 rounded-xl bg-[#080e0a]/80 border border-white/5 space-y-1 text-xs backdrop-blur-sm">
                      {order.items.map((item, idx) => (
                        <div key={idx} className="flex justify-between text-[11px]">
                          <span className="text-neutral-200 truncate">
                            <strong>{item.quantity}x</strong> {item.name}
                            {item.selectedPortion && <span className="text-neutral-400"> ({item.selectedPortion})</span>}
                            {item.selectedProtein && <span className="text-[#d4af37]"> [{item.selectedProtein}]</span>}
                          </span>
                        </div>
                      ))}

                      {order.specialOrderNote && (
                        <div className="pt-1 text-[10px] text-amber-300/90 italic border-t border-white/5">
                          Note: "{order.specialOrderNote}"
                        </div>
                      )}
                    </div>

                    {/* Action Status Controls */}
                    <div className="pt-1 flex items-center gap-1.5">
                      {order.status === 'pending' && (
                        <button
                          onClick={() => updateOrderStatus(order.id, 'preparing', 'Head Chef accepted ticket and fired up wok')}
                          className="flex-1 py-1.5 rounded-xl bg-orange-600 hover:bg-orange-500 text-white text-[11px] font-bold flex items-center justify-center gap-1 transition-all shadow-sm active:scale-95"
                        >
                          <Flame className="w-3.5 h-3.5" />
                          <span>Accept & Cook</span>
                        </button>
                      )}

                      {order.status === 'preparing' && (
                        <button
                          onClick={() => updateOrderStatus(order.id, 'ready', 'Plated and ready at service counter')}
                          className="flex-1 py-1.5 rounded-xl bg-sky-600 hover:bg-sky-500 text-white text-[11px] font-bold flex items-center justify-center gap-1 transition-all shadow-sm active:scale-95"
                        >
                          <Check className="w-3.5 h-3.5" />
                          <span>Mark Plated & Ready</span>
                        </button>
                      )}

                      {(order.status === 'ready' || order.status === 'out_for_delivery') && (
                        <button
                          onClick={() => updateOrderStatus(order.id, 'completed', 'Served to table / courier delivered')}
                          className="flex-1 py-1.5 rounded-xl bg-emerald-600 hover:bg-emerald-500 text-white text-[11px] font-bold flex items-center justify-center gap-1 transition-all shadow-sm active:scale-95"
                        >
                          <CheckCircle2 className="w-3.5 h-3.5" />
                          <span>Complete & Settle</span>
                        </button>
                      )}

                      {/* Detail modal opener */}
                      <button
                        onClick={() => setSelectedOrderDetails(order)}
                        className="px-2 py-1.5 rounded-xl glass-panel hover:bg-[#1e3428]/80 text-neutral-300 text-[11px]"
                        title="View full receipt"
                      >
                        <Receipt className="w-3.5 h-3.5 text-[#d4af37]" />
                      </button>

                      {/* Cancel option */}
                      {order.status !== 'completed' && order.status !== 'cancelled' && (
                        <button
                          onClick={() => setCancelModalOrder(order)}
                          className="px-2 py-1.5 rounded-xl bg-rose-950/40 hover:bg-rose-900/60 text-rose-300 text-[11px] border border-rose-800/40"
                          title="Cancel ticket"
                        >
                          <X className="w-3.5 h-3.5" />
                        </button>
                      )}
                    </div>
                  </motion.div>
                ))
              )}
            </div>
          </div>
        ))}
      </div>

      {/* Order Detail Modal */}
      {selectedOrderDetails && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/80 backdrop-blur-md">
          <div className="w-full max-w-md bg-[#08120d]/90 backdrop-blur-2xl border border-[#d4af37]/45 rounded-3xl p-6 shadow-[0_20px_60px_rgba(0,0,0,0.8)] space-y-4">
            <div className="flex items-center justify-between border-b border-white/10 pb-3">
              <div>
                <h4 className="font-cinzel text-base font-bold text-white">
                  Ticket {selectedOrderDetails.orderNumber}
                </h4>
                <div className="text-xs text-neutral-400">
                  {new Date(selectedOrderDetails.createdAt).toLocaleString()}
                </div>
              </div>
              <button
                onClick={() => setSelectedOrderDetails(null)}
                className="p-1 rounded-xl text-neutral-400 hover:text-white"
              >
                <X className="w-5 h-5" />
              </button>
            </div>

            <div className="space-y-2 text-xs">
              <div className="flex justify-between">
                <span className="text-neutral-400">Customer:</span>
                <span className="font-bold text-white">{selectedOrderDetails.customerName}</span>
              </div>
              <div className="flex justify-between">
                <span className="text-neutral-400">Phone:</span>
                <span className="font-mono text-white">{selectedOrderDetails.customerPhone}</span>
              </div>
              <div className="flex justify-between">
                <span className="text-neutral-400">Service:</span>
                <span className="text-[#f3e5ab] capitalize font-medium">{selectedOrderDetails.orderType.replace('_', ' ')}</span>
              </div>
              {selectedOrderDetails.tableNumber && (
                <div className="flex justify-between">
                  <span className="text-neutral-400">Location:</span>
                  <span className="text-[#d4af37] font-bold">{selectedOrderDetails.tableNumber}</span>
                </div>
              )}
              {selectedOrderDetails.deliveryAddress && (
                <div className="flex justify-between">
                  <span className="text-neutral-400">Address:</span>
                  <span className="text-sky-300 font-medium">{selectedOrderDetails.deliveryAddress}</span>
                </div>
              )}
            </div>

            {/* Items itemization */}
            <div className="p-3 rounded-2xl bg-[#080e0a]/80 border border-white/10 space-y-2 backdrop-blur-sm">
              <div className="text-[10px] uppercase font-bold tracking-wider text-neutral-400">
                Dishes Breakdown
              </div>
              {selectedOrderDetails.items.map((item, idx) => (
                <div key={idx} className="flex justify-between text-xs">
                  <div>
                    <span className="font-semibold text-white">{item.quantity}x {item.name}</span>
                    {item.selectedPortion && <span className="text-neutral-400 text-[10px]"> ({item.selectedPortion})</span>}
                    {item.selectedProtein && <span className="text-[#d4af37] text-[10px]"> [{item.selectedProtein}]</span>}
                  </div>
                  <span className="font-mono text-neutral-300">Rs {item.totalItemPrice.toLocaleString()}</span>
                </div>
              ))}
            </div>

            {/* Billing total */}
            <div className="pt-2 border-t border-white/10 space-y-1 text-xs">
              <div className="flex justify-between text-neutral-400">
                <span>Subtotal:</span>
                <span className="font-mono">Rs {selectedOrderDetails.subtotal.toLocaleString()}</span>
              </div>
              <div className="flex justify-between text-neutral-400">
                <span>PRA Tax (16% GST):</span>
                <span className="font-mono">Rs {selectedOrderDetails.tax.toLocaleString()}</span>
              </div>
              <div className="flex justify-between text-sm font-bold text-white pt-1">
                <span>Total Ticket:</span>
                <span className="font-mono text-[#d4af37]">Rs {selectedOrderDetails.total.toLocaleString()}</span>
              </div>
            </div>

            <button
              onClick={() => setSelectedOrderDetails(null)}
              className="w-full py-2.5 rounded-xl bg-gradient-to-r from-[#d4af37] via-[#e2c458] to-[#aa8210] text-black text-xs font-bold uppercase tracking-wider shadow-md hover:brightness-110 transition-all"
            >
              Close Ticket
            </button>
          </div>
        </div>
      )}

      {/* Cancel Order Confirmation Modal */}
      {cancelModalOrder && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/80 backdrop-blur-md">
          <div className="w-full max-w-md bg-[#160b0b]/90 backdrop-blur-2xl border border-rose-600/50 rounded-3xl p-6 shadow-2xl space-y-4">
            <h4 className="font-cinzel text-base font-bold text-rose-200">
              Cancel Order {cancelModalOrder.orderNumber}?
            </h4>
            <p className="text-xs text-neutral-300">
              Please specify the cancellation reason for the customer record:
            </p>
            <input
              type="text"
              value={cancelReasonText}
              onChange={(e) => setCancelReasonText(e.target.value)}
              placeholder="e.g. Out of ingredients, diner requested change, duplicate ticket"
              className="w-full px-3 py-2 bg-[#0d0606] border border-rose-800 rounded-xl text-xs text-white placeholder:text-neutral-500 focus:outline-none"
            />
            <div className="flex gap-2 justify-end pt-2">
              <button
                onClick={() => setCancelModalOrder(null)}
                className="px-4 py-2 rounded-xl glass-panel text-xs text-neutral-300"
              >
                Back
              </button>
              <button
                onClick={() => {
                  cancelOrder(cancelModalOrder.id, cancelReasonText || 'Cancelled by Kitchen Staff');
                  setCancelModalOrder(null);
                  setCancelReasonText('');
                }}
                className="px-4 py-2 rounded-xl bg-rose-600 hover:bg-rose-700 text-xs font-bold text-white shadow-lg transition-all"
              >
                Confirm Cancellation
              </button>
            </div>
          </div>
        </div>
      )}
    </div>
  );
};
