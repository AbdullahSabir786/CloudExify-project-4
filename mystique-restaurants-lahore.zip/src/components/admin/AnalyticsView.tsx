import React from 'react';
import { useRestaurant } from '../../context/RestaurantContext';
import { 
  TrendingUp, 
  DollarSign, 
  ShoppingBag, 
  Users, 
  Award, 
  PieChart, 
  Sparkles,
  ArrowUpRight,
  Receipt
} from 'lucide-react';

export const AnalyticsView: React.FC = () => {
  const { orders, menuItems, reservations } = useRestaurant();

  // Metrics computation
  const completedOrders = orders.filter(o => o.status === 'completed');
  const activeOrders = orders.filter(o => o.status !== 'cancelled' && o.status !== 'completed');

  const totalRevenue = orders
    .filter(o => o.status !== 'cancelled')
    .reduce((sum, o) => sum + o.total, 0);

  const averageTicket = orders.length > 0 ? Math.round(totalRevenue / orders.filter(o => o.status !== 'cancelled').length) : 0;

  // Compute top sold dishes
  const dishSalesMap: { [name: string]: { count: number; revenue: number } } = {};

  orders.forEach(order => {
    if (order.status !== 'cancelled') {
      order.items.forEach(item => {
        if (!dishSalesMap[item.name]) {
          dishSalesMap[item.name] = { count: 0, revenue: 0 };
        }
        dishSalesMap[item.name].count += item.quantity;
        dishSalesMap[item.name].revenue += item.totalItemPrice;
      });
    }
  });

  const sortedBestSellers = Object.entries(dishSalesMap)
    .sort((a, b) => b[1].count - a[1].count)
    .slice(0, 5);

  // Dine-in vs Takeaway vs Delivery breakdown
  const dineInCount = orders.filter(o => o.orderType === 'dine_in').length;
  const deliveryCount = orders.filter(o => o.orderType === 'delivery').length;
  const takeawayCount = orders.filter(o => o.orderType === 'takeaway').length;
  const totalOrdersCount = orders.length || 1;

  return (
    <div className="space-y-6">
      
      {/* Top 4 Metric KPI Cards */}
      <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-4">
        <div className="p-5 rounded-3xl glass-card border-[#d4af37]/35 shadow-[0_8px_30px_rgba(0,0,0,0.5)] space-y-2">
          <div className="flex items-center justify-between text-xs text-neutral-400">
            <span>Gross Sales Revenue</span>
            <div className="p-2 rounded-2xl glass-panel text-[#d4af37]">
              <DollarSign className="w-4 h-4" />
            </div>
          </div>
          <div className="font-mono text-2xl font-bold text-[#fcfaf5]">
            Rs {totalRevenue.toLocaleString()}
          </div>
          <div className="text-[11px] text-emerald-400 flex items-center gap-1">
            <ArrowUpRight className="w-3.5 h-3.5" />
            <span>Real-time POS & Online tickets</span>
          </div>
        </div>

        <div className="p-5 rounded-3xl glass-card shadow-[0_8px_30px_rgba(0,0,0,0.5)] space-y-2">
          <div className="flex items-center justify-between text-xs text-neutral-400">
            <span>Total Orders Logged</span>
            <div className="p-2 rounded-2xl glass-panel text-sky-400">
              <ShoppingBag className="w-4 h-4" />
            </div>
          </div>
          <div className="font-mono text-2xl font-bold text-[#fcfaf5]">
            {orders.length} Tickets
          </div>
          <div className="text-[11px] text-neutral-400">
            {activeOrders.length} active in kitchen workflow
          </div>
        </div>

        <div className="p-5 rounded-3xl glass-card shadow-[0_8px_30px_rgba(0,0,0,0.5)] space-y-2">
          <div className="flex items-center justify-between text-xs text-neutral-400">
            <span>Average Ticket Size</span>
            <div className="p-2 rounded-2xl glass-panel text-amber-400">
              <Receipt className="w-4 h-4" />
            </div>
          </div>
          <div className="font-mono text-2xl font-bold text-[#f3e5ab]">
            Rs {averageTicket.toLocaleString()}
          </div>
          <div className="text-[11px] text-neutral-400">
            Per party / delivery dispatch
          </div>
        </div>

        <div className="p-5 rounded-3xl glass-card shadow-[0_8px_30px_rgba(0,0,0,0.5)] space-y-2">
          <div className="flex items-center justify-between text-xs text-neutral-400">
            <span>Guest Reservations</span>
            <div className="p-2 rounded-2xl glass-panel text-emerald-400">
              <Users className="w-4 h-4" />
            </div>
          </div>
          <div className="font-mono text-2xl font-bold text-[#fcfaf5]">
            {reservations.length} Bookings
          </div>
          <div className="text-[11px] text-emerald-400">
            MM Alam Main Lounge & VIP
          </div>
        </div>
      </div>

      {/* Grid: Bestsellers + Order Type Breakdown */}
      <div className="grid grid-cols-1 lg:grid-cols-12 gap-6">
        
        {/* Bestselling Dishes */}
        <div className="lg:col-span-7 p-6 rounded-3xl glass-card border-[#d4af37]/25 shadow-[0_8px_30px_rgba(0,0,0,0.5)] space-y-4">
          <div className="flex items-center justify-between">
            <div>
              <h4 className="font-cinzel text-base font-bold text-white flex items-center gap-2">
                <Award className="w-4 h-4 text-[#d4af37]" />
                <span>Top Selling Culinary Specialties</span>
              </h4>
              <p className="text-xs text-neutral-400">Highest volume dishes ordered today</p>
            </div>
          </div>

          <div className="space-y-3">
            {sortedBestSellers.map(([name, data], idx) => (
              <div
                key={name}
                className="p-3.5 rounded-2xl glass-panel flex items-center justify-between hover:border-[#d4af37]/40 transition-colors"
              >
                <div className="flex items-center gap-3">
                  <span className="w-6 h-6 rounded-full bg-[#18271e]/80 backdrop-blur-sm text-[#d4af37] text-xs font-bold font-mono flex items-center justify-center border border-[#d4af37]/35 shadow-sm">
                    #{idx + 1}
                  </span>
                  <div>
                    <div className="font-semibold text-xs text-white">{name}</div>
                    <div className="text-[10px] text-neutral-400">{data.count} units ordered</div>
                  </div>
                </div>

                <div className="text-right">
                  <div className="font-mono font-bold text-xs text-[#f3e5ab]">
                    Rs {data.revenue.toLocaleString()}
                  </div>
                  <div className="text-[10px] text-emerald-400">High Demand</div>
                </div>
              </div>
            ))}
          </div>
        </div>

        {/* Order Channel Distribution */}
        <div className="lg:col-span-5 p-6 rounded-3xl glass-card border-[#d4af37]/25 shadow-[0_8px_30px_rgba(0,0,0,0.5)] space-y-5">
          <div>
            <h4 className="font-cinzel text-base font-bold text-white flex items-center gap-2">
              <PieChart className="w-4 h-4 text-[#d4af37]" />
              <span>Service Distribution</span>
            </h4>
            <p className="text-xs text-neutral-400">Dine-in vs Delivery vs Takeaway</p>
          </div>

          {/* Progress Bars */}
          <div className="space-y-4 text-xs">
            <div>
              <div className="flex justify-between mb-1.5 font-medium">
                <span className="text-neutral-200">🍽️ Dine-In (Table Service)</span>
                <span className="font-mono text-[#d4af37]">
                  {Math.round((dineInCount / totalOrdersCount) * 100)}% ({dineInCount})
                </span>
              </div>
              <div className="h-2 w-full bg-white/5 rounded-full overflow-hidden border border-white/5">
                <div
                  className="h-full bg-gradient-to-r from-[#d4af37] via-[#e2c458] to-[#aa8210]"
                  style={{ width: `${(dineInCount / totalOrdersCount) * 100}%` }}
                />
              </div>
            </div>

            <div>
              <div className="flex justify-between mb-1.5 font-medium">
                <span className="text-neutral-200">🚚 Gulberg Delivery</span>
                <span className="font-mono text-sky-400">
                  {Math.round((deliveryCount / totalOrdersCount) * 100)}% ({deliveryCount})
                </span>
              </div>
              <div className="h-2 w-full bg-white/5 rounded-full overflow-hidden border border-white/5">
                <div
                  className="h-full bg-sky-500"
                  style={{ width: `${(deliveryCount / totalOrdersCount) * 100}%` }}
                />
              </div>
            </div>

            <div>
              <div className="flex justify-between mb-1.5 font-medium">
                <span className="text-neutral-200">🛍️ Takeaway Counter</span>
                <span className="font-mono text-emerald-400">
                  {Math.round((takeawayCount / totalOrdersCount) * 100)}% ({takeawayCount})
                </span>
              </div>
              <div className="h-2 w-full bg-white/5 rounded-full overflow-hidden border border-white/5">
                <div
                  className="h-full bg-emerald-500"
                  style={{ width: `${(takeawayCount / totalOrdersCount) * 100}%` }}
                />
              </div>
            </div>
          </div>

          {/* Lahore Location footnote */}
          <div className="p-3 rounded-2xl glass-panel text-[11px] text-neutral-400 flex items-center gap-2">
            <span className="text-[#d4af37]">📍</span>
            <span>MM Alam Road Gulberg Branch POS & Online Synchronized</span>
          </div>
        </div>

      </div>
    </div>
  );
};
