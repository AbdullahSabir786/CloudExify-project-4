import React, { useState } from 'react';
import { useRestaurant } from '../../context/RestaurantContext';
import { MenuItem, CategoryType } from '../../types';
import { CATEGORIES } from '../../data/initialMenu';
import { 
  Plus, 
  Search, 
  Edit3, 
  Trash2, 
  Check, 
  X, 
  Sparkles, 
  Flame, 
  Eye, 
  EyeOff, 
  SlidersHorizontal,
  DollarSign
} from 'lucide-react';
import { motion, AnimatePresence } from 'motion/react';

export const MenuManager: React.FC = () => {
  const { menuItems, addMenuItem, updateMenuItem, deleteMenuItem, toggleItemAvailability } = useRestaurant();

  const [searchQuery, setSearchQuery] = useState('');
  const [selectedCategory, setSelectedCategory] = useState<CategoryType | 'all'>('all');
  const [isAddModalOpen, setIsAddModalOpen] = useState(false);
  const [editingItem, setEditingItem] = useState<MenuItem | null>(null);

  // New item form state
  const [name, setName] = useState('');
  const [category, setCategory] = useState<CategoryType>('voyage_to_asia');
  const [description, setDescription] = useState('');
  const [price, setPrice] = useState(2500);
  const [isChefSpecial, setIsChefSpecial] = useState(false);
  const [isSpicy, setIsSpicy] = useState(false);
  const [spicyLevel, setSpicyLevel] = useState(1);
  const [image, setImage] = useState('https://images.unsplash.com/photo-1544025162-d76694265947?auto=format&fit=crop&w=800&q=80');
  const [prepTimeMinutes, setPrepTimeMinutes] = useState(20);
  const [servedWith, setServedWith] = useState('Served with Steamed Rice');

  // Filtered menu
  const filtered = menuItems.filter(item => {
    if (selectedCategory !== 'all' && item.category !== selectedCategory) return false;
    if (searchQuery.trim()) {
      const q = searchQuery.toLowerCase();
      if (!item.name.toLowerCase().includes(q) && !item.description.toLowerCase().includes(q)) {
        return false;
      }
    }
    return true;
  });

  const handleSaveNewItem = (e: React.FormEvent) => {
    e.preventDefault();
    if (!name || !price) return;

    addMenuItem({
      name,
      category,
      description,
      price: Number(price),
      isChefSpecial,
      isSpicy,
      spicyLevel: isSpicy ? spicyLevel : 0,
      isAvailable: true,
      image: image || 'https://images.unsplash.com/photo-1544025162-d76694265947?auto=format&fit=crop&w=800&q=80',
      prepTimeMinutes: Number(prepTimeMinutes) || 20,
      servedWith: servedWith.trim() || undefined
    });

    // Reset & close
    setName('');
    setDescription('');
    setPrice(2500);
    setIsAddModalOpen(false);
  };

  const handleUpdateItem = (e: React.FormEvent) => {
    e.preventDefault();
    if (!editingItem) return;

    updateMenuItem(editingItem.id, editingItem);
    setEditingItem(null);
  };

  return (
    <div className="space-y-6">
      {/* Top Header & Add Dish button */}
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4 p-5 rounded-3xl glass-panel shadow-md">
        <div>
          <h3 className="font-cinzel text-lg font-bold text-[#fcfaf5]">
            Menu Catalog & Inventory Control
          </h3>
          <p className="text-xs text-neutral-400">
            Total {menuItems.length} active culinary creations across 8 categories
          </p>
        </div>

        <button
          onClick={() => setIsAddModalOpen(true)}
          className="px-4 py-2.5 rounded-2xl bg-gradient-to-r from-[#d4af37] via-[#e2c458] to-[#aa8210] text-[#090f0c] text-xs font-bold uppercase tracking-wider shadow-[0_4px_20px_rgba(212,175,55,0.3)] flex items-center justify-center gap-1.5 hover:brightness-110 active:scale-95 transition-all self-start sm:self-auto"
        >
          <Plus className="w-4 h-4" />
          <span>Add New Dish</span>
        </button>
      </div>

      {/* Filter & Search Bar */}
      <div className="flex flex-col md:flex-row items-center justify-between gap-4">
        <div className="relative w-full md:max-w-xs">
          <Search className="w-4 h-4 text-neutral-400 absolute left-3 top-3" />
          <input
            type="text"
            value={searchQuery}
            onChange={(e) => setSearchQuery(e.target.value)}
            placeholder="Search menu items..."
            className="w-full pl-9 pr-3 py-2 glass-input rounded-xl text-xs text-white placeholder:text-neutral-500 focus:outline-none"
          />
        </div>

        {/* Category Pill selector */}
        <div className="flex items-center gap-2 overflow-x-auto w-full md:w-auto pb-1 md:pb-0 scrollbar-none">
          <button
            onClick={() => setSelectedCategory('all')}
            className={`px-3.5 py-1.5 rounded-xl text-xs font-semibold shrink-0 border transition-all ${
              selectedCategory === 'all'
                ? 'bg-[#d4af37] text-black border-[#d4af37] shadow-md shadow-[#d4af37]/20 font-bold'
                : 'glass-panel text-neutral-400 hover:text-white'
            }`}
          >
            All ({menuItems.length})
          </button>
          {CATEGORIES.map(cat => (
            <button
              key={cat.id}
              onClick={() => setSelectedCategory(cat.id)}
              className={`px-3.5 py-1.5 rounded-xl text-xs font-semibold shrink-0 border transition-all ${
                selectedCategory === cat.id
                  ? 'bg-[#d4af37] text-black border-[#d4af37] shadow-md shadow-[#d4af37]/20 font-bold'
                  : 'glass-panel text-neutral-400 hover:text-white'
              }`}
            >
              {cat.icon} {cat.name}
            </button>
          ))}
        </div>
      </div>

      {/* Menu Table / List */}
      <div className="rounded-3xl glass-card overflow-hidden shadow-[0_8px_30px_rgba(0,0,0,0.5)]">
        <div className="overflow-x-auto">
          <table className="w-full text-left text-xs text-neutral-300">
            <thead className="bg-[#0e1913]/90 backdrop-blur-md text-[11px] uppercase tracking-wider text-neutral-400 border-b border-white/10">
              <tr>
                <th className="p-3.5">Dish</th>
                <th className="p-3.5">Category</th>
                <th className="p-3.5">Price (PKR)</th>
                <th className="p-3.5">Stock Status</th>
                <th className="p-3.5">Attributes</th>
                <th className="p-3.5 text-right">Actions</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-white/5">
              {filtered.map((item) => (
                <tr key={item.id} className="hover:bg-[#101a14]/60 transition-colors">
                  {/* Dish Name & Thumbnail */}
                  <td className="p-3.5 flex items-center gap-3">
                    <img
                      src={item.image}
                      alt={item.name}
                      className="w-10 h-10 rounded-xl object-cover border border-[#d4af37]/30 shadow-sm shrink-0"
                    />
                    <div>
                      <div className="font-bold text-white line-clamp-1">{item.name}</div>
                      <div className="text-[10px] text-neutral-400 line-clamp-1 max-w-xs">{item.description}</div>
                    </div>
                  </td>

                  {/* Category */}
                  <td className="p-3.5">
                    <span className="capitalize px-2.5 py-1 rounded-lg glass-panel text-[10px] text-[#f3e5ab] font-medium">
                      {item.category.replace(/_/g, ' ')}
                    </span>
                  </td>

                  {/* Price */}
                  <td className="p-3.5 font-mono font-bold text-[#f3e5ab]">
                    Rs {item.price.toLocaleString()}
                  </td>

                  {/* Stock Availability Toggle Switch */}
                  <td className="p-3.5">
                    <button
                      onClick={() => toggleItemAvailability(item.id)}
                      className={`px-3 py-1 rounded-full text-[10px] font-bold uppercase tracking-wider flex items-center gap-1.5 transition-all shadow-sm ${
                        item.isAvailable
                          ? 'bg-emerald-950/80 backdrop-blur-md text-emerald-300 border border-emerald-500/40 hover:bg-emerald-900/80'
                          : 'bg-rose-950/80 backdrop-blur-md text-rose-300 border border-rose-500/40 hover:bg-rose-900/80'
                      }`}
                    >
                      {item.isAvailable ? (
                        <>
                          <Eye className="w-3 h-3 text-emerald-400" />
                          <span>In Stock</span>
                        </>
                      ) : (
                        <>
                          <EyeOff className="w-3 h-3 text-rose-400" />
                          <span>Sold Out</span>
                        </>
                      )}
                    </button>
                  </td>

                  {/* Attributes */}
                  <td className="p-3.5">
                    <div className="flex items-center gap-1.5">
                      {item.isChefSpecial && (
                        <span className="text-[10px] px-2 py-0.5 rounded-full bg-[#d4af37]/20 text-[#f3e5ab] border border-[#d4af37]/35 font-semibold">
                          Chef
                        </span>
                      )}
                      {item.isSpicy && (
                        <span className="text-[10px] text-rose-400 font-semibold px-1.5 py-0.5 rounded bg-rose-950/40 border border-rose-800/40">
                          🌶️ {item.spicyLevel}
                        </span>
                      )}
                      {item.portionVariants && (
                        <span className="text-[10px] text-neutral-400 px-1.5 py-0.5 rounded bg-white/5 border border-white/10">
                          {item.portionVariants.length} Sizes
                        </span>
                      )}
                    </div>
                  </td>

                  {/* Actions */}
                  <td className="p-3.5 text-right space-x-1">
                    <button
                      onClick={() => setEditingItem(item)}
                      className="p-1.5 rounded-xl glass-panel hover:bg-[#1d3527]/80 text-neutral-300 hover:text-white transition-colors"
                      title="Edit dish"
                    >
                      <Edit3 className="w-3.5 h-3.5 text-[#d4af37]" />
                    </button>
                    <button
                      onClick={() => {
                        if (confirm(`Remove ${item.name} from menu?`)) {
                          deleteMenuItem(item.id);
                        }
                      }}
                      className="p-1.5 rounded-xl bg-rose-950/40 hover:bg-rose-900/60 text-rose-400 border border-rose-800/40 transition-colors"
                      title="Delete dish"
                    >
                      <Trash2 className="w-3.5 h-3.5" />
                    </button>
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      </div>

      {/* Add Dish Modal */}
      {isAddModalOpen && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/80 backdrop-blur-md">
          <div className="w-full max-w-lg bg-[#08120d]/90 backdrop-blur-2xl border border-[#d4af37]/45 rounded-3xl p-6 shadow-[0_20px_60px_rgba(0,0,0,0.8)] space-y-4 max-h-[85vh] overflow-y-auto">
            <div className="flex items-center justify-between border-b border-white/10 pb-3">
              <h4 className="font-cinzel text-base font-bold text-white">Add New Menu Creation</h4>
              <button onClick={() => setIsAddModalOpen(false)} className="text-neutral-400 hover:text-white">
                <X className="w-5 h-5" />
              </button>
            </div>

            <form onSubmit={handleSaveNewItem} className="space-y-3.5 text-xs">
              <div>
                <label className="block text-[11px] uppercase font-semibold text-neutral-400 mb-1">Dish Name</label>
                <input
                  type="text"
                  required
                  value={name}
                  onChange={(e) => setName(e.target.value)}
                  placeholder="e.g. Crispy Honey Wasabi Prawns"
                  className="w-full px-3 py-2 glass-input rounded-xl text-white focus:outline-none"
                />
              </div>

              <div className="grid grid-cols-2 gap-3">
                <div>
                  <label className="block text-[11px] uppercase font-semibold text-neutral-400 mb-1">Category</label>
                  <select
                    value={category}
                    onChange={(e) => setCategory(e.target.value as CategoryType)}
                    className="w-full px-3 py-2 glass-input rounded-xl text-white focus:outline-none"
                  >
                    {CATEGORIES.map(c => (
                      <option key={c.id} value={c.id} className="bg-[#0d1612]">{c.name}</option>
                    ))}
                  </select>
                </div>

                <div>
                  <label className="block text-[11px] uppercase font-semibold text-neutral-400 mb-1">Base Price (PKR)</label>
                  <input
                    type="number"
                    required
                    value={price}
                    onChange={(e) => setPrice(Number(e.target.value))}
                    className="w-full px-3 py-2 glass-input rounded-xl text-white font-mono focus:outline-none"
                  />
                </div>
              </div>

              <div>
                <label className="block text-[11px] uppercase font-semibold text-neutral-400 mb-1">Description</label>
                <textarea
                  rows={2}
                  value={description}
                  onChange={(e) => setDescription(e.target.value)}
                  placeholder="Ingredients, culinary notes, and taste profile..."
                  className="w-full px-3 py-2 glass-input rounded-xl text-white focus:outline-none"
                />
              </div>

              <div>
                <label className="block text-[11px] uppercase font-semibold text-neutral-400 mb-1">Image URL</label>
                <input
                  type="url"
                  value={image}
                  onChange={(e) => setImage(e.target.value)}
                  className="w-full px-3 py-2 glass-input rounded-xl text-white focus:outline-none"
                />
              </div>

              <div className="grid grid-cols-2 gap-3">
                <label className="flex items-center gap-2 p-2.5 rounded-2xl glass-panel cursor-pointer">
                  <input
                    type="checkbox"
                    checked={isChefSpecial}
                    onChange={(e) => setIsChefSpecial(e.target.checked)}
                    className="rounded text-[#d4af37]"
                  />
                  <span className="text-white font-medium">Chef's Special</span>
                </label>

                <label className="flex items-center gap-2 p-2.5 rounded-2xl glass-panel cursor-pointer">
                  <input
                    type="checkbox"
                    checked={isSpicy}
                    onChange={(e) => setIsSpicy(e.target.checked)}
                    className="rounded text-rose-500"
                  />
                  <span className="text-white font-medium">Spicy Dish 🌶️</span>
                </label>
              </div>

              <div className="flex gap-2 pt-2">
                <button
                  type="button"
                  onClick={() => setIsAddModalOpen(false)}
                  className="w-full py-2.5 rounded-xl glass-panel text-neutral-300 font-semibold"
                >
                  Cancel
                </button>
                <button
                  type="submit"
                  className="w-full py-2.5 rounded-xl bg-gradient-to-r from-[#d4af37] via-[#e2c458] to-[#aa8210] text-black font-bold uppercase tracking-wider shadow-[0_4px_20px_rgba(212,175,55,0.3)] hover:brightness-110 transition-all"
                >
                  Publish to Menu
                </button>
              </div>
            </form>
          </div>
        </div>
      )}

      {/* Edit Dish Modal */}
      {editingItem && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/80 backdrop-blur-md">
          <div className="w-full max-w-lg bg-[#08120d]/90 backdrop-blur-2xl border border-[#d4af37]/45 rounded-3xl p-6 shadow-[0_20px_60px_rgba(0,0,0,0.8)] space-y-4 max-h-[85vh] overflow-y-auto">
            <div className="flex items-center justify-between border-b border-white/10 pb-3">
              <h4 className="font-cinzel text-base font-bold text-white">Edit: {editingItem.name}</h4>
              <button onClick={() => setEditingItem(null)} className="text-neutral-400 hover:text-white">
                <X className="w-5 h-5" />
              </button>
            </div>

            <form onSubmit={handleUpdateItem} className="space-y-3.5 text-xs">
              <div>
                <label className="block text-[11px] uppercase font-semibold text-neutral-400 mb-1">Dish Name</label>
                <input
                  type="text"
                  required
                  value={editingItem.name}
                  onChange={(e) => setEditingItem({ ...editingItem, name: e.target.value })}
                  className="w-full px-3 py-2 glass-input rounded-xl text-white focus:outline-none"
                />
              </div>

              <div className="grid grid-cols-2 gap-3">
                <div>
                  <label className="block text-[11px] uppercase font-semibold text-neutral-400 mb-1">Price (PKR)</label>
                  <input
                    type="number"
                    required
                    value={editingItem.price}
                    onChange={(e) => setEditingItem({ ...editingItem, price: Number(e.target.value) })}
                    className="w-full px-3 py-2 glass-input rounded-xl text-white font-mono focus:outline-none"
                  />
                </div>

                <div>
                  <label className="block text-[11px] uppercase font-semibold text-neutral-400 mb-1">Prep Time (Mins)</label>
                  <input
                    type="number"
                    value={editingItem.prepTimeMinutes}
                    onChange={(e) => setEditingItem({ ...editingItem, prepTimeMinutes: Number(e.target.value) })}
                    className="w-full px-3 py-2 glass-input rounded-xl text-white focus:outline-none"
                  />
                </div>
              </div>

              <div>
                <label className="block text-[11px] uppercase font-semibold text-neutral-400 mb-1">Description</label>
                <textarea
                  rows={2}
                  value={editingItem.description}
                  onChange={(e) => setEditingItem({ ...editingItem, description: e.target.value })}
                  className="w-full px-3 py-2 glass-input rounded-xl text-white focus:outline-none"
                />
              </div>

              <div className="flex gap-2 pt-2">
                <button
                  type="button"
                  onClick={() => setEditingItem(null)}
                  className="w-full py-2.5 rounded-xl glass-panel text-neutral-300 font-semibold"
                >
                  Cancel
                </button>
                <button
                  type="submit"
                  className="w-full py-2.5 rounded-xl bg-gradient-to-r from-[#d4af37] via-[#e2c458] to-[#aa8210] text-black font-bold uppercase tracking-wider shadow-[0_4px_20px_rgba(212,175,55,0.3)] hover:brightness-110 transition-all"
                >
                  Save Changes
                </button>
              </div>
            </form>
          </div>
        </div>
      )}
    </div>
  );
};
