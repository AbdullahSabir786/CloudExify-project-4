import React, { useState } from 'react';
import { useRestaurant } from '../../context/RestaurantContext';
import { Reservation, ReservationStatus } from '../../types';
import { 
  CalendarCheck, 
  Users, 
  Clock, 
  MapPin, 
  CheckCircle2, 
  XCircle, 
  Phone, 
  Mail, 
  Search,
  Check,
  X,
  Sparkles
} from 'lucide-react';
import { motion } from 'motion/react';

export const ReservationManager: React.FC = () => {
  const { reservations, updateReservationStatus } = useRestaurant();

  const [searchQuery, setSearchQuery] = useState('');
  const [filterStatus, setFilterStatus] = useState<ReservationStatus | 'all'>('all');
  const [assignedTableNumber, setAssignedTableNumber] = useState<{ [id: string]: string }>({});

  const filtered = reservations.filter(res => {
    if (filterStatus !== 'all' && res.status !== filterStatus) return false;
    if (searchQuery.trim()) {
      const q = searchQuery.toLowerCase();
      if (!res.customerName.toLowerCase().includes(q) && !res.customerPhone.includes(q)) {
        return false;
      }
    }
    return true;
  });

  const pendingCount = reservations.filter(r => r.status === 'pending').length;
  const confirmedCount = reservations.filter(r => r.status === 'confirmed').length;

  return (
    <div className="space-y-6">
      {/* Top Header */}
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4 p-5 rounded-3xl glass-panel shadow-md">
        <div>
          <h3 className="font-cinzel text-lg font-bold text-[#fcfaf5]">
            Table Booking & Guest Concierge
          </h3>
          <p className="text-xs text-neutral-400">
            {pendingCount} new table requests awaiting approval • {confirmedCount} confirmed bookings
          </p>
        </div>

        <div className="flex items-center gap-2">
          <span className="px-3.5 py-1.5 rounded-2xl glass-pill text-[#f3e5ab] text-xs font-semibold shadow-sm">
            🏛️ MM Alam Main Dining & VIP Suites
          </span>
        </div>
      </div>

      {/* Filter & Search */}
      <div className="flex flex-col sm:flex-row items-center justify-between gap-4">
        <div className="relative w-full sm:max-w-xs">
          <Search className="w-4 h-4 text-neutral-400 absolute left-3 top-3" />
          <input
            type="text"
            value={searchQuery}
            onChange={(e) => setSearchQuery(e.target.value)}
            placeholder="Search guest name, phone..."
            className="w-full pl-9 pr-3 py-2 glass-input rounded-xl text-xs text-white placeholder:text-neutral-500 focus:outline-none"
          />
        </div>

        <div className="flex items-center gap-2 w-full sm:w-auto overflow-x-auto pb-1 sm:pb-0 scrollbar-none">
          {(['all', 'pending', 'confirmed', 'completed', 'cancelled'] as const).map((status) => (
            <button
              key={status}
              onClick={() => setFilterStatus(status)}
              className={`px-3.5 py-1.5 rounded-xl text-xs font-semibold uppercase tracking-wider transition-all shrink-0 ${
                filterStatus === status
                  ? 'bg-[#d4af37] text-black font-bold shadow-md shadow-[#d4af37]/20'
                  : 'glass-panel text-neutral-400 hover:text-white'
              }`}
            >
              {status === 'all' ? 'All Requests' : status}
            </button>
          ))}
        </div>
      </div>

      {/* Reservations Table / Cards */}
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-5">
        {filtered.length === 0 ? (
          <div className="col-span-full py-16 text-center glass-card rounded-3xl text-neutral-500 text-xs">
            No reservation records found for this filter
          </div>
        ) : (
          filtered.map((res) => (
            <motion.div
              key={res.id}
              layout
              className="p-5 rounded-3xl glass-card hover:border-[#d4af37]/50 transition-all shadow-[0_8px_30px_rgba(0,0,0,0.5)] space-y-4"
            >
              {/* Header */}
              <div className="flex items-start justify-between">
                <div>
                  <h4 className="text-sm font-bold text-white flex items-center gap-1.5">
                    <span>{res.customerName}</span>
                  </h4>
                  <div className="text-xs text-[#d4af37] font-semibold mt-0.5">
                    {res.diningArea}
                  </div>
                </div>

                <span className={`px-2.5 py-1 rounded-full text-[10px] font-bold uppercase tracking-wider backdrop-blur-md border ${
                  res.status === 'confirmed'
                    ? 'bg-emerald-950/80 text-emerald-300 border-emerald-500/40'
                    : res.status === 'pending'
                    ? 'bg-amber-950/80 text-amber-300 border-amber-500/40'
                    : res.status === 'completed'
                    ? 'bg-sky-950/80 text-sky-300 border-sky-500/40'
                    : 'bg-rose-950/80 text-rose-300 border-rose-500/40'
                }`}>
                  {res.status}
                </span>
              </div>

              {/* Booking Specifics */}
              <div className="p-3 rounded-2xl bg-[#070d0a]/80 border border-white/5 space-y-2 text-xs backdrop-blur-sm">
                <div className="flex items-center justify-between text-neutral-300">
                  <div className="flex items-center gap-1.5">
                    <CalendarCheck className="w-3.5 h-3.5 text-[#d4af37]" />
                    <span>{res.date}</span>
                  </div>
                  <div className="flex items-center gap-1.5">
                    <Clock className="w-3.5 h-3.5 text-neutral-400" />
                    <span className="font-mono">{res.time}</span>
                  </div>
                  <div className="flex items-center gap-1.5">
                    <Users className="w-3.5 h-3.5 text-neutral-400" />
                    <span>{res.guestsCount} Guests</span>
                  </div>
                </div>

                <div className="flex items-center justify-between text-neutral-400 pt-1 border-t border-white/5">
                  <a href={`tel:${res.customerPhone}`} className="hover:text-white flex items-center gap-1">
                    <Phone className="w-3 h-3 text-[#d4af37]" /> {res.customerPhone}
                  </a>
                </div>

                {res.specialRequests && (
                  <div className="text-[11px] text-amber-300/90 italic pt-1 border-t border-white/5">
                    "{res.specialRequests}"
                  </div>
                )}
              </div>

              {/* Table assignment input */}
              <div>
                <label className="block text-[10px] uppercase font-semibold text-neutral-400 mb-1">
                  Assigned Table / Room
                </label>
                <input
                  type="text"
                  placeholder="e.g. Table 8 or VIP Room 2"
                  value={assignedTableNumber[res.id] || res.assignedTable || ''}
                  onChange={(e) => setAssignedTableNumber({ ...assignedTableNumber, [res.id]: e.target.value })}
                  className="w-full px-3 py-1.5 glass-input rounded-xl text-xs text-white placeholder:text-neutral-500 focus:outline-none"
                />
              </div>

              {/* Status Action Buttons */}
              <div className="pt-2 flex items-center gap-2">
                {res.status === 'pending' && (
                  <>
                    <button
                      onClick={() => updateReservationStatus(res.id, 'confirmed', assignedTableNumber[res.id] || 'Table 10 (Royal Lounge)')}
                      className="flex-1 py-2 rounded-xl bg-emerald-600 hover:bg-emerald-500 text-white text-xs font-bold flex items-center justify-center gap-1 transition-all shadow-sm"
                    >
                      <Check className="w-3.5 h-3.5" />
                      <span>Confirm & Hold</span>
                    </button>
                    <button
                      onClick={() => updateReservationStatus(res.id, 'cancelled')}
                      className="px-3 py-2 rounded-xl bg-rose-950/60 text-rose-300 hover:bg-rose-900 text-xs font-semibold border border-rose-800/40 transition-colors"
                    >
                      <X className="w-3.5 h-3.5" />
                    </button>
                  </>
                )}

                {res.status === 'confirmed' && (
                  <button
                    onClick={() => updateReservationStatus(res.id, 'completed')}
                    className="w-full py-2 rounded-xl bg-sky-600 hover:bg-sky-500 text-white text-xs font-bold flex items-center justify-center gap-1 transition-all shadow-sm"
                  >
                    <CheckCircle2 className="w-3.5 h-3.5" />
                    <span>Guests Seated / Completed</span>
                  </button>
                )}

                {(res.status === 'completed' || res.status === 'cancelled') && (
                  <div className="w-full py-1.5 text-center text-xs text-neutral-500 font-mono">
                    Archived Request
                  </div>
                )}
              </div>
            </motion.div>
          ))
        )}
      </div>
    </div>
  );
};
