import React, { useState } from 'react';
import { useRestaurant } from '../../context/RestaurantContext';
import { X, Lock, Mail, User, Phone, ShieldCheck, Sparkles, CheckCircle2 } from 'lucide-react';
import { motion, AnimatePresence } from 'motion/react';
import { DEMO_USERS } from '../../data/initialState';

export const AuthModal: React.FC = () => {
  const { isAuthModalOpen, setIsAuthModalOpen, login, register, currentUser, logout } = useRestaurant();
  const [mode, setMode] = useState<'login' | 'register'>('login');
  
  // Form states
  const [email, setEmail] = useState('');
  const [password, setPassword] = useState('');
  const [name, setName] = useState('');
  const [phone, setPhone] = useState('');
  const [selectedRole, setSelectedRole] = useState<'customer' | 'admin'>('customer');

  if (!isAuthModalOpen) return null;

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (mode === 'login') {
      if (!email) return;
      login(email);
      setIsAuthModalOpen(false);
    } else {
      if (!email || !name) return;
      register(name, email, phone || '+92 300 1234567', selectedRole);
      setIsAuthModalOpen(false);
    }
  };

  const handleQuickLogin = (demoUser: typeof DEMO_USERS[0]) => {
    login(demoUser.email, demoUser.role);
    setIsAuthModalOpen(false);
  };

  return (
    <AnimatePresence>
      <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/80 backdrop-blur-md">
        <motion.div
          initial={{ opacity: 0, scale: 0.95, y: 15 }}
          animate={{ opacity: 1, scale: 1, y: 0 }}
          exit={{ opacity: 0, scale: 0.95, y: 15 }}
          className="w-full max-w-md bg-[#08120d]/90 backdrop-blur-2xl border border-[#d4af37]/45 rounded-3xl shadow-[0_20px_60px_rgba(0,0,0,0.8)] p-6 sm:p-8 relative overflow-hidden"
        >
          {/* Subtle gold glow corner */}
          <div className="absolute top-0 right-0 w-32 h-32 bg-[#d4af37]/15 rounded-full blur-2xl pointer-events-none" />

          {/* Close button */}
          <button
            onClick={() => setIsAuthModalOpen(false)}
            className="absolute top-4 right-4 p-2 text-neutral-400 hover:text-white rounded-xl hover:bg-white/10 transition-colors"
          >
            <X className="w-5 h-5" />
          </button>

          {/* Header */}
          <div className="text-center mb-6">
            <div className="w-12 h-12 mx-auto rounded-2xl bg-[#17291f]/90 border border-[#d4af37]/45 flex items-center justify-center mb-3 shadow-md">
              <Sparkles className="w-6 h-6 text-[#d4af37]" />
            </div>
            <h3 className="font-cinzel text-xl font-bold text-[#f9f7f2] tracking-wide">
              {currentUser ? 'Active Profile' : mode === 'login' ? 'Sign In to Mystique' : 'Join Mystique Dining Club'}
            </h3>
            <p className="text-xs text-neutral-400 mt-1">
              {currentUser
                ? `Logged in as ${currentUser.name} (${currentUser.role.toUpperCase()})`
                : 'Supabase Authentication & Role-Based Access'}
            </p>
          </div>

          {currentUser ? (
            <div className="space-y-4">
              <div className="p-4 rounded-2xl glass-panel flex items-center gap-3 shadow-sm">
                <img
                  src={currentUser.avatar || 'https://images.unsplash.com/photo-1534528741775-53994a69daeb?auto=format&fit=crop&w=120&q=80'}
                  alt={currentUser.name}
                  className="w-12 h-12 rounded-xl object-cover border border-[#d4af37]/40 shadow-sm"
                />
                <div>
                  <div className="font-semibold text-sm text-[#f5f1e8]">{currentUser.name}</div>
                  <div className="text-xs text-neutral-400 font-mono">{currentUser.email}</div>
                  <span className="inline-block mt-1 px-2.5 py-0.5 rounded-full bg-[#d4af37]/20 text-[#f3e5ab] text-[10px] font-bold uppercase border border-[#d4af37]/35">
                    Role: {currentUser.role}
                  </span>
                </div>
              </div>

              <div className="flex gap-2">
                <button
                  onClick={() => { logout(); }}
                  className="w-full py-2.5 rounded-xl bg-rose-950/50 hover:bg-rose-900/60 border border-rose-600/40 text-rose-200 text-xs font-semibold transition-colors"
                >
                  Sign Out
                </button>
                <button
                  onClick={() => setIsAuthModalOpen(false)}
                  className="w-full py-2.5 rounded-xl bg-[#1a2d21]/80 hover:bg-[#233c2c] border border-[#d4af37]/35 text-[#f3e5ab] text-xs font-semibold transition-colors"
                >
                  Close
                </button>
              </div>
            </div>
          ) : (
            <>
              {/* Tab Switcher */}
              <div className="flex p-1 rounded-2xl glass-panel mb-5">
                <button
                  onClick={() => setMode('login')}
                  className={`flex-1 py-2 rounded-xl text-xs font-semibold transition-all ${
                    mode === 'login' ? 'bg-[#182a20]/90 text-[#f3e5ab] border border-[#d4af37]/35 shadow-sm' : 'text-neutral-400 hover:text-white'
                  }`}
                >
                  Sign In
                </button>
                <button
                  onClick={() => setMode('register')}
                  className={`flex-1 py-2 rounded-xl text-xs font-semibold transition-all ${
                    mode === 'register' ? 'bg-[#182a20]/90 text-[#f3e5ab] border border-[#d4af37]/35 shadow-sm' : 'text-neutral-400 hover:text-white'
                  }`}
                >
                  Create Account
                </button>
              </div>

              {/* Form */}
              <form onSubmit={handleSubmit} className="space-y-3.5">
                {mode === 'register' && (
                  <div>
                    <label className="block text-[11px] uppercase tracking-wider text-neutral-400 font-semibold mb-1">
                      Full Name
                    </label>
                    <div className="relative">
                      <User className="w-4 h-4 text-neutral-400 absolute left-3 top-3" />
                      <input
                        type="text"
                        required
                        value={name}
                        onChange={(e) => setName(e.target.value)}
                        placeholder="e.g. Samiya Fatima"
                        className="w-full pl-9 pr-3 py-2.5 glass-input rounded-xl text-xs text-white placeholder:text-neutral-500 focus:outline-none"
                      />
                    </div>
                  </div>
                )}

                <div>
                  <label className="block text-[11px] uppercase tracking-wider text-neutral-400 font-semibold mb-1">
                    Email Address
                  </label>
                  <div className="relative">
                    <Mail className="w-4 h-4 text-neutral-400 absolute left-3 top-3" />
                    <input
                      type="email"
                      required
                      value={email}
                      onChange={(e) => setEmail(e.target.value)}
                      placeholder="samiyaf381@gmail.com"
                      className="w-full pl-9 pr-3 py-2.5 glass-input rounded-xl text-xs text-white placeholder:text-neutral-500 focus:outline-none"
                    />
                  </div>
                </div>

                {mode === 'register' && (
                  <div>
                    <label className="block text-[11px] uppercase tracking-wider text-neutral-400 font-semibold mb-1">
                      Phone Number (Lahore)
                    </label>
                    <div className="relative">
                      <Phone className="w-4 h-4 text-neutral-400 absolute left-3 top-3" />
                      <input
                        type="tel"
                        value={phone}
                        onChange={(e) => setPhone(e.target.value)}
                        placeholder="+92 300 1234567"
                        className="w-full pl-9 pr-3 py-2.5 glass-input rounded-xl text-xs text-white placeholder:text-neutral-500 focus:outline-none"
                      />
                    </div>
                  </div>
                )}

                <div>
                  <label className="block text-[11px] uppercase tracking-wider text-neutral-400 font-semibold mb-1">
                    Password
                  </label>
                  <div className="relative">
                    <Lock className="w-4 h-4 text-neutral-400 absolute left-3 top-3" />
                    <input
                      type="password"
                      required
                      value={password}
                      onChange={(e) => setPassword(e.target.value)}
                      placeholder="••••••••"
                      className="w-full pl-9 pr-3 py-2.5 glass-input rounded-xl text-xs text-white placeholder:text-neutral-500 focus:outline-none"
                    />
                  </div>
                </div>

                {mode === 'register' && (
                  <div>
                    <label className="block text-[11px] uppercase tracking-wider text-neutral-400 font-semibold mb-1">
                      Account Type
                    </label>
                    <div className="grid grid-cols-2 gap-2">
                      <button
                        type="button"
                        onClick={() => setSelectedRole('customer')}
                        className={`p-2 rounded-xl text-xs font-medium border text-center transition-all ${
                          selectedRole === 'customer'
                            ? 'bg-[#182a20]/90 border-[#d4af37]/60 text-[#f3e5ab] shadow-sm'
                            : 'glass-panel text-neutral-400'
                        }`}
                      >
                        Customer Diner
                      </button>
                      <button
                        type="button"
                        onClick={() => setSelectedRole('admin')}
                        className={`p-2 rounded-xl text-xs font-medium border text-center transition-all ${
                          selectedRole === 'admin'
                            ? 'bg-[#182a20]/90 border-[#d4af37]/60 text-[#f3e5ab] shadow-sm'
                            : 'glass-panel text-neutral-400'
                        }`}
                      >
                        Staff / Admin
                      </button>
                    </div>
                  </div>
                )}

                <button
                  type="submit"
                  className="w-full py-3 mt-2 rounded-xl bg-gradient-to-r from-[#d4af37] via-[#e2c458] to-[#aa8210] text-[#090f0c] text-xs font-bold uppercase tracking-wider shadow-[0_4px_20px_rgba(212,175,55,0.3)] hover:brightness-110 active:scale-98 transition-all"
                >
                  {mode === 'login' ? 'Authenticate & Sign In' : 'Register Account'}
                </button>
              </form>

              {/* 1-Click Demo Profiles */}
              <div className="mt-6 pt-5 border-t border-white/10">
                <div className="flex items-center justify-between mb-2.5">
                  <span className="text-[11px] font-semibold text-neutral-400 uppercase tracking-wider flex items-center gap-1">
                    <ShieldCheck className="w-3.5 h-3.5 text-[#d4af37]" /> 1-Click Instant Demo Login:
                  </span>
                </div>
                <div className="grid grid-cols-3 gap-2">
                  {DEMO_USERS.map((usr) => (
                    <button
                      key={usr.id}
                      onClick={() => handleQuickLogin(usr)}
                      className="p-2 rounded-xl glass-panel hover:bg-[#18291f]/90 text-left transition-all hover:scale-102"
                    >
                      <div className="text-[11px] font-semibold text-[#f5f0e6] truncate">{usr.name.split(' ')[0]}</div>
                      <div className="text-[9px] text-[#d4af37] font-medium uppercase mt-0.5">{usr.role}</div>
                    </button>
                  ))}
                </div>
              </div>
            </>
          )}
        </motion.div>
      </div>
    </AnimatePresence>
  );
};
