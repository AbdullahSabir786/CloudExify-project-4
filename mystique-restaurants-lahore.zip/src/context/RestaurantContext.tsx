import React, { createContext, useContext, useState, useEffect, ReactNode } from 'react';
import { User, MenuItem, Order, TableReservation, Review, OrderItem, OrderStatus, CategoryType } from '../types';
import { INITIAL_MENU_ITEMS } from '../data/initialMenu';
import { DEMO_USERS, INITIAL_ORDERS, INITIAL_RESERVATIONS, INITIAL_REVIEWS } from '../data/initialState';
import { playOrderChime } from '../utils/audio';

interface ToastMessage {
  id: string;
  title: string;
  message: string;
  type: 'success' | 'info' | 'warning' | 'error';
}

interface RestaurantContextType {
  currentUser: User | null;
  users: User[];
  login: (email: string, role?: 'customer' | 'admin' | 'staff') => boolean;
  register: (name: string, email: string, phone: string, role?: 'customer' | 'admin') => void;
  logout: () => void;
  switchRole: (role: 'customer' | 'admin' | 'staff') => void;
  
  // Menu items
  menuItems: MenuItem[];
  addMenuItem: (item: Omit<MenuItem, 'id'>) => void;
  updateMenuItem: (id: string, updates: Partial<MenuItem>) => void;
  deleteMenuItem: (id: string) => void;
  toggleItemAvailability: (id: string) => void;
  
  // Cart
  cart: OrderItem[];
  addToCart: (item: OrderItem) => void;
  removeFromCart: (index: number) => void;
  updateCartQuantity: (index: number, quantity: number) => void;
  clearCart: () => void;
  cartSubtotal: number;
  cartTax: number;
  cartTotal: number;
  
  // Orders
  orders: Order[];
  activeOrder: Order | null;
  setActiveOrder: (order: Order | null) => void;
  placeOrder: (orderData: {
    orderType: 'dine_in' | 'takeaway' | 'delivery';
    tableNumber?: string;
    deliveryAddress?: string;
    paymentMethod: 'cash_on_delivery' | 'card_at_counter' | 'online_banking' | 'jazzcash_easypaisa';
    specialOrderNote?: string;
  }) => Order;
  updateOrderStatus: (orderId: string, status: OrderStatus, note?: string) => void;
  cancelOrder: (orderId: string, reason: string) => void;
  
  // Reservations
  reservations: TableReservation[];
  createReservation: (resData: Omit<TableReservation, 'id' | 'status' | 'createdAt'>) => TableReservation;
  updateReservationStatus: (resId: string, status: 'pending' | 'confirmed' | 'rejected' | 'completed', tableAssigned?: string) => void;
  
  // Reviews
  reviews: Review[];
  addReview: (review: Omit<Review, 'id' | 'date'>) => void;
  
  // UI Helpers
  activeTab: 'customer' | 'admin';
  setActiveTab: (tab: 'customer' | 'admin') => void;
  isCartOpen: boolean;
  setIsCartOpen: (open: boolean) => void;
  isAuthModalOpen: boolean;
  setIsAuthModalOpen: (open: boolean) => void;
  isReservationModalOpen: boolean;
  setIsReservationModalOpen: (open: boolean) => void;
  toasts: ToastMessage[];
  addToast: (title: string, message: string, type?: 'success' | 'info' | 'warning' | 'error') => void;
  removeToast: (id: string) => void;
  
  // Sound controls
  soundEnabled: boolean;
  setSoundEnabled: (enabled: boolean) => void;
}

const RestaurantContext = createContext<RestaurantContextType | undefined>(undefined);

const STORAGE_KEYS = {
  MENU: 'mystique_menu_v2',
  ORDERS: 'mystique_orders_v1',
  RESERVATIONS: 'mystique_reservations_v1',
  REVIEWS: 'mystique_reviews_v1',
  USER: 'mystique_current_user_v1',
  USERS_LIST: 'mystique_users_list_v1',
  CART: 'mystique_cart_v1'
};

export const RestaurantProvider: React.FC<{ children: ReactNode }> = ({ children }) => {
  // Sync channel across browser tabs
  const [broadcastChannel, setBroadcastChannel] = useState<BroadcastChannel | null>(null);

  // Users state
  const [users, setUsers] = useState<User[]>(() => {
    const saved = localStorage.getItem(STORAGE_KEYS.USERS_LIST);
    return saved ? JSON.parse(saved) : DEMO_USERS;
  });

  const [currentUser, setCurrentUser] = useState<User | null>(() => {
    const saved = localStorage.getItem(STORAGE_KEYS.USER);
    return saved ? JSON.parse(saved) : DEMO_USERS[0]; // Default to Samiya Fatima (customer)
  });

  // Menu items state
  const [menuItems, setMenuItems] = useState<MenuItem[]>(() => {
    const saved = localStorage.getItem(STORAGE_KEYS.MENU);
    if (saved) {
      try {
        const parsed: MenuItem[] = JSON.parse(saved);
        return parsed.map(item => {
          if (item.id === 'sushi-7' && item.image.includes('1558981403-c5f9899a28bc')) {
            return { ...item, image: 'https://images.unsplash.com/photo-1617196034796-73dfa7b1fd56?auto=format&fit=crop&w=800&q=80' };
          }
          return item;
        });
      } catch {
        return INITIAL_MENU_ITEMS;
      }
    }
    return INITIAL_MENU_ITEMS;
  });

  // Orders state
  const [orders, setOrders] = useState<Order[]>(() => {
    const saved = localStorage.getItem(STORAGE_KEYS.ORDERS);
    return saved ? JSON.parse(saved) : INITIAL_ORDERS;
  });

  // Active tracked order
  const [activeOrder, setActiveOrder] = useState<Order | null>(() => {
    const saved = localStorage.getItem(STORAGE_KEYS.ORDERS);
    const orderList: Order[] = saved ? JSON.parse(saved) : INITIAL_ORDERS;
    return orderList.find(o => o.customerId === 'usr-customer-1' && o.status !== 'completed' && o.status !== 'cancelled') || orderList[0] || null;
  });

  // Reservations state
  const [reservations, setReservations] = useState<TableReservation[]>(() => {
    const saved = localStorage.getItem(STORAGE_KEYS.RESERVATIONS);
    return saved ? JSON.parse(saved) : INITIAL_RESERVATIONS;
  });

  // Reviews state
  const [reviews, setReviews] = useState<Review[]>(() => {
    const saved = localStorage.getItem(STORAGE_KEYS.REVIEWS);
    return saved ? JSON.parse(saved) : INITIAL_REVIEWS;
  });

  // Cart state
  const [cart, setCart] = useState<OrderItem[]>(() => {
    const saved = localStorage.getItem(STORAGE_KEYS.CART);
    return saved ? JSON.parse(saved) : [];
  });

  // UI state
  const [activeTab, setActiveTab] = useState<'customer' | 'admin'>('customer');
  const [isCartOpen, setIsCartOpen] = useState<boolean>(false);
  const [isAuthModalOpen, setIsAuthModalOpen] = useState<boolean>(false);
  const [isReservationModalOpen, setIsReservationModalOpen] = useState<boolean>(false);
  const [toasts, setToasts] = useState<ToastMessage[]>([]);
  const [soundEnabled, setSoundEnabled] = useState<boolean>(true);

  // Broadcast channel setup for real-time multi-tab sync
  useEffect(() => {
    if (typeof window !== 'undefined' && 'BroadcastChannel' in window) {
      const channel = new BroadcastChannel('mystique_realtime_db');
      channel.onmessage = (event) => {
        const { type, payload } = event.data;
        if (type === 'ORDER_PLACED') {
          setOrders(prev => [payload, ...prev.filter(o => o.id !== payload.id)]);
          if (soundEnabled) playOrderChime('new_order');
        } else if (type === 'ORDER_UPDATED') {
          setOrders(prev => prev.map(o => o.id === payload.id ? payload : o));
          setActiveOrder(current => (current && current.id === payload.id ? payload : current));
          if (soundEnabled) playOrderChime('status_update');
        } else if (type === 'MENU_UPDATED') {
          setMenuItems(payload);
        } else if (type === 'RESERVATIONS_UPDATED') {
          setReservations(payload);
        }
      };
      setBroadcastChannel(channel);
      return () => {
        channel.close();
      };
    }
  }, [soundEnabled]);

  // Persistent storage effects
  useEffect(() => {
    localStorage.setItem(STORAGE_KEYS.MENU, JSON.stringify(menuItems));
  }, [menuItems]);

  useEffect(() => {
    localStorage.setItem(STORAGE_KEYS.ORDERS, JSON.stringify(orders));
  }, [orders]);

  useEffect(() => {
    localStorage.setItem(STORAGE_KEYS.RESERVATIONS, JSON.stringify(reservations));
  }, [reservations]);

  useEffect(() => {
    localStorage.setItem(STORAGE_KEYS.REVIEWS, JSON.stringify(reviews));
  }, [reviews]);

  useEffect(() => {
    localStorage.setItem(STORAGE_KEYS.USER, JSON.stringify(currentUser));
  }, [currentUser]);

  useEffect(() => {
    localStorage.setItem(STORAGE_KEYS.USERS_LIST, JSON.stringify(users));
  }, [users]);

  useEffect(() => {
    localStorage.setItem(STORAGE_KEYS.CART, JSON.stringify(cart));
  }, [cart]);

  // Toast manager
  const addToast = (title: string, message: string, type: 'success' | 'info' | 'warning' | 'error' = 'info') => {
    const id = 'toast_' + Math.random().toString(36).substring(2, 9);
    setToasts(prev => [...prev, { id, title, message, type }]);
    setTimeout(() => {
      removeToast(id);
    }, 4000);
  };

  const removeToast = (id: string) => {
    setToasts(prev => prev.filter(t => t.id !== id));
  };

  // Auth functions
  const login = (email: string, roleOverride?: 'customer' | 'admin' | 'staff'): boolean => {
    const existing = users.find(u => u.email.toLowerCase() === email.toLowerCase());
    if (existing) {
      const updatedUser = roleOverride ? { ...existing, role: roleOverride } : existing;
      setCurrentUser(updatedUser);
      addToast('Welcome Back', `Signed in as ${updatedUser.name} (${updatedUser.role.toUpperCase()})`, 'success');
      return true;
    }

    // Auto-create if not found
    const newUser: User = {
      id: 'usr_' + Date.now(),
      email,
      name: email.split('@')[0].replace('.', ' ').replace(/^./, c => c.toUpperCase()),
      role: roleOverride || (email.includes('admin') ? 'admin' : email.includes('chef') ? 'staff' : 'customer'),
      phone: '+92 300 1234567'
    };
    setUsers(prev => [...prev, newUser]);
    setCurrentUser(newUser);
    addToast('Account Created', `Logged in as ${newUser.name}`, 'success');
    return true;
  };

  const register = (name: string, email: string, phone: string, role: 'customer' | 'admin' = 'customer') => {
    const newUser: User = {
      id: 'usr_' + Date.now(),
      name,
      email,
      phone,
      role,
      address: 'Gulberg III, Lahore'
    };
    setUsers(prev => [...prev, newUser]);
    setCurrentUser(newUser);
    addToast('Registration Successful', `Welcome to Mystique, ${name}!`, 'success');
  };

  const logout = () => {
    setCurrentUser(null);
    addToast('Signed Out', 'You have been safely signed out.', 'info');
  };

  const switchRole = (role: 'customer' | 'admin' | 'staff') => {
    const targetUser = users.find(u => u.role === role) || DEMO_USERS.find(u => u.role === role) || {
      id: 'usr_' + role,
      name: role === 'admin' ? 'Manager Farhan' : role === 'staff' ? 'Head Chef Tariq' : 'Samiya Fatima',
      email: role === 'admin' ? 'admin@mystiquerestaurants.com' : role === 'staff' ? 'chef@mystiquerestaurants.com' : 'samiyaf381@gmail.com',
      role: role
    };
    setCurrentUser(targetUser);
    if (role === 'admin' || role === 'staff') {
      setActiveTab('admin');
    } else {
      setActiveTab('customer');
    }
    addToast('Role Switched', `Switched active session to ${targetUser.name} [${role.toUpperCase()}]`, 'info');
  };

  // Menu item management
  const addMenuItem = (newItemData: Omit<MenuItem, 'id'>) => {
    const newItem: MenuItem = {
      ...newItemData,
      id: 'dish_' + Date.now()
    };
    const updated = [newItem, ...menuItems];
    setMenuItems(updated);
    broadcastChannel?.postMessage({ type: 'MENU_UPDATED', payload: updated });
    addToast('Menu Item Added', `${newItem.name} added to catalog`, 'success');
  };

  const updateMenuItem = (id: string, updates: Partial<MenuItem>) => {
    const updated = menuItems.map(item => item.id === id ? { ...item, ...updates } : item);
    setMenuItems(updated);
    broadcastChannel?.postMessage({ type: 'MENU_UPDATED', payload: updated });
    addToast('Menu Updated', `Item updated successfully`, 'success');
  };

  const deleteMenuItem = (id: string) => {
    const updated = menuItems.filter(item => item.id !== id);
    setMenuItems(updated);
    broadcastChannel?.postMessage({ type: 'MENU_UPDATED', payload: updated });
    addToast('Item Removed', `Menu item removed from catalog`, 'info');
  };

  const toggleItemAvailability = (id: string) => {
    const updated = menuItems.map(item => {
      if (item.id === id) {
        const isNowAvailable = !item.isAvailable;
        addToast(
          isNowAvailable ? 'Dish Available' : 'Marked Out of Stock',
          `${item.name} is now ${isNowAvailable ? 'in stock' : 'out of stock'}`,
          isNowAvailable ? 'success' : 'warning'
        );
        return { ...item, isAvailable: isNowAvailable };
      }
      return item;
    });
    setMenuItems(updated);
    broadcastChannel?.postMessage({ type: 'MENU_UPDATED', payload: updated });
  };

  // Cart operations
  const addToCart = (item: OrderItem) => {
    setCart(prev => {
      // Check if identical item already exists (same ID, portion, protein, and side)
      const existingIdx = prev.findIndex(ci => 
        ci.menuItemId === item.menuItemId &&
        ci.selectedPortion === item.selectedPortion &&
        ci.selectedProtein === item.selectedProtein &&
        JSON.stringify(ci.selectedSides || []) === JSON.stringify(item.selectedSides || [])
      );

      if (existingIdx > -1) {
        const updated = [...prev];
        updated[existingIdx].quantity += item.quantity;
        updated[existingIdx].totalItemPrice += item.totalItemPrice;
        return updated;
      }
      return [...prev, item];
    });

    setIsCartOpen(true);
    addToast('Added to Cart', `${item.name} (x${item.quantity}) added`, 'success');
  };

  const removeFromCart = (index: number) => {
    setCart(prev => prev.filter((_, i) => i !== index));
  };

  const updateCartQuantity = (index: number, quantity: number) => {
    if (quantity <= 0) {
      removeFromCart(index);
      return;
    }
    setCart(prev => {
      const updated = [...prev];
      updated[index].quantity = quantity;
      updated[index].totalItemPrice = updated[index].unitPrice * quantity;
      return updated;
    });
  };

  const clearCart = () => {
    setCart([]);
  };

  // Calculations
  const cartSubtotal = cart.reduce((acc, item) => acc + item.totalItemPrice, 0);
  const cartTax = Math.round(cartSubtotal * 0.16); // 16% Punjab Sales Tax
  const cartTotal = cartSubtotal + cartTax;

  // Place Order
  const placeOrder = (orderData: {
    orderType: 'dine_in' | 'takeaway' | 'delivery';
    tableNumber?: string;
    deliveryAddress?: string;
    paymentMethod: 'cash_on_delivery' | 'card_at_counter' | 'online_banking' | 'jazzcash_easypaisa';
    specialOrderNote?: string;
  }): Order => {
    const deliveryFee = orderData.orderType === 'delivery' ? 350 : 0;
    const finalTotal = cartTotal + deliveryFee;

    const newOrder: Order = {
      id: 'ord_' + Date.now(),
      orderNumber: `MYS-${Math.floor(1000 + Math.random() * 9000)}`,
      customerId: currentUser?.id || 'guest_' + Date.now(),
      customerName: currentUser?.name || 'Guest Diner',
      customerPhone: currentUser?.phone || '+92 300 0000000',
      customerEmail: currentUser?.email || 'guest@mystiquerestaurants.com',
      orderType: orderData.orderType,
      tableNumber: orderData.tableNumber,
      deliveryAddress: orderData.deliveryAddress || currentUser?.address,
      items: [...cart],
      subtotal: cartSubtotal,
      tax: cartTax,
      deliveryFee,
      discount: 0,
      total: finalTotal,
      paymentMethod: orderData.paymentMethod,
      paymentStatus: orderData.paymentMethod === 'card_at_counter' || orderData.paymentMethod === 'online_banking' ? 'paid' : 'unpaid',
      status: 'pending',
      statusTimeline: [
        {
          status: 'pending',
          timestamp: 'Just now',
          note: `Order placed via online portal (${orderData.orderType.replace('_', ' ').toUpperCase()})`
        }
      ],
      specialOrderNote: orderData.specialOrderNote,
      createdAt: new Date().toISOString(),
      estimatedPrepMinutes: 25
    };

    const updatedOrders = [newOrder, ...orders];
    setOrders(updatedOrders);
    setActiveOrder(newOrder);
    clearCart();
    setIsCartOpen(false);

    // Broadcast event across tabs for Admin live view
    broadcastChannel?.postMessage({ type: 'ORDER_PLACED', payload: newOrder });
    if (soundEnabled) playOrderChime('new_order');

    addToast('Order Placed Successfully!', `Ticket ${newOrder.orderNumber} sent to Mystique Kitchen`, 'success');
    return newOrder;
  };

  // Update order status (Admin function)
  const updateOrderStatus = (orderId: string, newStatus: OrderStatus, note?: string) => {
    let updatedOrder: Order | null = null;

    const updatedOrders = orders.map(ord => {
      if (ord.id === orderId) {
        const timelineEntry = {
          status: newStatus,
          timestamp: 'Just now',
          note: note || getStatusDefaultNote(newStatus, ord.orderType)
        };

        updatedOrder = {
          ...ord,
          status: newStatus,
          paymentStatus: newStatus === 'completed' ? 'paid' : ord.paymentStatus,
          statusTimeline: [...ord.statusTimeline, timelineEntry]
        };
        return updatedOrder;
      }
      return ord;
    });

    setOrders(updatedOrders);

    if (updatedOrder) {
      if (activeOrder && activeOrder.id === orderId) {
        setActiveOrder(updatedOrder);
      }
      broadcastChannel?.postMessage({ type: 'ORDER_UPDATED', payload: updatedOrder });
      if (soundEnabled) playOrderChime('status_update');
      addToast(
        'Order Status Updated',
        `Order ${updatedOrder.orderNumber} is now: ${newStatus.replace('_', ' ').toUpperCase()}`,
        'success'
      );
    }
  };

  const cancelOrder = (orderId: string, reason: string) => {
    let updatedOrder: Order | null = null;
    const updatedOrders = orders.map(ord => {
      if (ord.id === orderId) {
        updatedOrder = {
          ...ord,
          status: 'cancelled',
          cancellationReason: reason,
          statusTimeline: [
            ...ord.statusTimeline,
            { status: 'cancelled', timestamp: 'Just now', note: `Cancelled: ${reason}` }
          ]
        };
        return updatedOrder;
      }
      return ord;
    });
    setOrders(updatedOrders);
    if (updatedOrder) {
      if (activeOrder && activeOrder.id === orderId) {
        setActiveOrder(updatedOrder);
      }
      broadcastChannel?.postMessage({ type: 'ORDER_UPDATED', payload: updatedOrder });
      addToast('Order Cancelled', `Order marked as cancelled`, 'warning');
    }
  };

  // Reservation management
  const createReservation = (resData: Omit<TableReservation, 'id' | 'status' | 'createdAt'>): TableReservation => {
    const newRes: TableReservation = {
      ...resData,
      id: 'res_' + Date.now(),
      status: 'pending',
      createdAt: new Date().toISOString()
    };
    const updated = [newRes, ...reservations];
    setReservations(updated);
    broadcastChannel?.postMessage({ type: 'RESERVATIONS_UPDATED', payload: updated });
    setIsReservationModalOpen(false);
    if (soundEnabled) playOrderChime('new_order');
    addToast('Table Reservation Requested', `Booking request for ${newRes.guestsCount} guests submitted for approval`, 'success');
    return newRes;
  };

  const updateReservationStatus = (resId: string, status: 'pending' | 'confirmed' | 'rejected' | 'completed', tableAssigned?: string) => {
    const updated = reservations.map(r => {
      if (r.id === resId) {
        return {
          ...r,
          status,
          tableAssigned: tableAssigned !== undefined ? tableAssigned : r.tableAssigned
        };
      }
      return r;
    });
    setReservations(updated);
    broadcastChannel?.postMessage({ type: 'RESERVATIONS_UPDATED', payload: updated });
    addToast('Reservation Updated', `Booking status changed to ${status.toUpperCase()}`, 'success');
  };

  // Review management
  const addReview = (newReview: Omit<Review, 'id' | 'date'>) => {
    const review: Review = {
      ...newReview,
      id: 'rev_' + Date.now(),
      date: 'Just now',
      avatarBg: 'bg-emerald-900'
    };
    setReviews(prev => [review, ...prev]);
    addToast('Review Submitted', 'Thank you for your valuable feedback on Mystique Lahore!', 'success');
  };

  return (
    <RestaurantContext.Provider
      value={{
        currentUser,
        users,
        login,
        register,
        logout,
        switchRole,
        menuItems,
        addMenuItem,
        updateMenuItem,
        deleteMenuItem,
        toggleItemAvailability,
        cart,
        addToCart,
        removeFromCart,
        updateCartQuantity,
        clearCart,
        cartSubtotal,
        cartTax,
        cartTotal,
        orders,
        activeOrder,
        setActiveOrder,
        placeOrder,
        updateOrderStatus,
        cancelOrder,
        reservations,
        createReservation,
        updateReservationStatus,
        reviews,
        addReview,
        activeTab,
        setActiveTab,
        isCartOpen,
        setIsCartOpen,
        isAuthModalOpen,
        setIsAuthModalOpen,
        isReservationModalOpen,
        setIsReservationModalOpen,
        toasts,
        addToast,
        removeToast,
        soundEnabled,
        setSoundEnabled
      }}
    >
      {children}
    </RestaurantContext.Provider>
  );
};

export const useRestaurant = () => {
  const context = useContext(RestaurantContext);
  if (!context) {
    throw new Error('useRestaurant must be used within a RestaurantProvider');
  }
  return context;
};

function getStatusDefaultNote(status: OrderStatus, orderType: string): string {
  switch (status) {
    case 'pending':
      return 'Order pending kitchen confirmation';
    case 'preparing':
      return 'Head Chef has begun preparing your dishes in the wok & grill stations';
    case 'ready':
      return orderType === 'dine_in'
        ? 'Plated and ready for server delivery to your table'
        : orderType === 'delivery'
        ? 'Packed in thermal container, handed to delivery courier'
        : 'Freshly packed and waiting at MM Alam front desk';
    case 'out_for_delivery':
      return 'Courier rider is en route to your location in Lahore';
    case 'completed':
      return 'Order completed and delivered. Bon Appétit!';
    case 'cancelled':
      return 'Order cancelled by restaurant management';
    default:
      return 'Status updated';
  }
}
