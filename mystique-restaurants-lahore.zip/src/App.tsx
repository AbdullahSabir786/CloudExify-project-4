import React, { useState } from 'react';
import { RestaurantProvider, useRestaurant } from './context/RestaurantContext';
import { Navbar } from './components/common/Navbar';
import { Footer } from './components/common/Footer';
import { ToastContainer } from './components/common/ToastContainer';
import { AuthModal } from './components/auth/AuthModal';
import { HeroBanner } from './components/customer/HeroBanner';
import { MenuExplorer } from './components/customer/MenuExplorer';
import { CartDrawer } from './components/customer/CartDrawer';
import { LiveOrderTracker } from './components/customer/LiveOrderTracker';
import { ReservationModal } from './components/customer/ReservationModal';
import { ReviewsSection } from './components/customer/ReviewsSection';
import { OrderHistoryModal } from './components/customer/OrderHistoryModal';
import { AdminDashboard } from './components/admin/AdminDashboard';
import { Order } from './types';
import { motion, AnimatePresence } from 'motion/react';

const MainAppContent: React.FC = () => {
  const { 
    activeTab, 
    setActiveTab, 
    activeOrder, 
    setActiveOrder 
  } = useRestaurant();

  const [isTrackerOpen, setIsTrackerOpen] = useState(false);
  const [isHistoryOpen, setIsHistoryOpen] = useState(false);

  const handleScrollToMenu = () => {
    setActiveTab('customer');
    setTimeout(() => {
      const element = document.getElementById('restaurant-menu-section');
      if (element) {
        element.scrollIntoView({ behavior: 'smooth' });
      }
    }, 50);
  };

  const handleOrderPlacedSuccess = (orderId: string) => {
    setIsTrackerOpen(true);
  };

  const handleTrackSpecificOrder = (order: Order) => {
    setActiveOrder(order);
    setIsTrackerOpen(true);
  };

  return (
    <div className="min-h-screen bg-[#070c09] text-[#fbf8f2] flex flex-col selection:bg-[#d4af37] selection:text-black">
      
      {/* Navigation Bar */}
      <Navbar
        onOpenTracker={() => setIsTrackerOpen(true)}
        onOpenHistory={() => setIsHistoryOpen(true)}
      />

      {/* Main Content Area */}
      <main className="flex-1">
        <AnimatePresence mode="wait">
          {activeTab === 'customer' ? (
            <motion.div
              key="customer-view"
              initial={{ opacity: 0 }}
              animate={{ opacity: 1 }}
              exit={{ opacity: 0 }}
              transition={{ duration: 0.3 }}
            >
              {/* Hero Banner with Fine Dining Ambience */}
              <HeroBanner onScrollToMenu={handleScrollToMenu} />

              {/* Menu Explorer & Filtering */}
              <MenuExplorer />

              {/* Verified Google Reviews Section */}
              <ReviewsSection />
            </motion.div>
          ) : (
            <motion.div
              key="admin-view"
              initial={{ opacity: 0 }}
              animate={{ opacity: 1 }}
              exit={{ opacity: 0 }}
              transition={{ duration: 0.3 }}
            >
              {/* Admin & Kitchen Suite */}
              <AdminDashboard />
            </motion.div>
          )}
        </AnimatePresence>
      </main>

      {/* Footer */}
      <Footer />

      {/* Slide-over Cart Drawer */}
      <CartDrawer onOrderPlacedSuccess={handleOrderPlacedSuccess} />

      {/* Live Order Tracker Modal */}
      <LiveOrderTracker
        isOpen={isTrackerOpen}
        onClose={() => setIsTrackerOpen(false)}
      />

      {/* Order History Modal */}
      <OrderHistoryModal
        isOpen={isHistoryOpen}
        onClose={() => setIsHistoryOpen(false)}
        onTrackOrder={handleTrackSpecificOrder}
      />

      {/* Table Reservation Modal */}
      <ReservationModal />

      {/* Authentication & Role Switcher Modal */}
      <AuthModal />

      {/* Audio & Toast Notification Manager */}
      <ToastContainer />

    </div>
  );
};

export default function App() {
  return (
    <RestaurantProvider>
      <MainAppContent />
    </RestaurantProvider>
  );
}
