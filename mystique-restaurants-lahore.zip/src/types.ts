export type UserRole = 'customer' | 'admin' | 'staff';

export interface User {
  id: string;
  email: string;
  name: string;
  role: UserRole;
  phone?: string;
  address?: string;
  avatar?: string;
}

export type CategoryType = 
  | 'voyage_to_asia' 
  | 'sushi_bar' 
  | 'continental_steaks' 
  | 'italian_pasta_pizza' 
  | 'additional_sides' 
  | 'hi_tea_breakfast' 
  | 'desserts' 
  | 'beverages';

export interface VariantOption {
  label: string;
  price: number;
}

export interface MenuItem {
  id: string;
  name: string;
  category: CategoryType;
  description: string;
  price: number; // Base price in PKR (Rs)
  portionVariants?: VariantOption[]; // e.g. 8 Pcs (4000) vs 4 Pcs (2000)
  proteinVariants?: VariantOption[]; // e.g. Chicken (2650) vs Beef (3000)
  isSpicy?: boolean;
  spicyLevel?: number; // 0 to 3
  isChefSpecial?: boolean;
  isPopular?: boolean;
  isAvailable: boolean;
  image: string;
  prepTimeMinutes: number;
  allergens?: string[];
  calories?: number;
  servedWith?: string; // e.g. "Served with Rice"
}

export interface OrderItem {
  menuItemId: string;
  name: string;
  unitPrice: number;
  quantity: number;
  selectedPortion?: string;
  selectedProtein?: string;
  selectedSides?: string[];
  specialInstructions?: string;
  totalItemPrice: number;
  image?: string;
}

export type OrderStatus = 'pending' | 'preparing' | 'ready' | 'out_for_delivery' | 'completed' | 'cancelled';
export type OrderType = 'dine_in' | 'takeaway' | 'delivery';
export type PaymentMethod = 'cash_on_delivery' | 'card_at_counter' | 'online_banking' | 'jazzcash_easypaisa';

export interface StatusTimelineEntry {
  status: OrderStatus;
  timestamp: string;
  note?: string;
}

export interface Order {
  id: string;
  orderNumber: string;
  customerId: string;
  customerName: string;
  customerPhone: string;
  customerEmail: string;
  orderType: OrderType;
  tableNumber?: string;
  deliveryAddress?: string;
  items: OrderItem[];
  subtotal: number;
  tax: number; // 16% PRA GST
  deliveryFee: number;
  discount: number;
  total: number;
  paymentMethod: PaymentMethod;
  paymentStatus: 'unpaid' | 'paid';
  status: OrderStatus;
  statusTimeline: StatusTimelineEntry[];
  specialOrderNote?: string;
  createdAt: string;
  estimatedPrepMinutes: number;
  cancellationReason?: string;
}

export type ReservationStatus = 'pending' | 'confirmed' | 'cancelled' | 'rejected' | 'completed';

export interface TableReservation {
  id: string;
  customerName: string;
  customerPhone: string;
  customerEmail: string;
  guestsCount: number;
  date: string;
  time: string;
  diningArea: 'Indoor Royal Lounge' | 'Private Dining Room' | 'MM Alam Terrace' | 'Live Music Lounge';
  specialRequests?: string;
  status: ReservationStatus;
  tableAssigned?: string;
  assignedTable?: string;
  createdAt: string;
}

export type Reservation = TableReservation;

export interface Review {
  id: string;
  userName: string;
  rating: number;
  date: string;
  comment: string;
  dishRecommended?: string;
  verifiedVisit: boolean;
  avatarBg?: string;
}
